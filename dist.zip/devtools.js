"use strict";
(() => {
  // src/shared/utils.ts
  var nowId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  var parseQueryString = (input) => {
    const output = {};
    const params = new URLSearchParams(input);
    for (const [key, value] of params.entries()) {
      output[key] = value;
    }
    return output;
  };
  var toHeaderMap = (headers) => {
    const map = {};
    if (!headers) return map;
    headers.forEach((h) => {
      if (!h.name) return;
      map[h.name.toLowerCase()] = String(h.value ?? "");
    });
    return map;
  };

  // src/devtools/index.ts
  chrome.devtools.panels.create("KZero Passwordless SSO Tracer", "", "panel.html", () => {
  });
  var tabId = chrome.devtools.inspectedWindow.tabId;
  var sendEvent = (event) => {
    chrome.runtime.sendMessage({
      type: "DEVTOOLS_NETWORK_EVENT",
      tabId,
      event
    });
  };
  chrome.devtools.network.onRequestFinished.addListener((request) => {
    request.getContent((content) => {
      const queryString = (request.request.queryString ?? []).map(
        (entry) => `${encodeURIComponent(entry.name)}=${encodeURIComponent(entry.value)}`
      );
      const event = {
        id: nowId(),
        tabId,
        source: "devtools-network",
        timestamp: request.startedDateTime ? Date.parse(request.startedDateTime) : Date.now(),
        url: request.request.url,
        method: request.request.method,
        statusCode: request.response.status,
        requestHeaders: toHeaderMap(request.request.headers),
        responseHeaders: toHeaderMap(request.response.headers),
        queryParams: parseQueryString(queryString.join("&")),
        postBody: request.request.postData?.text,
        responseBody: content,
        redirectUrl: request.response.redirectURL,
        timingMs: request.time,
        host: (() => {
          try {
            return new URL(request.request.url).host;
          } catch {
            return "";
          }
        })()
      };
      sendEvent(event);
    });
  });
})();
//# sourceMappingURL=devtools.js.map
