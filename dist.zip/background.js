var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/fast-xml-parser/src/util.js
var require_util = __commonJS({
  "node_modules/fast-xml-parser/src/util.js"(exports) {
    "use strict";
    var nameStartChar = ":A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD";
    var nameChar = nameStartChar + "\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040";
    var nameRegexp = "[" + nameStartChar + "][" + nameChar + "]*";
    var regexName = new RegExp("^" + nameRegexp + "$");
    var getAllMatches = function(string, regex) {
      const matches = [];
      let match = regex.exec(string);
      while (match) {
        const allmatches = [];
        allmatches.startIndex = regex.lastIndex - match[0].length;
        const len = match.length;
        for (let index = 0; index < len; index++) {
          allmatches.push(match[index]);
        }
        matches.push(allmatches);
        match = regex.exec(string);
      }
      return matches;
    };
    var isName = function(string) {
      const match = regexName.exec(string);
      return !(match === null || typeof match === "undefined");
    };
    exports.isExist = function(v) {
      return typeof v !== "undefined";
    };
    exports.isEmptyObject = function(obj) {
      return Object.keys(obj).length === 0;
    };
    exports.merge = function(target, a, arrayMode) {
      if (a) {
        const keys = Object.keys(a);
        const len = keys.length;
        for (let i = 0; i < len; i++) {
          if (arrayMode === "strict") {
            target[keys[i]] = [a[keys[i]]];
          } else {
            target[keys[i]] = a[keys[i]];
          }
        }
      }
    };
    exports.getValue = function(v) {
      if (exports.isExist(v)) {
        return v;
      } else {
        return "";
      }
    };
    var DANGEROUS_PROPERTY_NAMES = [
      // '__proto__',
      // 'constructor',
      // 'prototype',
      "hasOwnProperty",
      "toString",
      "valueOf",
      "__defineGetter__",
      "__defineSetter__",
      "__lookupGetter__",
      "__lookupSetter__"
    ];
    var criticalProperties = ["__proto__", "constructor", "prototype"];
    exports.isName = isName;
    exports.getAllMatches = getAllMatches;
    exports.nameRegexp = nameRegexp;
    exports.DANGEROUS_PROPERTY_NAMES = DANGEROUS_PROPERTY_NAMES;
    exports.criticalProperties = criticalProperties;
  }
});

// node_modules/fast-xml-parser/src/validator.js
var require_validator = __commonJS({
  "node_modules/fast-xml-parser/src/validator.js"(exports) {
    "use strict";
    var util = require_util();
    var defaultOptions = {
      allowBooleanAttributes: false,
      //A tag can have attributes without any value
      unpairedTags: []
    };
    exports.validate = function(xmlData, options) {
      options = Object.assign({}, defaultOptions, options);
      const tags = [];
      let tagFound = false;
      let reachedRoot = false;
      if (xmlData[0] === "\uFEFF") {
        xmlData = xmlData.substr(1);
      }
      for (let i = 0; i < xmlData.length; i++) {
        if (xmlData[i] === "<" && xmlData[i + 1] === "?") {
          i += 2;
          i = readPI(xmlData, i);
          if (i.err) return i;
        } else if (xmlData[i] === "<") {
          let tagStartPos = i;
          i++;
          if (xmlData[i] === "!") {
            i = readCommentAndCDATA(xmlData, i);
            continue;
          } else {
            let closingTag = false;
            if (xmlData[i] === "/") {
              closingTag = true;
              i++;
            }
            let tagName = "";
            for (; i < xmlData.length && xmlData[i] !== ">" && xmlData[i] !== " " && xmlData[i] !== "	" && xmlData[i] !== "\n" && xmlData[i] !== "\r"; i++) {
              tagName += xmlData[i];
            }
            tagName = tagName.trim();
            if (tagName[tagName.length - 1] === "/") {
              tagName = tagName.substring(0, tagName.length - 1);
              i--;
            }
            if (!validateTagName(tagName)) {
              let msg;
              if (tagName.trim().length === 0) {
                msg = "Invalid space after '<'.";
              } else {
                msg = "Tag '" + tagName + "' is an invalid name.";
              }
              return getErrorObject("InvalidTag", msg, getLineNumberForPosition(xmlData, i));
            }
            const result = readAttributeStr(xmlData, i);
            if (result === false) {
              return getErrorObject("InvalidAttr", "Attributes for '" + tagName + "' have open quote.", getLineNumberForPosition(xmlData, i));
            }
            let attrStr = result.value;
            i = result.index;
            if (attrStr[attrStr.length - 1] === "/") {
              const attrStrStart = i - attrStr.length;
              attrStr = attrStr.substring(0, attrStr.length - 1);
              const isValid = validateAttributeString(attrStr, options);
              if (isValid === true) {
                tagFound = true;
              } else {
                return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, attrStrStart + isValid.err.line));
              }
            } else if (closingTag) {
              if (!result.tagClosed) {
                return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' doesn't have proper closing.", getLineNumberForPosition(xmlData, i));
              } else if (attrStr.trim().length > 0) {
                return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' can't have attributes or invalid starting.", getLineNumberForPosition(xmlData, tagStartPos));
              } else if (tags.length === 0) {
                return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' has not been opened.", getLineNumberForPosition(xmlData, tagStartPos));
              } else {
                const otg = tags.pop();
                if (tagName !== otg.tagName) {
                  let openPos = getLineNumberForPosition(xmlData, otg.tagStartPos);
                  return getErrorObject(
                    "InvalidTag",
                    "Expected closing tag '" + otg.tagName + "' (opened in line " + openPos.line + ", col " + openPos.col + ") instead of closing tag '" + tagName + "'.",
                    getLineNumberForPosition(xmlData, tagStartPos)
                  );
                }
                if (tags.length == 0) {
                  reachedRoot = true;
                }
              }
            } else {
              const isValid = validateAttributeString(attrStr, options);
              if (isValid !== true) {
                return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
              }
              if (reachedRoot === true) {
                return getErrorObject("InvalidXml", "Multiple possible root nodes found.", getLineNumberForPosition(xmlData, i));
              } else if (options.unpairedTags.indexOf(tagName) !== -1) {
              } else {
                tags.push({ tagName, tagStartPos });
              }
              tagFound = true;
            }
            for (i++; i < xmlData.length; i++) {
              if (xmlData[i] === "<") {
                if (xmlData[i + 1] === "!") {
                  i++;
                  i = readCommentAndCDATA(xmlData, i);
                  continue;
                } else if (xmlData[i + 1] === "?") {
                  i = readPI(xmlData, ++i);
                  if (i.err) return i;
                } else {
                  break;
                }
              } else if (xmlData[i] === "&") {
                const afterAmp = validateAmpersand(xmlData, i);
                if (afterAmp == -1)
                  return getErrorObject("InvalidChar", "char '&' is not expected.", getLineNumberForPosition(xmlData, i));
                i = afterAmp;
              } else {
                if (reachedRoot === true && !isWhiteSpace(xmlData[i])) {
                  return getErrorObject("InvalidXml", "Extra text at the end", getLineNumberForPosition(xmlData, i));
                }
              }
            }
            if (xmlData[i] === "<") {
              i--;
            }
          }
        } else {
          if (isWhiteSpace(xmlData[i])) {
            continue;
          }
          return getErrorObject("InvalidChar", "char '" + xmlData[i] + "' is not expected.", getLineNumberForPosition(xmlData, i));
        }
      }
      if (!tagFound) {
        return getErrorObject("InvalidXml", "Start tag expected.", 1);
      } else if (tags.length == 1) {
        return getErrorObject("InvalidTag", "Unclosed tag '" + tags[0].tagName + "'.", getLineNumberForPosition(xmlData, tags[0].tagStartPos));
      } else if (tags.length > 0) {
        return getErrorObject("InvalidXml", "Invalid '" + JSON.stringify(tags.map((t) => t.tagName), null, 4).replace(/\r?\n/g, "") + "' found.", { line: 1, col: 1 });
      }
      return true;
    };
    function isWhiteSpace(char) {
      return char === " " || char === "	" || char === "\n" || char === "\r";
    }
    function readPI(xmlData, i) {
      const start = i;
      for (; i < xmlData.length; i++) {
        if (xmlData[i] == "?" || xmlData[i] == " ") {
          const tagname = xmlData.substr(start, i - start);
          if (i > 5 && tagname === "xml") {
            return getErrorObject("InvalidXml", "XML declaration allowed only at the start of the document.", getLineNumberForPosition(xmlData, i));
          } else if (xmlData[i] == "?" && xmlData[i + 1] == ">") {
            i++;
            break;
          } else {
            continue;
          }
        }
      }
      return i;
    }
    function readCommentAndCDATA(xmlData, i) {
      if (xmlData.length > i + 5 && xmlData[i + 1] === "-" && xmlData[i + 2] === "-") {
        for (i += 3; i < xmlData.length; i++) {
          if (xmlData[i] === "-" && xmlData[i + 1] === "-" && xmlData[i + 2] === ">") {
            i += 2;
            break;
          }
        }
      } else if (xmlData.length > i + 8 && xmlData[i + 1] === "D" && xmlData[i + 2] === "O" && xmlData[i + 3] === "C" && xmlData[i + 4] === "T" && xmlData[i + 5] === "Y" && xmlData[i + 6] === "P" && xmlData[i + 7] === "E") {
        let angleBracketsCount = 1;
        for (i += 8; i < xmlData.length; i++) {
          if (xmlData[i] === "<") {
            angleBracketsCount++;
          } else if (xmlData[i] === ">") {
            angleBracketsCount--;
            if (angleBracketsCount === 0) {
              break;
            }
          }
        }
      } else if (xmlData.length > i + 9 && xmlData[i + 1] === "[" && xmlData[i + 2] === "C" && xmlData[i + 3] === "D" && xmlData[i + 4] === "A" && xmlData[i + 5] === "T" && xmlData[i + 6] === "A" && xmlData[i + 7] === "[") {
        for (i += 8; i < xmlData.length; i++) {
          if (xmlData[i] === "]" && xmlData[i + 1] === "]" && xmlData[i + 2] === ">") {
            i += 2;
            break;
          }
        }
      }
      return i;
    }
    var doubleQuote = '"';
    var singleQuote = "'";
    function readAttributeStr(xmlData, i) {
      let attrStr = "";
      let startChar = "";
      let tagClosed = false;
      for (; i < xmlData.length; i++) {
        if (xmlData[i] === doubleQuote || xmlData[i] === singleQuote) {
          if (startChar === "") {
            startChar = xmlData[i];
          } else if (startChar !== xmlData[i]) {
          } else {
            startChar = "";
          }
        } else if (xmlData[i] === ">") {
          if (startChar === "") {
            tagClosed = true;
            break;
          }
        }
        attrStr += xmlData[i];
      }
      if (startChar !== "") {
        return false;
      }
      return {
        value: attrStr,
        index: i,
        tagClosed
      };
    }
    var validAttrStrRegxp = new RegExp(`(\\s*)([^\\s=]+)(\\s*=)?(\\s*(['"])(([\\s\\S])*?)\\5)?`, "g");
    function validateAttributeString(attrStr, options) {
      const matches = util.getAllMatches(attrStr, validAttrStrRegxp);
      const attrNames = {};
      for (let i = 0; i < matches.length; i++) {
        if (matches[i][1].length === 0) {
          return getErrorObject("InvalidAttr", "Attribute '" + matches[i][2] + "' has no space in starting.", getPositionFromMatch(matches[i]));
        } else if (matches[i][3] !== void 0 && matches[i][4] === void 0) {
          return getErrorObject("InvalidAttr", "Attribute '" + matches[i][2] + "' is without value.", getPositionFromMatch(matches[i]));
        } else if (matches[i][3] === void 0 && !options.allowBooleanAttributes) {
          return getErrorObject("InvalidAttr", "boolean attribute '" + matches[i][2] + "' is not allowed.", getPositionFromMatch(matches[i]));
        }
        const attrName = matches[i][2];
        if (!validateAttrName(attrName)) {
          return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is an invalid name.", getPositionFromMatch(matches[i]));
        }
        if (!attrNames.hasOwnProperty(attrName)) {
          attrNames[attrName] = 1;
        } else {
          return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is repeated.", getPositionFromMatch(matches[i]));
        }
      }
      return true;
    }
    function validateNumberAmpersand(xmlData, i) {
      let re = /\d/;
      if (xmlData[i] === "x") {
        i++;
        re = /[\da-fA-F]/;
      }
      for (; i < xmlData.length; i++) {
        if (xmlData[i] === ";")
          return i;
        if (!xmlData[i].match(re))
          break;
      }
      return -1;
    }
    function validateAmpersand(xmlData, i) {
      i++;
      if (xmlData[i] === ";")
        return -1;
      if (xmlData[i] === "#") {
        i++;
        return validateNumberAmpersand(xmlData, i);
      }
      let count = 0;
      for (; i < xmlData.length; i++, count++) {
        if (xmlData[i].match(/\w/) && count < 20)
          continue;
        if (xmlData[i] === ";")
          break;
        return -1;
      }
      return i;
    }
    function getErrorObject(code, message, lineNumber) {
      return {
        err: {
          code,
          msg: message,
          line: lineNumber.line || lineNumber,
          col: lineNumber.col
        }
      };
    }
    function validateAttrName(attrName) {
      return util.isName(attrName);
    }
    function validateTagName(tagname) {
      return util.isName(tagname);
    }
    function getLineNumberForPosition(xmlData, index) {
      const lines = xmlData.substring(0, index).split(/\r?\n/);
      return {
        line: lines.length,
        // column number is last line's length + 1, because column numbering starts at 1:
        col: lines[lines.length - 1].length + 1
      };
    }
    function getPositionFromMatch(match) {
      return match.startIndex + match[1].length;
    }
  }
});

// node_modules/fast-xml-parser/src/xmlparser/OptionsBuilder.js
var require_OptionsBuilder = __commonJS({
  "node_modules/fast-xml-parser/src/xmlparser/OptionsBuilder.js"(exports) {
    var { DANGEROUS_PROPERTY_NAMES, criticalProperties } = require_util();
    var defaultOnDangerousProperty = (name) => {
      if (DANGEROUS_PROPERTY_NAMES.includes(name)) {
        return "__" + name;
      }
      return name;
    };
    var defaultOptions = {
      preserveOrder: false,
      attributeNamePrefix: "@_",
      attributesGroupName: false,
      textNodeName: "#text",
      ignoreAttributes: true,
      removeNSPrefix: false,
      // remove NS from tag name or attribute name if true
      allowBooleanAttributes: false,
      //a tag can have attributes without any value
      //ignoreRootElement : false,
      parseTagValue: true,
      parseAttributeValue: false,
      trimValues: true,
      //Trim string values of tag and attributes
      cdataPropName: false,
      numberParseOptions: {
        hex: true,
        leadingZeros: true,
        eNotation: true
      },
      tagValueProcessor: function(tagName, val) {
        return val;
      },
      attributeValueProcessor: function(attrName, val) {
        return val;
      },
      stopNodes: [],
      //nested tags will not be parsed even for errors
      alwaysCreateTextNode: false,
      isArray: () => false,
      commentPropName: false,
      unpairedTags: [],
      processEntities: true,
      htmlEntities: false,
      ignoreDeclaration: false,
      ignorePiTags: false,
      transformTagName: false,
      transformAttributeName: false,
      updateTag: function(tagName, jPath, attrs) {
        return tagName;
      },
      // skipEmptyListItem: false
      captureMetaData: false,
      maxNestedTags: 100,
      strictReservedNames: true,
      onDangerousProperty: defaultOnDangerousProperty
    };
    function validatePropertyName(propertyName, optionName) {
      if (typeof propertyName !== "string") {
        return;
      }
      const normalized = propertyName.toLowerCase();
      if (DANGEROUS_PROPERTY_NAMES.some((dangerous) => normalized === dangerous.toLowerCase())) {
        throw new Error(
          `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
        );
      }
      if (criticalProperties.some((dangerous) => normalized === dangerous.toLowerCase())) {
        throw new Error(
          `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
        );
      }
    }
    function normalizeProcessEntities(value) {
      if (typeof value === "boolean") {
        return {
          enabled: value,
          // true or false
          maxEntitySize: 1e4,
          maxExpansionDepth: 10,
          maxTotalExpansions: 1e3,
          maxExpandedLength: 1e5,
          allowedTags: null,
          tagFilter: null
        };
      }
      if (typeof value === "object" && value !== null) {
        return {
          enabled: value.enabled !== false,
          maxEntitySize: Math.max(1, value.maxEntitySize ?? 1e4),
          maxExpansionDepth: Math.max(1, value.maxExpansionDepth ?? 10),
          maxTotalExpansions: Math.max(1, value.maxTotalExpansions ?? 1e3),
          maxExpandedLength: Math.max(1, value.maxExpandedLength ?? 1e5),
          maxEntityCount: Math.max(1, value.maxEntityCount ?? 100),
          allowedTags: value.allowedTags ?? null,
          tagFilter: value.tagFilter ?? null
        };
      }
      return normalizeProcessEntities(true);
    }
    var buildOptions = function(options) {
      const built = Object.assign({}, defaultOptions, options);
      const propertyNameOptions = [
        { value: built.attributeNamePrefix, name: "attributeNamePrefix" },
        { value: built.attributesGroupName, name: "attributesGroupName" },
        { value: built.textNodeName, name: "textNodeName" },
        { value: built.cdataPropName, name: "cdataPropName" },
        { value: built.commentPropName, name: "commentPropName" }
      ];
      for (const { value, name } of propertyNameOptions) {
        if (value) {
          validatePropertyName(value, name);
        }
      }
      if (built.onDangerousProperty === null) {
        built.onDangerousProperty = defaultOnDangerousProperty;
      }
      built.processEntities = normalizeProcessEntities(built.processEntities);
      return built;
    };
    exports.buildOptions = buildOptions;
    exports.defaultOptions = defaultOptions;
  }
});

// node_modules/fast-xml-parser/src/xmlparser/xmlNode.js
var require_xmlNode = __commonJS({
  "node_modules/fast-xml-parser/src/xmlparser/xmlNode.js"(exports, module) {
    "use strict";
    var XmlNode = class {
      constructor(tagname) {
        this.tagname = tagname;
        this.child = [];
        this[":@"] = {};
      }
      add(key, val) {
        if (key === "__proto__") key = "#__proto__";
        this.child.push({ [key]: val });
      }
      addChild(node) {
        if (node.tagname === "__proto__") node.tagname = "#__proto__";
        if (node[":@"] && Object.keys(node[":@"]).length > 0) {
          this.child.push({ [node.tagname]: node.child, [":@"]: node[":@"] });
        } else {
          this.child.push({ [node.tagname]: node.child });
        }
      }
    };
    module.exports = XmlNode;
  }
});

// node_modules/fast-xml-parser/src/xmlparser/DocTypeReader.js
var require_DocTypeReader = __commonJS({
  "node_modules/fast-xml-parser/src/xmlparser/DocTypeReader.js"(exports, module) {
    var util = require_util();
    var DocTypeReader = class {
      constructor(options) {
        this.suppressValidationErr = !options;
        this.options = options || {};
      }
      readDocType(xmlData, i) {
        const entities = /* @__PURE__ */ Object.create(null);
        let entityCount = 0;
        if (xmlData[i + 3] === "O" && xmlData[i + 4] === "C" && xmlData[i + 5] === "T" && xmlData[i + 6] === "Y" && xmlData[i + 7] === "P" && xmlData[i + 8] === "E") {
          i = i + 9;
          let angleBracketsCount = 1;
          let hasBody = false, comment = false;
          let exp = "";
          for (; i < xmlData.length; i++) {
            if (xmlData[i] === "<" && !comment) {
              if (hasBody && hasSeq(xmlData, "!ENTITY", i)) {
                i += 7;
                let entityName, val;
                [entityName, val, i] = this.readEntityExp(xmlData, i + 1, this.suppressValidationErr);
                if (val.indexOf("&") === -1) {
                  if (this.options.enabled !== false && this.options.maxEntityCount != null && entityCount >= this.options.maxEntityCount) {
                    throw new Error(
                      `Entity count (${entityCount + 1}) exceeds maximum allowed (${this.options.maxEntityCount})`
                    );
                  }
                  const escaped = entityName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
                  entities[entityName] = {
                    regx: RegExp(`&${escaped};`, "g"),
                    val
                  };
                  entityCount++;
                }
              } else if (hasBody && hasSeq(xmlData, "!ELEMENT", i)) {
                i += 8;
                const { index } = this.readElementExp(xmlData, i + 1);
                i = index;
              } else if (hasBody && hasSeq(xmlData, "!ATTLIST", i)) {
                i += 8;
              } else if (hasBody && hasSeq(xmlData, "!NOTATION", i)) {
                i += 9;
                const { index } = this.readNotationExp(xmlData, i + 1, this.suppressValidationErr);
                i = index;
              } else if (hasSeq(xmlData, "!--", i)) {
                comment = true;
              } else {
                throw new Error(`Invalid DOCTYPE`);
              }
              angleBracketsCount++;
              exp = "";
            } else if (xmlData[i] === ">") {
              if (comment) {
                if (xmlData[i - 1] === "-" && xmlData[i - 2] === "-") {
                  comment = false;
                  angleBracketsCount--;
                }
              } else {
                angleBracketsCount--;
              }
              if (angleBracketsCount === 0) {
                break;
              }
            } else if (xmlData[i] === "[") {
              hasBody = true;
            } else {
              exp += xmlData[i];
            }
          }
          if (angleBracketsCount !== 0) {
            throw new Error(`Unclosed DOCTYPE`);
          }
        } else {
          throw new Error(`Invalid Tag instead of DOCTYPE`);
        }
        return { entities, i };
      }
      readEntityExp(xmlData, i) {
        i = skipWhitespace(xmlData, i);
        let entityName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i]) && xmlData[i] !== '"' && xmlData[i] !== "'") {
          entityName += xmlData[i];
          i++;
        }
        validateEntityName(entityName);
        i = skipWhitespace(xmlData, i);
        if (!this.suppressValidationErr) {
          if (xmlData.substring(i, i + 6).toUpperCase() === "SYSTEM") {
            throw new Error("External entities are not supported");
          } else if (xmlData[i] === "%") {
            throw new Error("Parameter entities are not supported");
          }
        }
        let entityValue = "";
        [i, entityValue] = this.readIdentifierVal(xmlData, i, "entity");
        if (this.options.enabled !== false && this.options.maxEntitySize != null && entityValue.length > this.options.maxEntitySize) {
          throw new Error(
            `Entity "${entityName}" size (${entityValue.length}) exceeds maximum allowed size (${this.options.maxEntitySize})`
          );
        }
        i--;
        return [entityName, entityValue, i];
      }
      readNotationExp(xmlData, i) {
        i = skipWhitespace(xmlData, i);
        let notationName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
          notationName += xmlData[i];
          i++;
        }
        !this.suppressValidationErr && validateEntityName(notationName);
        i = skipWhitespace(xmlData, i);
        const identifierType = xmlData.substring(i, i + 6).toUpperCase();
        if (!this.suppressValidationErr && identifierType !== "SYSTEM" && identifierType !== "PUBLIC") {
          throw new Error(`Expected SYSTEM or PUBLIC, found "${identifierType}"`);
        }
        i += identifierType.length;
        i = skipWhitespace(xmlData, i);
        let publicIdentifier = null;
        let systemIdentifier = null;
        if (identifierType === "PUBLIC") {
          [i, publicIdentifier] = this.readIdentifierVal(xmlData, i, "publicIdentifier");
          i = skipWhitespace(xmlData, i);
          if (xmlData[i] === '"' || xmlData[i] === "'") {
            [i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");
          }
        } else if (identifierType === "SYSTEM") {
          [i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");
          if (!this.suppressValidationErr && !systemIdentifier) {
            throw new Error("Missing mandatory system identifier for SYSTEM notation");
          }
        }
        return { notationName, publicIdentifier, systemIdentifier, index: --i };
      }
      readIdentifierVal(xmlData, i, type) {
        let identifierVal = "";
        const startChar = xmlData[i];
        if (startChar !== '"' && startChar !== "'") {
          throw new Error(`Expected quoted string, found "${startChar}"`);
        }
        i++;
        while (i < xmlData.length && xmlData[i] !== startChar) {
          identifierVal += xmlData[i];
          i++;
        }
        if (xmlData[i] !== startChar) {
          throw new Error(`Unterminated ${type} value`);
        }
        i++;
        return [i, identifierVal];
      }
      readElementExp(xmlData, i) {
        i = skipWhitespace(xmlData, i);
        let elementName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
          elementName += xmlData[i];
          i++;
        }
        if (!this.suppressValidationErr && !util.isName(elementName)) {
          throw new Error(`Invalid element name: "${elementName}"`);
        }
        i = skipWhitespace(xmlData, i);
        let contentModel = "";
        if (xmlData[i] === "E" && hasSeq(xmlData, "MPTY", i)) {
          i += 4;
        } else if (xmlData[i] === "A" && hasSeq(xmlData, "NY", i)) {
          i += 2;
        } else if (xmlData[i] === "(") {
          i++;
          while (i < xmlData.length && xmlData[i] !== ")") {
            contentModel += xmlData[i];
            i++;
          }
          if (xmlData[i] !== ")") {
            throw new Error("Unterminated content model");
          }
        } else if (!this.suppressValidationErr) {
          throw new Error(`Invalid Element Expression, found "${xmlData[i]}"`);
        }
        return {
          elementName,
          contentModel: contentModel.trim(),
          index: i
        };
      }
      readAttlistExp(xmlData, i) {
        i = skipWhitespace(xmlData, i);
        let elementName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
          elementName += xmlData[i];
          i++;
        }
        validateEntityName(elementName);
        i = skipWhitespace(xmlData, i);
        let attributeName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
          attributeName += xmlData[i];
          i++;
        }
        if (!validateEntityName(attributeName)) {
          throw new Error(`Invalid attribute name: "${attributeName}"`);
        }
        i = skipWhitespace(xmlData, i);
        let attributeType = "";
        if (xmlData.substring(i, i + 8).toUpperCase() === "NOTATION") {
          attributeType = "NOTATION";
          i += 8;
          i = skipWhitespace(xmlData, i);
          if (xmlData[i] !== "(") {
            throw new Error(`Expected '(', found "${xmlData[i]}"`);
          }
          i++;
          let allowedNotations = [];
          while (i < xmlData.length && xmlData[i] !== ")") {
            let notation = "";
            while (i < xmlData.length && xmlData[i] !== "|" && xmlData[i] !== ")") {
              notation += xmlData[i];
              i++;
            }
            notation = notation.trim();
            if (!validateEntityName(notation)) {
              throw new Error(`Invalid notation name: "${notation}"`);
            }
            allowedNotations.push(notation);
            if (xmlData[i] === "|") {
              i++;
              i = skipWhitespace(xmlData, i);
            }
          }
          if (xmlData[i] !== ")") {
            throw new Error("Unterminated list of notations");
          }
          i++;
          attributeType += " (" + allowedNotations.join("|") + ")";
        } else {
          while (i < xmlData.length && !/\s/.test(xmlData[i])) {
            attributeType += xmlData[i];
            i++;
          }
          const validTypes = ["CDATA", "ID", "IDREF", "IDREFS", "ENTITY", "ENTITIES", "NMTOKEN", "NMTOKENS"];
          if (!this.suppressValidationErr && !validTypes.includes(attributeType.toUpperCase())) {
            throw new Error(`Invalid attribute type: "${attributeType}"`);
          }
        }
        i = skipWhitespace(xmlData, i);
        let defaultValue = "";
        if (xmlData.substring(i, i + 8).toUpperCase() === "#REQUIRED") {
          defaultValue = "#REQUIRED";
          i += 8;
        } else if (xmlData.substring(i, i + 7).toUpperCase() === "#IMPLIED") {
          defaultValue = "#IMPLIED";
          i += 7;
        } else {
          [i, defaultValue] = this.readIdentifierVal(xmlData, i, "ATTLIST");
        }
        return {
          elementName,
          attributeName,
          attributeType,
          defaultValue,
          index: i
        };
      }
    };
    var skipWhitespace = (data, index) => {
      while (index < data.length && /\s/.test(data[index])) {
        index++;
      }
      return index;
    };
    function hasSeq(data, seq, i) {
      for (let j = 0; j < seq.length; j++) {
        if (seq[j] !== data[i + j + 1]) return false;
      }
      return true;
    }
    function validateEntityName(name) {
      if (util.isName(name))
        return name;
      else
        throw new Error(`Invalid entity name ${name}`);
    }
    module.exports = DocTypeReader;
  }
});

// node_modules/strnum/strnum.js
var require_strnum = __commonJS({
  "node_modules/strnum/strnum.js"(exports, module) {
    var hexRegex = /^[-+]?0x[a-fA-F0-9]+$/;
    var numRegex = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/;
    var consider = {
      hex: true,
      // oct: false,
      leadingZeros: true,
      decimalPoint: ".",
      eNotation: true
      //skipLike: /regex/
    };
    function toNumber(str, options = {}) {
      options = Object.assign({}, consider, options);
      if (!str || typeof str !== "string") return str;
      let trimmedStr = str.trim();
      if (options.skipLike !== void 0 && options.skipLike.test(trimmedStr)) return str;
      else if (str === "0") return 0;
      else if (options.hex && hexRegex.test(trimmedStr)) {
        return parse_int(trimmedStr, 16);
      } else if (trimmedStr.search(/[eE]/) !== -1) {
        const notation = trimmedStr.match(/^([-\+])?(0*)([0-9]*(\.[0-9]*)?[eE][-\+]?[0-9]+)$/);
        if (notation) {
          if (options.leadingZeros) {
            trimmedStr = (notation[1] || "") + notation[3];
          } else {
            if (notation[2] === "0" && notation[3][0] === ".") {
            } else {
              return str;
            }
          }
          return options.eNotation ? Number(trimmedStr) : str;
        } else {
          return str;
        }
      } else {
        const match = numRegex.exec(trimmedStr);
        if (match) {
          const sign = match[1];
          const leadingZeros = match[2];
          let numTrimmedByZeros = trimZeros(match[3]);
          if (!options.leadingZeros && leadingZeros.length > 0 && sign && trimmedStr[2] !== ".") return str;
          else if (!options.leadingZeros && leadingZeros.length > 0 && !sign && trimmedStr[1] !== ".") return str;
          else if (options.leadingZeros && leadingZeros === str) return 0;
          else {
            const num = Number(trimmedStr);
            const numStr = "" + num;
            if (numStr.search(/[eE]/) !== -1) {
              if (options.eNotation) return num;
              else return str;
            } else if (trimmedStr.indexOf(".") !== -1) {
              if (numStr === "0" && numTrimmedByZeros === "") return num;
              else if (numStr === numTrimmedByZeros) return num;
              else if (sign && numStr === "-" + numTrimmedByZeros) return num;
              else return str;
            }
            if (leadingZeros) {
              return numTrimmedByZeros === numStr || sign + numTrimmedByZeros === numStr ? num : str;
            } else {
              return trimmedStr === numStr || trimmedStr === sign + numStr ? num : str;
            }
          }
        } else {
          return str;
        }
      }
    }
    function trimZeros(numStr) {
      if (numStr && numStr.indexOf(".") !== -1) {
        numStr = numStr.replace(/0+$/, "");
        if (numStr === ".") numStr = "0";
        else if (numStr[0] === ".") numStr = "0" + numStr;
        else if (numStr[numStr.length - 1] === ".") numStr = numStr.substr(0, numStr.length - 1);
        return numStr;
      }
      return numStr;
    }
    function parse_int(numStr, base) {
      if (parseInt) return parseInt(numStr, base);
      else if (Number.parseInt) return Number.parseInt(numStr, base);
      else if (window && window.parseInt) return window.parseInt(numStr, base);
      else throw new Error("parseInt, Number.parseInt, window.parseInt are not supported");
    }
    module.exports = toNumber;
  }
});

// node_modules/fast-xml-parser/src/ignoreAttributes.js
var require_ignoreAttributes = __commonJS({
  "node_modules/fast-xml-parser/src/ignoreAttributes.js"(exports, module) {
    function getIgnoreAttributesFn(ignoreAttributes) {
      if (typeof ignoreAttributes === "function") {
        return ignoreAttributes;
      }
      if (Array.isArray(ignoreAttributes)) {
        return (attrName) => {
          for (const pattern of ignoreAttributes) {
            if (typeof pattern === "string" && attrName === pattern) {
              return true;
            }
            if (pattern instanceof RegExp && pattern.test(attrName)) {
              return true;
            }
          }
        };
      }
      return () => false;
    }
    module.exports = getIgnoreAttributesFn;
  }
});

// node_modules/fast-xml-parser/src/xmlparser/OrderedObjParser.js
var require_OrderedObjParser = __commonJS({
  "node_modules/fast-xml-parser/src/xmlparser/OrderedObjParser.js"(exports, module) {
    "use strict";
    var util = require_util();
    var xmlNode = require_xmlNode();
    var DocTypeReader = require_DocTypeReader();
    var toNumber = require_strnum();
    var getIgnoreAttributesFn = require_ignoreAttributes();
    var OrderedObjParser = class {
      constructor(options) {
        this.options = options;
        this.currentNode = null;
        this.tagsNodeStack = [];
        this.docTypeEntities = {};
        this.lastEntities = {
          "apos": { regex: /&(apos|#39|#x27);/g, val: "'" },
          "gt": { regex: /&(gt|#62|#x3E);/g, val: ">" },
          "lt": { regex: /&(lt|#60|#x3C);/g, val: "<" },
          "quot": { regex: /&(quot|#34|#x22);/g, val: '"' }
        };
        this.ampEntity = { regex: /&(amp|#38|#x26);/g, val: "&" };
        this.htmlEntities = {
          "space": { regex: /&(nbsp|#160);/g, val: " " },
          // "lt" : { regex: /&(lt|#60);/g, val: "<" },
          // "gt" : { regex: /&(gt|#62);/g, val: ">" },
          // "amp" : { regex: /&(amp|#38);/g, val: "&" },
          // "quot" : { regex: /&(quot|#34);/g, val: "\"" },
          // "apos" : { regex: /&(apos|#39);/g, val: "'" },
          "cent": { regex: /&(cent|#162);/g, val: "\xA2" },
          "pound": { regex: /&(pound|#163);/g, val: "\xA3" },
          "yen": { regex: /&(yen|#165);/g, val: "\xA5" },
          "euro": { regex: /&(euro|#8364);/g, val: "\u20AC" },
          "copyright": { regex: /&(copy|#169);/g, val: "\xA9" },
          "reg": { regex: /&(reg|#174);/g, val: "\xAE" },
          "inr": { regex: /&(inr|#8377);/g, val: "\u20B9" },
          "num_dec": { regex: /&#([0-9]{1,7});/g, val: (_, str) => fromCodePoint(str, 10, "&#") },
          "num_hex": { regex: /&#x([0-9a-fA-F]{1,6});/g, val: (_, str) => fromCodePoint(str, 16, "&#x") }
        };
        this.addExternalEntities = addExternalEntities;
        this.parseXml = parseXml;
        this.parseTextData = parseTextData;
        this.resolveNameSpace = resolveNameSpace;
        this.buildAttributesMap = buildAttributesMap;
        this.isItStopNode = isItStopNode;
        this.replaceEntitiesValue = replaceEntitiesValue;
        this.readStopNodeData = readStopNodeData;
        this.saveTextToParentTag = saveTextToParentTag;
        this.addChild = addChild;
        this.ignoreAttributesFn = getIgnoreAttributesFn(this.options.ignoreAttributes);
        this.entityExpansionCount = 0;
        this.currentExpandedLength = 0;
        if (this.options.stopNodes && this.options.stopNodes.length > 0) {
          this.stopNodesExact = /* @__PURE__ */ new Set();
          this.stopNodesWildcard = /* @__PURE__ */ new Set();
          for (let i = 0; i < this.options.stopNodes.length; i++) {
            const stopNodeExp = this.options.stopNodes[i];
            if (typeof stopNodeExp !== "string") continue;
            if (stopNodeExp.startsWith("*.")) {
              this.stopNodesWildcard.add(stopNodeExp.substring(2));
            } else {
              this.stopNodesExact.add(stopNodeExp);
            }
          }
        }
      }
    };
    function addExternalEntities(externalEntities) {
      const entKeys = Object.keys(externalEntities);
      for (let i = 0; i < entKeys.length; i++) {
        const ent = entKeys[i];
        const escaped = ent.replace(/[.\-+*:]/g, "\\.");
        this.lastEntities[ent] = {
          regex: new RegExp("&" + escaped + ";", "g"),
          val: externalEntities[ent]
        };
      }
    }
    function parseTextData(val, tagName, jPath, dontTrim, hasAttributes, isLeafNode, escapeEntities) {
      if (val !== void 0) {
        if (this.options.trimValues && !dontTrim) {
          val = val.trim();
        }
        if (val.length > 0) {
          if (!escapeEntities) val = this.replaceEntitiesValue(val, tagName, jPath);
          const newval = this.options.tagValueProcessor(tagName, val, jPath, hasAttributes, isLeafNode);
          if (newval === null || newval === void 0) {
            return val;
          } else if (typeof newval !== typeof val || newval !== val) {
            return newval;
          } else if (this.options.trimValues) {
            return parseValue(val, this.options.parseTagValue, this.options.numberParseOptions);
          } else {
            const trimmedVal = val.trim();
            if (trimmedVal === val) {
              return parseValue(val, this.options.parseTagValue, this.options.numberParseOptions);
            } else {
              return val;
            }
          }
        }
      }
    }
    function resolveNameSpace(tagname) {
      if (this.options.removeNSPrefix) {
        const tags = tagname.split(":");
        const prefix = tagname.charAt(0) === "/" ? "/" : "";
        if (tags[0] === "xmlns") {
          return "";
        }
        if (tags.length === 2) {
          tagname = prefix + tags[1];
        }
      }
      return tagname;
    }
    var attrsRegx = new RegExp(`([^\\s=]+)\\s*(=\\s*(['"])([\\s\\S]*?)\\3)?`, "gm");
    function buildAttributesMap(attrStr, jPath, tagName) {
      if (this.options.ignoreAttributes !== true && typeof attrStr === "string") {
        const matches = util.getAllMatches(attrStr, attrsRegx);
        const len = matches.length;
        const attrs = {};
        for (let i = 0; i < len; i++) {
          const attrName = this.resolveNameSpace(matches[i][1]);
          if (this.ignoreAttributesFn(attrName, jPath)) {
            continue;
          }
          let oldVal = matches[i][4];
          let aName = this.options.attributeNamePrefix + attrName;
          if (attrName.length) {
            if (this.options.transformAttributeName) {
              aName = this.options.transformAttributeName(aName);
            }
            aName = sanitizeName(aName, this.options);
            if (oldVal !== void 0) {
              if (this.options.trimValues) {
                oldVal = oldVal.trim();
              }
              oldVal = this.replaceEntitiesValue(oldVal, tagName, jPath);
              const newVal = this.options.attributeValueProcessor(attrName, oldVal, jPath);
              if (newVal === null || newVal === void 0) {
                attrs[aName] = oldVal;
              } else if (typeof newVal !== typeof oldVal || newVal !== oldVal) {
                attrs[aName] = newVal;
              } else {
                attrs[aName] = parseValue(
                  oldVal,
                  this.options.parseAttributeValue,
                  this.options.numberParseOptions
                );
              }
            } else if (this.options.allowBooleanAttributes) {
              attrs[aName] = true;
            }
          }
        }
        if (!Object.keys(attrs).length) {
          return;
        }
        if (this.options.attributesGroupName) {
          const attrCollection = {};
          attrCollection[this.options.attributesGroupName] = attrs;
          return attrCollection;
        }
        return attrs;
      }
    }
    var parseXml = function(xmlData) {
      xmlData = xmlData.replace(/\r\n?/g, "\n");
      const xmlObj = new xmlNode("!xml");
      let currentNode = xmlObj;
      let textData = "";
      let jPath = "";
      this.entityExpansionCount = 0;
      this.currentExpandedLength = 0;
      const docTypeReader = new DocTypeReader(this.options.processEntities);
      for (let i = 0; i < xmlData.length; i++) {
        const ch = xmlData[i];
        if (ch === "<") {
          if (xmlData[i + 1] === "/") {
            const closeIndex = findClosingIndex(xmlData, ">", i, "Closing Tag is not closed.");
            let tagName = xmlData.substring(i + 2, closeIndex).trim();
            if (this.options.removeNSPrefix) {
              const colonIndex = tagName.indexOf(":");
              if (colonIndex !== -1) {
                tagName = tagName.substr(colonIndex + 1);
              }
            }
            if (this.options.transformTagName) {
              tagName = this.options.transformTagName(tagName);
            }
            if (currentNode) {
              textData = this.saveTextToParentTag(textData, currentNode, jPath);
            }
            const lastTagName = jPath.substring(jPath.lastIndexOf(".") + 1);
            if (tagName && this.options.unpairedTags.indexOf(tagName) !== -1) {
              throw new Error(`Unpaired tag can not be used as closing tag: </${tagName}>`);
            }
            let propIndex = 0;
            if (lastTagName && this.options.unpairedTags.indexOf(lastTagName) !== -1) {
              propIndex = jPath.lastIndexOf(".", jPath.lastIndexOf(".") - 1);
              this.tagsNodeStack.pop();
            } else {
              propIndex = jPath.lastIndexOf(".");
            }
            jPath = jPath.substring(0, propIndex);
            currentNode = this.tagsNodeStack.pop();
            textData = "";
            i = closeIndex;
          } else if (xmlData[i + 1] === "?") {
            let tagData = readTagExp(xmlData, i, false, "?>");
            if (!tagData) throw new Error("Pi Tag is not closed.");
            textData = this.saveTextToParentTag(textData, currentNode, jPath);
            if (this.options.ignoreDeclaration && tagData.tagName === "?xml" || this.options.ignorePiTags) {
            } else {
              const childNode = new xmlNode(tagData.tagName);
              childNode.add(this.options.textNodeName, "");
              if (tagData.tagName !== tagData.tagExp && tagData.attrExpPresent) {
                childNode[":@"] = this.buildAttributesMap(tagData.tagExp, jPath, tagData.tagName);
              }
              this.addChild(currentNode, childNode, jPath, i);
            }
            i = tagData.closeIndex + 1;
          } else if (xmlData.substr(i + 1, 3) === "!--") {
            const endIndex = findClosingIndex(xmlData, "-->", i + 4, "Comment is not closed.");
            if (this.options.commentPropName) {
              const comment = xmlData.substring(i + 4, endIndex - 2);
              textData = this.saveTextToParentTag(textData, currentNode, jPath);
              currentNode.add(this.options.commentPropName, [{ [this.options.textNodeName]: comment }]);
            }
            i = endIndex;
          } else if (xmlData.substr(i + 1, 2) === "!D") {
            const result = docTypeReader.readDocType(xmlData, i);
            this.docTypeEntities = result.entities;
            i = result.i;
          } else if (xmlData.substr(i + 1, 2) === "![") {
            const closeIndex = findClosingIndex(xmlData, "]]>", i, "CDATA is not closed.") - 2;
            const tagExp = xmlData.substring(i + 9, closeIndex);
            textData = this.saveTextToParentTag(textData, currentNode, jPath);
            let val = this.parseTextData(tagExp, currentNode.tagname, jPath, true, false, true, true);
            if (val == void 0) val = "";
            if (this.options.cdataPropName) {
              currentNode.add(this.options.cdataPropName, [{ [this.options.textNodeName]: tagExp }]);
            } else {
              currentNode.add(this.options.textNodeName, val);
            }
            i = closeIndex + 2;
          } else {
            let result = readTagExp(xmlData, i, this.options.removeNSPrefix);
            let tagName = result.tagName;
            const rawTagName = result.rawTagName;
            let tagExp = result.tagExp;
            let attrExpPresent = result.attrExpPresent;
            let closeIndex = result.closeIndex;
            if (this.options.transformTagName) {
              const newTagName = this.options.transformTagName(tagName);
              if (tagExp === tagName) {
                tagExp = newTagName;
              }
              tagName = newTagName;
            }
            if (this.options.strictReservedNames && (tagName === this.options.commentPropName || tagName === this.options.cdataPropName || tagName === this.options.textNodeName || tagName === this.options.attributesGroupName)) {
              throw new Error(`Invalid tag name: ${tagName}`);
            }
            if (currentNode && textData) {
              if (currentNode.tagname !== "!xml") {
                textData = this.saveTextToParentTag(textData, currentNode, jPath, false);
              }
            }
            const lastTag = currentNode;
            if (lastTag && this.options.unpairedTags.indexOf(lastTag.tagname) !== -1) {
              currentNode = this.tagsNodeStack.pop();
              jPath = jPath.substring(0, jPath.lastIndexOf("."));
            }
            if (tagName !== xmlObj.tagname) {
              jPath += jPath ? "." + tagName : tagName;
            }
            const startIndex = i;
            if (this.isItStopNode(this.stopNodesExact, this.stopNodesWildcard, jPath, tagName)) {
              let tagContent = "";
              if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
                if (tagName[tagName.length - 1] === "/") {
                  tagName = tagName.substr(0, tagName.length - 1);
                  jPath = jPath.substr(0, jPath.length - 1);
                  tagExp = tagName;
                } else {
                  tagExp = tagExp.substr(0, tagExp.length - 1);
                }
                i = result.closeIndex;
              } else if (this.options.unpairedTags.indexOf(tagName) !== -1) {
                i = result.closeIndex;
              } else {
                const result2 = this.readStopNodeData(xmlData, rawTagName, closeIndex + 1);
                if (!result2) throw new Error(`Unexpected end of ${rawTagName}`);
                i = result2.i;
                tagContent = result2.tagContent;
              }
              const childNode = new xmlNode(tagName);
              if (tagName !== tagExp && attrExpPresent) {
                childNode[":@"] = this.buildAttributesMap(tagExp, jPath, tagName);
              }
              if (tagContent) {
                tagContent = this.parseTextData(tagContent, tagName, jPath, true, attrExpPresent, true, true);
              }
              jPath = jPath.substr(0, jPath.lastIndexOf("."));
              childNode.add(this.options.textNodeName, tagContent);
              this.addChild(currentNode, childNode, jPath, startIndex);
            } else {
              if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
                if (tagName[tagName.length - 1] === "/") {
                  tagName = tagName.substr(0, tagName.length - 1);
                  jPath = jPath.substr(0, jPath.length - 1);
                  tagExp = tagName;
                } else {
                  tagExp = tagExp.substr(0, tagExp.length - 1);
                }
                if (this.options.transformTagName) {
                  const newTagName = this.options.transformTagName(tagName);
                  if (tagExp === tagName) {
                    tagExp = newTagName;
                  }
                  tagName = newTagName;
                }
                const childNode = new xmlNode(tagName);
                if (tagName !== tagExp && attrExpPresent) {
                  childNode[":@"] = this.buildAttributesMap(tagExp, jPath, tagName);
                }
                this.addChild(currentNode, childNode, jPath, startIndex);
                jPath = jPath.substr(0, jPath.lastIndexOf("."));
              } else if (this.options.unpairedTags.indexOf(tagName) !== -1) {
                const childNode = new xmlNode(tagName);
                if (tagName !== tagExp && attrExpPresent) {
                  childNode[":@"] = this.buildAttributesMap(tagExp, jPath);
                }
                this.addChild(currentNode, childNode, jPath, startIndex);
                jPath = jPath.substr(0, jPath.lastIndexOf("."));
                i = result.closeIndex;
                continue;
              } else {
                const childNode = new xmlNode(tagName);
                if (this.tagsNodeStack.length > this.options.maxNestedTags) {
                  throw new Error("Maximum nested tags exceeded");
                }
                this.tagsNodeStack.push(currentNode);
                if (tagName !== tagExp && attrExpPresent) {
                  childNode[":@"] = this.buildAttributesMap(tagExp, jPath, tagName);
                }
                this.addChild(currentNode, childNode, jPath);
                currentNode = childNode;
              }
              textData = "";
              i = closeIndex;
            }
          }
        } else {
          textData += xmlData[i];
        }
      }
      return xmlObj.child;
    };
    function addChild(currentNode, childNode, jPath, startIndex) {
      if (!this.options.captureMetaData) startIndex = void 0;
      const result = this.options.updateTag(childNode.tagname, jPath, childNode[":@"]);
      if (result === false) {
      } else if (typeof result === "string") {
        childNode.tagname = result;
        currentNode.addChild(childNode, startIndex);
      } else {
        currentNode.addChild(childNode, startIndex);
      }
    }
    var replaceEntitiesValue = function(val, tagName, jPath) {
      if (val.indexOf("&") === -1) {
        return val;
      }
      const entityConfig = this.options.processEntities;
      if (!entityConfig.enabled) {
        return val;
      }
      if (entityConfig.allowedTags) {
        if (!entityConfig.allowedTags.includes(tagName)) {
          return val;
        }
      }
      if (entityConfig.tagFilter) {
        if (!entityConfig.tagFilter(tagName, jPath)) {
          return val;
        }
      }
      for (let entityName in this.docTypeEntities) {
        const entity = this.docTypeEntities[entityName];
        const matches = val.match(entity.regx);
        if (matches) {
          this.entityExpansionCount += matches.length;
          if (entityConfig.maxTotalExpansions && this.entityExpansionCount > entityConfig.maxTotalExpansions) {
            throw new Error(
              `Entity expansion limit exceeded: ${this.entityExpansionCount} > ${entityConfig.maxTotalExpansions}`
            );
          }
          const lengthBefore = val.length;
          val = val.replace(entity.regx, entity.val);
          if (entityConfig.maxExpandedLength) {
            this.currentExpandedLength += val.length - lengthBefore;
            if (this.currentExpandedLength > entityConfig.maxExpandedLength) {
              throw new Error(
                `Total expanded content size exceeded: ${this.currentExpandedLength} > ${entityConfig.maxExpandedLength}`
              );
            }
          }
        }
      }
      if (val.indexOf("&") === -1) return val;
      for (const entityName of Object.keys(this.lastEntities)) {
        const entity = this.lastEntities[entityName];
        const matches = val.match(entity.regex);
        if (matches) {
          this.entityExpansionCount += matches.length;
          if (entityConfig.maxTotalExpansions && this.entityExpansionCount > entityConfig.maxTotalExpansions) {
            throw new Error(
              `Entity expansion limit exceeded: ${this.entityExpansionCount} > ${entityConfig.maxTotalExpansions}`
            );
          }
        }
        val = val.replace(entity.regex, entity.val);
      }
      if (val.indexOf("&") === -1) return val;
      if (this.options.htmlEntities) {
        for (const entityName of Object.keys(this.htmlEntities)) {
          const entity = this.htmlEntities[entityName];
          const matches = val.match(entity.regex);
          if (matches) {
            this.entityExpansionCount += matches.length;
            if (entityConfig.maxTotalExpansions && this.entityExpansionCount > entityConfig.maxTotalExpansions) {
              throw new Error(
                `Entity expansion limit exceeded: ${this.entityExpansionCount} > ${entityConfig.maxTotalExpansions}`
              );
            }
          }
          val = val.replace(entity.regex, entity.val);
        }
      }
      val = val.replace(this.ampEntity.regex, this.ampEntity.val);
      return val;
    };
    function saveTextToParentTag(textData, parentNode, jPath, isLeafNode) {
      if (textData) {
        if (isLeafNode === void 0) isLeafNode = parentNode.child.length === 0;
        textData = this.parseTextData(
          textData,
          parentNode.tagname,
          jPath,
          false,
          parentNode[":@"] ? Object.keys(parentNode[":@"]).length !== 0 : false,
          isLeafNode
        );
        if (textData !== void 0 && textData !== "")
          parentNode.add(this.options.textNodeName, textData);
        textData = "";
      }
      return textData;
    }
    function isItStopNode(stopNodesExact, stopNodesWildcard, jPath, currentTagName) {
      if (stopNodesWildcard && stopNodesWildcard.has(currentTagName)) return true;
      if (stopNodesExact && stopNodesExact.has(jPath)) return true;
      return false;
    }
    function tagExpWithClosingIndex(xmlData, i, closingChar = ">") {
      let attrBoundary;
      let tagExp = "";
      for (let index = i; index < xmlData.length; index++) {
        let ch = xmlData[index];
        if (attrBoundary) {
          if (ch === attrBoundary) attrBoundary = "";
        } else if (ch === '"' || ch === "'") {
          attrBoundary = ch;
        } else if (ch === closingChar[0]) {
          if (closingChar[1]) {
            if (xmlData[index + 1] === closingChar[1]) {
              return {
                data: tagExp,
                index
              };
            }
          } else {
            return {
              data: tagExp,
              index
            };
          }
        } else if (ch === "	") {
          ch = " ";
        }
        tagExp += ch;
      }
    }
    function findClosingIndex(xmlData, str, i, errMsg) {
      const closingIndex = xmlData.indexOf(str, i);
      if (closingIndex === -1) {
        throw new Error(errMsg);
      } else {
        return closingIndex + str.length - 1;
      }
    }
    function readTagExp(xmlData, i, removeNSPrefix, closingChar = ">") {
      const result = tagExpWithClosingIndex(xmlData, i + 1, closingChar);
      if (!result) return;
      let tagExp = result.data;
      const closeIndex = result.index;
      const separatorIndex = tagExp.search(/\s/);
      let tagName = tagExp;
      let attrExpPresent = true;
      if (separatorIndex !== -1) {
        tagName = tagExp.substring(0, separatorIndex);
        tagExp = tagExp.substring(separatorIndex + 1).trimStart();
      }
      const rawTagName = tagName;
      if (removeNSPrefix) {
        const colonIndex = tagName.indexOf(":");
        if (colonIndex !== -1) {
          tagName = tagName.substr(colonIndex + 1);
          attrExpPresent = tagName !== result.data.substr(colonIndex + 1);
        }
      }
      return {
        tagName,
        tagExp,
        closeIndex,
        attrExpPresent,
        rawTagName
      };
    }
    function readStopNodeData(xmlData, tagName, i) {
      const startIndex = i;
      let openTagCount = 1;
      for (; i < xmlData.length; i++) {
        if (xmlData[i] === "<") {
          if (xmlData[i + 1] === "/") {
            const closeIndex = findClosingIndex(xmlData, ">", i, `${tagName} is not closed`);
            let closeTagName = xmlData.substring(i + 2, closeIndex).trim();
            if (closeTagName === tagName) {
              openTagCount--;
              if (openTagCount === 0) {
                return {
                  tagContent: xmlData.substring(startIndex, i),
                  i: closeIndex
                };
              }
            }
            i = closeIndex;
          } else if (xmlData[i + 1] === "?") {
            const closeIndex = findClosingIndex(xmlData, "?>", i + 1, "StopNode is not closed.");
            i = closeIndex;
          } else if (xmlData.substr(i + 1, 3) === "!--") {
            const closeIndex = findClosingIndex(xmlData, "-->", i + 3, "StopNode is not closed.");
            i = closeIndex;
          } else if (xmlData.substr(i + 1, 2) === "![") {
            const closeIndex = findClosingIndex(xmlData, "]]>", i, "StopNode is not closed.") - 2;
            i = closeIndex;
          } else {
            const tagData = readTagExp(xmlData, i, ">");
            if (tagData) {
              const openTagName = tagData && tagData.tagName;
              if (openTagName === tagName && tagData.tagExp[tagData.tagExp.length - 1] !== "/") {
                openTagCount++;
              }
              i = tagData.closeIndex;
            }
          }
        }
      }
    }
    function parseValue(val, shouldParse, options) {
      if (shouldParse && typeof val === "string") {
        const newval = val.trim();
        if (newval === "true") return true;
        else if (newval === "false") return false;
        else return toNumber(val, options);
      } else {
        if (util.isExist(val)) {
          return val;
        } else {
          return "";
        }
      }
    }
    function fromCodePoint(str, base, prefix) {
      const codePoint = Number.parseInt(str, base);
      if (codePoint >= 0 && codePoint <= 1114111) {
        return String.fromCodePoint(codePoint);
      } else {
        return prefix + str + ";";
      }
    }
    function sanitizeName(name, options) {
      if (util.criticalProperties.includes(name)) {
        throw new Error(`[SECURITY] Invalid name: "${name}" is a reserved JavaScript keyword that could cause prototype pollution`);
      } else if (util.DANGEROUS_PROPERTY_NAMES.includes(name)) {
        return options.onDangerousProperty(name);
      }
      return name;
    }
    module.exports = OrderedObjParser;
  }
});

// node_modules/fast-xml-parser/src/xmlparser/node2json.js
var require_node2json = __commonJS({
  "node_modules/fast-xml-parser/src/xmlparser/node2json.js"(exports) {
    "use strict";
    function prettify(node, options) {
      return compress(node, options);
    }
    function compress(arr, options, jPath) {
      let text;
      const compressedObj = {};
      for (let i = 0; i < arr.length; i++) {
        const tagObj = arr[i];
        const property = propName(tagObj);
        let newJpath = "";
        if (jPath === void 0) newJpath = property;
        else newJpath = jPath + "." + property;
        if (property === options.textNodeName) {
          if (text === void 0) text = tagObj[property];
          else text += "" + tagObj[property];
        } else if (property === void 0) {
          continue;
        } else if (tagObj[property]) {
          let val = compress(tagObj[property], options, newJpath);
          const isLeaf = isLeafTag(val, options);
          if (tagObj[":@"]) {
            assignAttributes(val, tagObj[":@"], newJpath, options);
          } else if (Object.keys(val).length === 1 && val[options.textNodeName] !== void 0 && !options.alwaysCreateTextNode) {
            val = val[options.textNodeName];
          } else if (Object.keys(val).length === 0) {
            if (options.alwaysCreateTextNode) val[options.textNodeName] = "";
            else val = "";
          }
          if (compressedObj[property] !== void 0 && compressedObj.hasOwnProperty(property)) {
            if (!Array.isArray(compressedObj[property])) {
              compressedObj[property] = [compressedObj[property]];
            }
            compressedObj[property].push(val);
          } else {
            if (options.isArray(property, newJpath, isLeaf)) {
              compressedObj[property] = [val];
            } else {
              compressedObj[property] = val;
            }
          }
        }
      }
      if (typeof text === "string") {
        if (text.length > 0) compressedObj[options.textNodeName] = text;
      } else if (text !== void 0) compressedObj[options.textNodeName] = text;
      return compressedObj;
    }
    function propName(obj) {
      const keys = Object.keys(obj);
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        if (key !== ":@") return key;
      }
    }
    function assignAttributes(obj, attrMap, jpath, options) {
      if (attrMap) {
        const keys = Object.keys(attrMap);
        const len = keys.length;
        for (let i = 0; i < len; i++) {
          const atrrName = keys[i];
          if (options.isArray(atrrName, jpath + "." + atrrName, true, true)) {
            obj[atrrName] = [attrMap[atrrName]];
          } else {
            obj[atrrName] = attrMap[atrrName];
          }
        }
      }
    }
    function isLeafTag(obj, options) {
      const { textNodeName } = options;
      const propCount = Object.keys(obj).length;
      if (propCount === 0) {
        return true;
      }
      if (propCount === 1 && (obj[textNodeName] || typeof obj[textNodeName] === "boolean" || obj[textNodeName] === 0)) {
        return true;
      }
      return false;
    }
    exports.prettify = prettify;
  }
});

// node_modules/fast-xml-parser/src/xmlparser/XMLParser.js
var require_XMLParser = __commonJS({
  "node_modules/fast-xml-parser/src/xmlparser/XMLParser.js"(exports, module) {
    var { buildOptions } = require_OptionsBuilder();
    var OrderedObjParser = require_OrderedObjParser();
    var { prettify } = require_node2json();
    var validator = require_validator();
    var XMLParser2 = class {
      constructor(options) {
        this.externalEntities = {};
        this.options = buildOptions(options);
      }
      /**
       * Parse XML dats to JS object 
       * @param {string|Buffer} xmlData 
       * @param {boolean|Object} validationOption 
       */
      parse(xmlData, validationOption) {
        if (typeof xmlData === "string") {
        } else if (xmlData.toString) {
          xmlData = xmlData.toString();
        } else {
          throw new Error("XML data is accepted in String or Bytes[] form.");
        }
        if (validationOption) {
          if (validationOption === true) validationOption = {};
          const result = validator.validate(xmlData, validationOption);
          if (result !== true) {
            throw Error(`${result.err.msg}:${result.err.line}:${result.err.col}`);
          }
        }
        const orderedObjParser = new OrderedObjParser(this.options);
        orderedObjParser.addExternalEntities(this.externalEntities);
        const orderedResult = orderedObjParser.parseXml(xmlData);
        if (this.options.preserveOrder || orderedResult === void 0) return orderedResult;
        else return prettify(orderedResult, this.options);
      }
      /**
       * Add Entity which is not by default supported by this library
       * @param {string} key 
       * @param {string} value 
       */
      addEntity(key, value) {
        if (value.indexOf("&") !== -1) {
          throw new Error("Entity value can't have '&'");
        } else if (key.indexOf("&") !== -1 || key.indexOf(";") !== -1) {
          throw new Error("An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'");
        } else if (value === "&") {
          throw new Error("An entity with value '&' is not permitted");
        } else {
          this.externalEntities[key] = value;
        }
      }
    };
    module.exports = XMLParser2;
  }
});

// node_modules/fast-xml-parser/src/xmlbuilder/orderedJs2Xml.js
var require_orderedJs2Xml = __commonJS({
  "node_modules/fast-xml-parser/src/xmlbuilder/orderedJs2Xml.js"(exports, module) {
    var EOL = "\n";
    function toXml(jArray, options) {
      let indentation = "";
      if (options.format && options.indentBy.length > 0) {
        indentation = EOL;
      }
      return arrToStr(jArray, options, "", indentation);
    }
    function arrToStr(arr, options, jPath, indentation) {
      let xmlStr = "";
      let isPreviousElementTag = false;
      if (!Array.isArray(arr)) {
        if (arr !== void 0 && arr !== null) {
          let text = arr.toString();
          text = replaceEntitiesValue(text, options);
          return text;
        }
        return "";
      }
      for (let i = 0; i < arr.length; i++) {
        const tagObj = arr[i];
        const tagName = propName(tagObj);
        if (tagName === void 0) continue;
        let newJPath = "";
        if (jPath.length === 0) newJPath = tagName;
        else newJPath = `${jPath}.${tagName}`;
        if (tagName === options.textNodeName) {
          let tagText = tagObj[tagName];
          if (!isStopNode(newJPath, options)) {
            tagText = options.tagValueProcessor(tagName, tagText);
            tagText = replaceEntitiesValue(tagText, options);
          }
          if (isPreviousElementTag) {
            xmlStr += indentation;
          }
          xmlStr += tagText;
          isPreviousElementTag = false;
          continue;
        } else if (tagName === options.cdataPropName) {
          if (isPreviousElementTag) {
            xmlStr += indentation;
          }
          xmlStr += `<![CDATA[${tagObj[tagName][0][options.textNodeName]}]]>`;
          isPreviousElementTag = false;
          continue;
        } else if (tagName === options.commentPropName) {
          xmlStr += indentation + `<!--${tagObj[tagName][0][options.textNodeName]}-->`;
          isPreviousElementTag = true;
          continue;
        } else if (tagName[0] === "?") {
          const attStr2 = attr_to_str(tagObj[":@"], options);
          const tempInd = tagName === "?xml" ? "" : indentation;
          let piTextNodeName = tagObj[tagName][0][options.textNodeName];
          piTextNodeName = piTextNodeName.length !== 0 ? " " + piTextNodeName : "";
          xmlStr += tempInd + `<${tagName}${piTextNodeName}${attStr2}?>`;
          isPreviousElementTag = true;
          continue;
        }
        let newIdentation = indentation;
        if (newIdentation !== "") {
          newIdentation += options.indentBy;
        }
        const attStr = attr_to_str(tagObj[":@"], options);
        const tagStart = indentation + `<${tagName}${attStr}`;
        const tagValue = arrToStr(tagObj[tagName], options, newJPath, newIdentation);
        if (options.unpairedTags.indexOf(tagName) !== -1) {
          if (options.suppressUnpairedNode) xmlStr += tagStart + ">";
          else xmlStr += tagStart + "/>";
        } else if ((!tagValue || tagValue.length === 0) && options.suppressEmptyNode) {
          xmlStr += tagStart + "/>";
        } else if (tagValue && tagValue.endsWith(">")) {
          xmlStr += tagStart + `>${tagValue}${indentation}</${tagName}>`;
        } else {
          xmlStr += tagStart + ">";
          if (tagValue && indentation !== "" && (tagValue.includes("/>") || tagValue.includes("</"))) {
            xmlStr += indentation + options.indentBy + tagValue + indentation;
          } else {
            xmlStr += tagValue;
          }
          xmlStr += `</${tagName}>`;
        }
        isPreviousElementTag = true;
      }
      return xmlStr;
    }
    function propName(obj) {
      const keys = Object.keys(obj);
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        if (!Object.prototype.hasOwnProperty.call(obj, key)) continue;
        if (key !== ":@") return key;
      }
    }
    function attr_to_str(attrMap, options) {
      let attrStr = "";
      if (attrMap && !options.ignoreAttributes) {
        for (let attr in attrMap) {
          if (!Object.prototype.hasOwnProperty.call(attrMap, attr)) continue;
          let attrVal = options.attributeValueProcessor(attr, attrMap[attr]);
          attrVal = replaceEntitiesValue(attrVal, options);
          if (attrVal === true && options.suppressBooleanAttributes) {
            attrStr += ` ${attr.substr(options.attributeNamePrefix.length)}`;
          } else {
            attrStr += ` ${attr.substr(options.attributeNamePrefix.length)}="${attrVal}"`;
          }
        }
      }
      return attrStr;
    }
    function isStopNode(jPath, options) {
      jPath = jPath.substr(0, jPath.length - options.textNodeName.length - 1);
      let tagName = jPath.substr(jPath.lastIndexOf(".") + 1);
      for (let index in options.stopNodes) {
        if (options.stopNodes[index] === jPath || options.stopNodes[index] === "*." + tagName) return true;
      }
      return false;
    }
    function replaceEntitiesValue(textValue, options) {
      if (textValue && textValue.length > 0 && options.processEntities) {
        for (let i = 0; i < options.entities.length; i++) {
          const entity = options.entities[i];
          textValue = textValue.replace(entity.regex, entity.val);
        }
      }
      return textValue;
    }
    module.exports = toXml;
  }
});

// node_modules/fast-xml-parser/src/xmlbuilder/json2xml.js
var require_json2xml = __commonJS({
  "node_modules/fast-xml-parser/src/xmlbuilder/json2xml.js"(exports, module) {
    "use strict";
    var buildFromOrderedJs = require_orderedJs2Xml();
    var getIgnoreAttributesFn = require_ignoreAttributes();
    var defaultOptions = {
      attributeNamePrefix: "@_",
      attributesGroupName: false,
      textNodeName: "#text",
      ignoreAttributes: true,
      cdataPropName: false,
      format: false,
      indentBy: "  ",
      suppressEmptyNode: false,
      suppressUnpairedNode: true,
      suppressBooleanAttributes: true,
      tagValueProcessor: function(key, a) {
        return a;
      },
      attributeValueProcessor: function(attrName, a) {
        return a;
      },
      preserveOrder: false,
      commentPropName: false,
      unpairedTags: [],
      entities: [
        { regex: new RegExp("&", "g"), val: "&amp;" },
        //it must be on top
        { regex: new RegExp(">", "g"), val: "&gt;" },
        { regex: new RegExp("<", "g"), val: "&lt;" },
        { regex: new RegExp("'", "g"), val: "&apos;" },
        { regex: new RegExp('"', "g"), val: "&quot;" }
      ],
      processEntities: true,
      stopNodes: [],
      // transformTagName: false,
      // transformAttributeName: false,
      oneListGroup: false
    };
    function Builder(options) {
      this.options = Object.assign({}, defaultOptions, options);
      if (this.options.ignoreAttributes === true || this.options.attributesGroupName) {
        this.isAttribute = function() {
          return false;
        };
      } else {
        this.ignoreAttributesFn = getIgnoreAttributesFn(this.options.ignoreAttributes);
        this.attrPrefixLen = this.options.attributeNamePrefix.length;
        this.isAttribute = isAttribute;
      }
      this.processTextOrObjNode = processTextOrObjNode;
      if (this.options.format) {
        this.indentate = indentate;
        this.tagEndChar = ">\n";
        this.newLine = "\n";
      } else {
        this.indentate = function() {
          return "";
        };
        this.tagEndChar = ">";
        this.newLine = "";
      }
    }
    Builder.prototype.build = function(jObj) {
      if (this.options.preserveOrder) {
        return buildFromOrderedJs(jObj, this.options);
      } else {
        if (Array.isArray(jObj) && this.options.arrayNodeName && this.options.arrayNodeName.length > 1) {
          jObj = {
            [this.options.arrayNodeName]: jObj
          };
        }
        return this.j2x(jObj, 0, []).val;
      }
    };
    Builder.prototype.j2x = function(jObj, level, ajPath) {
      let attrStr = "";
      let val = "";
      const jPath = ajPath.join(".");
      for (let key in jObj) {
        if (!Object.prototype.hasOwnProperty.call(jObj, key)) continue;
        if (typeof jObj[key] === "undefined") {
          if (this.isAttribute(key)) {
            val += "";
          }
        } else if (jObj[key] === null) {
          if (this.isAttribute(key)) {
            val += "";
          } else if (key === this.options.cdataPropName) {
            val += "";
          } else if (key[0] === "?") {
            val += this.indentate(level) + "<" + key + "?" + this.tagEndChar;
          } else {
            val += this.indentate(level) + "<" + key + "/" + this.tagEndChar;
          }
        } else if (jObj[key] instanceof Date) {
          val += this.buildTextValNode(jObj[key], key, "", level);
        } else if (typeof jObj[key] !== "object") {
          const attr = this.isAttribute(key);
          if (attr && !this.ignoreAttributesFn(attr, jPath)) {
            attrStr += this.buildAttrPairStr(attr, "" + jObj[key]);
          } else if (!attr) {
            if (key === this.options.textNodeName) {
              let newval = this.options.tagValueProcessor(key, "" + jObj[key]);
              val += this.replaceEntitiesValue(newval);
            } else {
              val += this.buildTextValNode(jObj[key], key, "", level);
            }
          }
        } else if (Array.isArray(jObj[key])) {
          const arrLen = jObj[key].length;
          let listTagVal = "";
          let listTagAttr = "";
          for (let j = 0; j < arrLen; j++) {
            const item = jObj[key][j];
            if (typeof item === "undefined") {
            } else if (item === null) {
              if (key[0] === "?") val += this.indentate(level) + "<" + key + "?" + this.tagEndChar;
              else val += this.indentate(level) + "<" + key + "/" + this.tagEndChar;
            } else if (typeof item === "object") {
              if (this.options.oneListGroup) {
                const result = this.j2x(item, level + 1, ajPath.concat(key));
                listTagVal += result.val;
                if (this.options.attributesGroupName && item.hasOwnProperty(this.options.attributesGroupName)) {
                  listTagAttr += result.attrStr;
                }
              } else {
                listTagVal += this.processTextOrObjNode(item, key, level, ajPath);
              }
            } else {
              if (this.options.oneListGroup) {
                let textValue = this.options.tagValueProcessor(key, item);
                textValue = this.replaceEntitiesValue(textValue);
                listTagVal += textValue;
              } else {
                listTagVal += this.buildTextValNode(item, key, "", level);
              }
            }
          }
          if (this.options.oneListGroup) {
            listTagVal = this.buildObjectNode(listTagVal, key, listTagAttr, level);
          }
          val += listTagVal;
        } else {
          if (this.options.attributesGroupName && key === this.options.attributesGroupName) {
            const Ks = Object.keys(jObj[key]);
            const L = Ks.length;
            for (let j = 0; j < L; j++) {
              attrStr += this.buildAttrPairStr(Ks[j], "" + jObj[key][Ks[j]]);
            }
          } else {
            val += this.processTextOrObjNode(jObj[key], key, level, ajPath);
          }
        }
      }
      return { attrStr, val };
    };
    Builder.prototype.buildAttrPairStr = function(attrName, val) {
      val = this.options.attributeValueProcessor(attrName, "" + val);
      val = this.replaceEntitiesValue(val);
      if (this.options.suppressBooleanAttributes && val === "true") {
        return " " + attrName;
      } else return " " + attrName + '="' + val + '"';
    };
    function processTextOrObjNode(object, key, level, ajPath) {
      const result = this.j2x(object, level + 1, ajPath.concat(key));
      if (object[this.options.textNodeName] !== void 0 && Object.keys(object).length === 1) {
        return this.buildTextValNode(object[this.options.textNodeName], key, result.attrStr, level);
      } else {
        return this.buildObjectNode(result.val, key, result.attrStr, level);
      }
    }
    Builder.prototype.buildObjectNode = function(val, key, attrStr, level) {
      if (val === "") {
        if (key[0] === "?") return this.indentate(level) + "<" + key + attrStr + "?" + this.tagEndChar;
        else {
          return this.indentate(level) + "<" + key + attrStr + this.closeTag(key) + this.tagEndChar;
        }
      } else {
        let tagEndExp = "</" + key + this.tagEndChar;
        let piClosingChar = "";
        if (key[0] === "?") {
          piClosingChar = "?";
          tagEndExp = "";
        }
        if ((attrStr || attrStr === "") && val.indexOf("<") === -1) {
          return this.indentate(level) + "<" + key + attrStr + piClosingChar + ">" + val + tagEndExp;
        } else if (this.options.commentPropName !== false && key === this.options.commentPropName && piClosingChar.length === 0) {
          return this.indentate(level) + `<!--${val}-->` + this.newLine;
        } else {
          return this.indentate(level) + "<" + key + attrStr + piClosingChar + this.tagEndChar + val + this.indentate(level) + tagEndExp;
        }
      }
    };
    Builder.prototype.closeTag = function(key) {
      let closeTag = "";
      if (this.options.unpairedTags.indexOf(key) !== -1) {
        if (!this.options.suppressUnpairedNode) closeTag = "/";
      } else if (this.options.suppressEmptyNode) {
        closeTag = "/";
      } else {
        closeTag = `></${key}`;
      }
      return closeTag;
    };
    Builder.prototype.buildTextValNode = function(val, key, attrStr, level) {
      if (this.options.cdataPropName !== false && key === this.options.cdataPropName) {
        return this.indentate(level) + `<![CDATA[${val}]]>` + this.newLine;
      } else if (this.options.commentPropName !== false && key === this.options.commentPropName) {
        return this.indentate(level) + `<!--${val}-->` + this.newLine;
      } else if (key[0] === "?") {
        return this.indentate(level) + "<" + key + attrStr + "?" + this.tagEndChar;
      } else {
        let textValue = this.options.tagValueProcessor(key, val);
        textValue = this.replaceEntitiesValue(textValue);
        if (textValue === "") {
          return this.indentate(level) + "<" + key + attrStr + this.closeTag(key) + this.tagEndChar;
        } else {
          return this.indentate(level) + "<" + key + attrStr + ">" + textValue + "</" + key + this.tagEndChar;
        }
      }
    };
    Builder.prototype.replaceEntitiesValue = function(textValue) {
      if (textValue && textValue.length > 0 && this.options.processEntities) {
        for (let i = 0; i < this.options.entities.length; i++) {
          const entity = this.options.entities[i];
          textValue = textValue.replace(entity.regex, entity.val);
        }
      }
      return textValue;
    };
    function indentate(level) {
      return this.options.indentBy.repeat(level);
    }
    function isAttribute(name) {
      if (name.startsWith(this.options.attributeNamePrefix) && name !== this.options.textNodeName) {
        return name.substr(this.attrPrefixLen);
      } else {
        return false;
      }
    }
    module.exports = Builder;
  }
});

// node_modules/fast-xml-parser/src/fxp.js
var require_fxp = __commonJS({
  "node_modules/fast-xml-parser/src/fxp.js"(exports, module) {
    "use strict";
    var validator = require_validator();
    var XMLParser2 = require_XMLParser();
    var XMLBuilder = require_json2xml();
    module.exports = {
      XMLParser: XMLParser2,
      XMLValidator: validator,
      XMLBuilder
    };
  }
});

// src/parsers/jwt.ts
var b64UrlDecode = (input) => {
  const padded = input.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(input.length / 4) * 4, "=");
  return atob(padded);
};
var decodeJwt = (token) => {
  const parts = token.split(".");
  if (parts.length !== 3) return void 0;
  try {
    const header = JSON.parse(b64UrlDecode(parts[0]));
    const payload = JSON.parse(b64UrlDecode(parts[1]));
    return { header, payload, signature: parts[2] };
  } catch {
    return void 0;
  }
};
var isJwt = (value) => Boolean(value && value.split(".").length === 3);

// src/shared/utils.ts
var nowId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
var parseQueryString = (input) => {
  const output = {};
  const params = new URLSearchParams(input);
  for (const [key, value] of params.entries()) {
    output[key] = value;
  }
  return output;
};
var toHeaderMap = (headers) => {
  const map2 = {};
  if (!headers) return map2;
  headers.forEach((h) => {
    if (!h.name) return;
    map2[h.name.toLowerCase()] = String(h.value ?? "");
  });
  return map2;
};
var safeJsonParse = (value) => {
  try {
    return JSON.parse(value);
  } catch {
    return void 0;
  }
};
var safeUrl = (value) => {
  try {
    return new URL(value);
  } catch {
    return void 0;
  }
};

// src/parsers/oidc.ts
var parseFragmentOrQuery = (url) => {
  const parsed = safeUrl(url);
  if (!parsed) return {};
  if (parsed.hash.length > 1) return parseQueryString(parsed.hash.slice(1));
  if (parsed.search.length > 1) return parseQueryString(parsed.search.slice(1));
  return {};
};
var attachTokenArtifacts = (event, body) => {
  if (!body) return;
  const json = safeJsonParse(body);
  if (!json) return;
  const idToken = typeof json.id_token === "string" ? json.id_token : void 0;
  const accessToken = typeof json.access_token === "string" ? json.access_token : void 0;
  const error = typeof json.error === "string" ? json.error : void 0;
  const errorDescription = typeof json.error_description === "string" ? json.error_description : void 0;
  if (idToken && isJwt(idToken)) {
    event.idToken = decodeJwt(idToken);
  }
  if (accessToken) {
    if (isJwt(accessToken)) {
      event.accessTokenJwt = decodeJwt(accessToken);
    } else {
      event.accessTokenOpaque = true;
    }
  }
  if (error) event.error = error;
  if (errorDescription) event.errorDescription = errorDescription;
  const authMethod = typeof json.token_endpoint_auth_method === "string" ? json.token_endpoint_auth_method : void 0;
  if (authMethod) {
    event.tokenEndpointAuthMethod = authMethod;
  }
};

// node_modules/pako/dist/pako.esm.mjs
var Z_FIXED$1 = 4;
var Z_BINARY = 0;
var Z_TEXT = 1;
var Z_UNKNOWN$1 = 2;
function zero$1(buf) {
  let len = buf.length;
  while (--len >= 0) {
    buf[len] = 0;
  }
}
var STORED_BLOCK = 0;
var STATIC_TREES = 1;
var DYN_TREES = 2;
var MIN_MATCH$1 = 3;
var MAX_MATCH$1 = 258;
var LENGTH_CODES$1 = 29;
var LITERALS$1 = 256;
var L_CODES$1 = LITERALS$1 + 1 + LENGTH_CODES$1;
var D_CODES$1 = 30;
var BL_CODES$1 = 19;
var HEAP_SIZE$1 = 2 * L_CODES$1 + 1;
var MAX_BITS$1 = 15;
var Buf_size = 16;
var MAX_BL_BITS = 7;
var END_BLOCK = 256;
var REP_3_6 = 16;
var REPZ_3_10 = 17;
var REPZ_11_138 = 18;
var extra_lbits = (
  /* extra bits for each length code */
  new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0])
);
var extra_dbits = (
  /* extra bits for each distance code */
  new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13])
);
var extra_blbits = (
  /* extra bits for each bit length code */
  new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7])
);
var bl_order = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var DIST_CODE_LEN = 512;
var static_ltree = new Array((L_CODES$1 + 2) * 2);
zero$1(static_ltree);
var static_dtree = new Array(D_CODES$1 * 2);
zero$1(static_dtree);
var _dist_code = new Array(DIST_CODE_LEN);
zero$1(_dist_code);
var _length_code = new Array(MAX_MATCH$1 - MIN_MATCH$1 + 1);
zero$1(_length_code);
var base_length = new Array(LENGTH_CODES$1);
zero$1(base_length);
var base_dist = new Array(D_CODES$1);
zero$1(base_dist);
function StaticTreeDesc(static_tree, extra_bits, extra_base, elems, max_length) {
  this.static_tree = static_tree;
  this.extra_bits = extra_bits;
  this.extra_base = extra_base;
  this.elems = elems;
  this.max_length = max_length;
  this.has_stree = static_tree && static_tree.length;
}
var static_l_desc;
var static_d_desc;
var static_bl_desc;
function TreeDesc(dyn_tree, stat_desc) {
  this.dyn_tree = dyn_tree;
  this.max_code = 0;
  this.stat_desc = stat_desc;
}
var d_code = (dist) => {
  return dist < 256 ? _dist_code[dist] : _dist_code[256 + (dist >>> 7)];
};
var put_short = (s, w) => {
  s.pending_buf[s.pending++] = w & 255;
  s.pending_buf[s.pending++] = w >>> 8 & 255;
};
var send_bits = (s, value, length) => {
  if (s.bi_valid > Buf_size - length) {
    s.bi_buf |= value << s.bi_valid & 65535;
    put_short(s, s.bi_buf);
    s.bi_buf = value >> Buf_size - s.bi_valid;
    s.bi_valid += length - Buf_size;
  } else {
    s.bi_buf |= value << s.bi_valid & 65535;
    s.bi_valid += length;
  }
};
var send_code = (s, c, tree) => {
  send_bits(
    s,
    tree[c * 2],
    tree[c * 2 + 1]
    /*.Len*/
  );
};
var bi_reverse = (code, len) => {
  let res = 0;
  do {
    res |= code & 1;
    code >>>= 1;
    res <<= 1;
  } while (--len > 0);
  return res >>> 1;
};
var bi_flush = (s) => {
  if (s.bi_valid === 16) {
    put_short(s, s.bi_buf);
    s.bi_buf = 0;
    s.bi_valid = 0;
  } else if (s.bi_valid >= 8) {
    s.pending_buf[s.pending++] = s.bi_buf & 255;
    s.bi_buf >>= 8;
    s.bi_valid -= 8;
  }
};
var gen_bitlen = (s, desc) => {
  const tree = desc.dyn_tree;
  const max_code = desc.max_code;
  const stree = desc.stat_desc.static_tree;
  const has_stree = desc.stat_desc.has_stree;
  const extra = desc.stat_desc.extra_bits;
  const base = desc.stat_desc.extra_base;
  const max_length = desc.stat_desc.max_length;
  let h;
  let n, m;
  let bits;
  let xbits;
  let f;
  let overflow = 0;
  for (bits = 0; bits <= MAX_BITS$1; bits++) {
    s.bl_count[bits] = 0;
  }
  tree[s.heap[s.heap_max] * 2 + 1] = 0;
  for (h = s.heap_max + 1; h < HEAP_SIZE$1; h++) {
    n = s.heap[h];
    bits = tree[tree[n * 2 + 1] * 2 + 1] + 1;
    if (bits > max_length) {
      bits = max_length;
      overflow++;
    }
    tree[n * 2 + 1] = bits;
    if (n > max_code) {
      continue;
    }
    s.bl_count[bits]++;
    xbits = 0;
    if (n >= base) {
      xbits = extra[n - base];
    }
    f = tree[n * 2];
    s.opt_len += f * (bits + xbits);
    if (has_stree) {
      s.static_len += f * (stree[n * 2 + 1] + xbits);
    }
  }
  if (overflow === 0) {
    return;
  }
  do {
    bits = max_length - 1;
    while (s.bl_count[bits] === 0) {
      bits--;
    }
    s.bl_count[bits]--;
    s.bl_count[bits + 1] += 2;
    s.bl_count[max_length]--;
    overflow -= 2;
  } while (overflow > 0);
  for (bits = max_length; bits !== 0; bits--) {
    n = s.bl_count[bits];
    while (n !== 0) {
      m = s.heap[--h];
      if (m > max_code) {
        continue;
      }
      if (tree[m * 2 + 1] !== bits) {
        s.opt_len += (bits - tree[m * 2 + 1]) * tree[m * 2];
        tree[m * 2 + 1] = bits;
      }
      n--;
    }
  }
};
var gen_codes = (tree, max_code, bl_count) => {
  const next_code = new Array(MAX_BITS$1 + 1);
  let code = 0;
  let bits;
  let n;
  for (bits = 1; bits <= MAX_BITS$1; bits++) {
    code = code + bl_count[bits - 1] << 1;
    next_code[bits] = code;
  }
  for (n = 0; n <= max_code; n++) {
    let len = tree[n * 2 + 1];
    if (len === 0) {
      continue;
    }
    tree[n * 2] = bi_reverse(next_code[len]++, len);
  }
};
var tr_static_init = () => {
  let n;
  let bits;
  let length;
  let code;
  let dist;
  const bl_count = new Array(MAX_BITS$1 + 1);
  length = 0;
  for (code = 0; code < LENGTH_CODES$1 - 1; code++) {
    base_length[code] = length;
    for (n = 0; n < 1 << extra_lbits[code]; n++) {
      _length_code[length++] = code;
    }
  }
  _length_code[length - 1] = code;
  dist = 0;
  for (code = 0; code < 16; code++) {
    base_dist[code] = dist;
    for (n = 0; n < 1 << extra_dbits[code]; n++) {
      _dist_code[dist++] = code;
    }
  }
  dist >>= 7;
  for (; code < D_CODES$1; code++) {
    base_dist[code] = dist << 7;
    for (n = 0; n < 1 << extra_dbits[code] - 7; n++) {
      _dist_code[256 + dist++] = code;
    }
  }
  for (bits = 0; bits <= MAX_BITS$1; bits++) {
    bl_count[bits] = 0;
  }
  n = 0;
  while (n <= 143) {
    static_ltree[n * 2 + 1] = 8;
    n++;
    bl_count[8]++;
  }
  while (n <= 255) {
    static_ltree[n * 2 + 1] = 9;
    n++;
    bl_count[9]++;
  }
  while (n <= 279) {
    static_ltree[n * 2 + 1] = 7;
    n++;
    bl_count[7]++;
  }
  while (n <= 287) {
    static_ltree[n * 2 + 1] = 8;
    n++;
    bl_count[8]++;
  }
  gen_codes(static_ltree, L_CODES$1 + 1, bl_count);
  for (n = 0; n < D_CODES$1; n++) {
    static_dtree[n * 2 + 1] = 5;
    static_dtree[n * 2] = bi_reverse(n, 5);
  }
  static_l_desc = new StaticTreeDesc(static_ltree, extra_lbits, LITERALS$1 + 1, L_CODES$1, MAX_BITS$1);
  static_d_desc = new StaticTreeDesc(static_dtree, extra_dbits, 0, D_CODES$1, MAX_BITS$1);
  static_bl_desc = new StaticTreeDesc(new Array(0), extra_blbits, 0, BL_CODES$1, MAX_BL_BITS);
};
var init_block = (s) => {
  let n;
  for (n = 0; n < L_CODES$1; n++) {
    s.dyn_ltree[n * 2] = 0;
  }
  for (n = 0; n < D_CODES$1; n++) {
    s.dyn_dtree[n * 2] = 0;
  }
  for (n = 0; n < BL_CODES$1; n++) {
    s.bl_tree[n * 2] = 0;
  }
  s.dyn_ltree[END_BLOCK * 2] = 1;
  s.opt_len = s.static_len = 0;
  s.sym_next = s.matches = 0;
};
var bi_windup = (s) => {
  if (s.bi_valid > 8) {
    put_short(s, s.bi_buf);
  } else if (s.bi_valid > 0) {
    s.pending_buf[s.pending++] = s.bi_buf;
  }
  s.bi_buf = 0;
  s.bi_valid = 0;
};
var smaller = (tree, n, m, depth) => {
  const _n2 = n * 2;
  const _m2 = m * 2;
  return tree[_n2] < tree[_m2] || tree[_n2] === tree[_m2] && depth[n] <= depth[m];
};
var pqdownheap = (s, tree, k) => {
  const v = s.heap[k];
  let j = k << 1;
  while (j <= s.heap_len) {
    if (j < s.heap_len && smaller(tree, s.heap[j + 1], s.heap[j], s.depth)) {
      j++;
    }
    if (smaller(tree, v, s.heap[j], s.depth)) {
      break;
    }
    s.heap[k] = s.heap[j];
    k = j;
    j <<= 1;
  }
  s.heap[k] = v;
};
var compress_block = (s, ltree, dtree) => {
  let dist;
  let lc;
  let sx = 0;
  let code;
  let extra;
  if (s.sym_next !== 0) {
    do {
      dist = s.pending_buf[s.sym_buf + sx++] & 255;
      dist += (s.pending_buf[s.sym_buf + sx++] & 255) << 8;
      lc = s.pending_buf[s.sym_buf + sx++];
      if (dist === 0) {
        send_code(s, lc, ltree);
      } else {
        code = _length_code[lc];
        send_code(s, code + LITERALS$1 + 1, ltree);
        extra = extra_lbits[code];
        if (extra !== 0) {
          lc -= base_length[code];
          send_bits(s, lc, extra);
        }
        dist--;
        code = d_code(dist);
        send_code(s, code, dtree);
        extra = extra_dbits[code];
        if (extra !== 0) {
          dist -= base_dist[code];
          send_bits(s, dist, extra);
        }
      }
    } while (sx < s.sym_next);
  }
  send_code(s, END_BLOCK, ltree);
};
var build_tree = (s, desc) => {
  const tree = desc.dyn_tree;
  const stree = desc.stat_desc.static_tree;
  const has_stree = desc.stat_desc.has_stree;
  const elems = desc.stat_desc.elems;
  let n, m;
  let max_code = -1;
  let node;
  s.heap_len = 0;
  s.heap_max = HEAP_SIZE$1;
  for (n = 0; n < elems; n++) {
    if (tree[n * 2] !== 0) {
      s.heap[++s.heap_len] = max_code = n;
      s.depth[n] = 0;
    } else {
      tree[n * 2 + 1] = 0;
    }
  }
  while (s.heap_len < 2) {
    node = s.heap[++s.heap_len] = max_code < 2 ? ++max_code : 0;
    tree[node * 2] = 1;
    s.depth[node] = 0;
    s.opt_len--;
    if (has_stree) {
      s.static_len -= stree[node * 2 + 1];
    }
  }
  desc.max_code = max_code;
  for (n = s.heap_len >> 1; n >= 1; n--) {
    pqdownheap(s, tree, n);
  }
  node = elems;
  do {
    n = s.heap[
      1
      /*SMALLEST*/
    ];
    s.heap[
      1
      /*SMALLEST*/
    ] = s.heap[s.heap_len--];
    pqdownheap(
      s,
      tree,
      1
      /*SMALLEST*/
    );
    m = s.heap[
      1
      /*SMALLEST*/
    ];
    s.heap[--s.heap_max] = n;
    s.heap[--s.heap_max] = m;
    tree[node * 2] = tree[n * 2] + tree[m * 2];
    s.depth[node] = (s.depth[n] >= s.depth[m] ? s.depth[n] : s.depth[m]) + 1;
    tree[n * 2 + 1] = tree[m * 2 + 1] = node;
    s.heap[
      1
      /*SMALLEST*/
    ] = node++;
    pqdownheap(
      s,
      tree,
      1
      /*SMALLEST*/
    );
  } while (s.heap_len >= 2);
  s.heap[--s.heap_max] = s.heap[
    1
    /*SMALLEST*/
  ];
  gen_bitlen(s, desc);
  gen_codes(tree, max_code, s.bl_count);
};
var scan_tree = (s, tree, max_code) => {
  let n;
  let prevlen = -1;
  let curlen;
  let nextlen = tree[0 * 2 + 1];
  let count = 0;
  let max_count = 7;
  let min_count = 4;
  if (nextlen === 0) {
    max_count = 138;
    min_count = 3;
  }
  tree[(max_code + 1) * 2 + 1] = 65535;
  for (n = 0; n <= max_code; n++) {
    curlen = nextlen;
    nextlen = tree[(n + 1) * 2 + 1];
    if (++count < max_count && curlen === nextlen) {
      continue;
    } else if (count < min_count) {
      s.bl_tree[curlen * 2] += count;
    } else if (curlen !== 0) {
      if (curlen !== prevlen) {
        s.bl_tree[curlen * 2]++;
      }
      s.bl_tree[REP_3_6 * 2]++;
    } else if (count <= 10) {
      s.bl_tree[REPZ_3_10 * 2]++;
    } else {
      s.bl_tree[REPZ_11_138 * 2]++;
    }
    count = 0;
    prevlen = curlen;
    if (nextlen === 0) {
      max_count = 138;
      min_count = 3;
    } else if (curlen === nextlen) {
      max_count = 6;
      min_count = 3;
    } else {
      max_count = 7;
      min_count = 4;
    }
  }
};
var send_tree = (s, tree, max_code) => {
  let n;
  let prevlen = -1;
  let curlen;
  let nextlen = tree[0 * 2 + 1];
  let count = 0;
  let max_count = 7;
  let min_count = 4;
  if (nextlen === 0) {
    max_count = 138;
    min_count = 3;
  }
  for (n = 0; n <= max_code; n++) {
    curlen = nextlen;
    nextlen = tree[(n + 1) * 2 + 1];
    if (++count < max_count && curlen === nextlen) {
      continue;
    } else if (count < min_count) {
      do {
        send_code(s, curlen, s.bl_tree);
      } while (--count !== 0);
    } else if (curlen !== 0) {
      if (curlen !== prevlen) {
        send_code(s, curlen, s.bl_tree);
        count--;
      }
      send_code(s, REP_3_6, s.bl_tree);
      send_bits(s, count - 3, 2);
    } else if (count <= 10) {
      send_code(s, REPZ_3_10, s.bl_tree);
      send_bits(s, count - 3, 3);
    } else {
      send_code(s, REPZ_11_138, s.bl_tree);
      send_bits(s, count - 11, 7);
    }
    count = 0;
    prevlen = curlen;
    if (nextlen === 0) {
      max_count = 138;
      min_count = 3;
    } else if (curlen === nextlen) {
      max_count = 6;
      min_count = 3;
    } else {
      max_count = 7;
      min_count = 4;
    }
  }
};
var build_bl_tree = (s) => {
  let max_blindex;
  scan_tree(s, s.dyn_ltree, s.l_desc.max_code);
  scan_tree(s, s.dyn_dtree, s.d_desc.max_code);
  build_tree(s, s.bl_desc);
  for (max_blindex = BL_CODES$1 - 1; max_blindex >= 3; max_blindex--) {
    if (s.bl_tree[bl_order[max_blindex] * 2 + 1] !== 0) {
      break;
    }
  }
  s.opt_len += 3 * (max_blindex + 1) + 5 + 5 + 4;
  return max_blindex;
};
var send_all_trees = (s, lcodes, dcodes, blcodes) => {
  let rank2;
  send_bits(s, lcodes - 257, 5);
  send_bits(s, dcodes - 1, 5);
  send_bits(s, blcodes - 4, 4);
  for (rank2 = 0; rank2 < blcodes; rank2++) {
    send_bits(s, s.bl_tree[bl_order[rank2] * 2 + 1], 3);
  }
  send_tree(s, s.dyn_ltree, lcodes - 1);
  send_tree(s, s.dyn_dtree, dcodes - 1);
};
var detect_data_type = (s) => {
  let block_mask = 4093624447;
  let n;
  for (n = 0; n <= 31; n++, block_mask >>>= 1) {
    if (block_mask & 1 && s.dyn_ltree[n * 2] !== 0) {
      return Z_BINARY;
    }
  }
  if (s.dyn_ltree[9 * 2] !== 0 || s.dyn_ltree[10 * 2] !== 0 || s.dyn_ltree[13 * 2] !== 0) {
    return Z_TEXT;
  }
  for (n = 32; n < LITERALS$1; n++) {
    if (s.dyn_ltree[n * 2] !== 0) {
      return Z_TEXT;
    }
  }
  return Z_BINARY;
};
var static_init_done = false;
var _tr_init$1 = (s) => {
  if (!static_init_done) {
    tr_static_init();
    static_init_done = true;
  }
  s.l_desc = new TreeDesc(s.dyn_ltree, static_l_desc);
  s.d_desc = new TreeDesc(s.dyn_dtree, static_d_desc);
  s.bl_desc = new TreeDesc(s.bl_tree, static_bl_desc);
  s.bi_buf = 0;
  s.bi_valid = 0;
  init_block(s);
};
var _tr_stored_block$1 = (s, buf, stored_len, last) => {
  send_bits(s, (STORED_BLOCK << 1) + (last ? 1 : 0), 3);
  bi_windup(s);
  put_short(s, stored_len);
  put_short(s, ~stored_len);
  if (stored_len) {
    s.pending_buf.set(s.window.subarray(buf, buf + stored_len), s.pending);
  }
  s.pending += stored_len;
};
var _tr_align$1 = (s) => {
  send_bits(s, STATIC_TREES << 1, 3);
  send_code(s, END_BLOCK, static_ltree);
  bi_flush(s);
};
var _tr_flush_block$1 = (s, buf, stored_len, last) => {
  let opt_lenb, static_lenb;
  let max_blindex = 0;
  if (s.level > 0) {
    if (s.strm.data_type === Z_UNKNOWN$1) {
      s.strm.data_type = detect_data_type(s);
    }
    build_tree(s, s.l_desc);
    build_tree(s, s.d_desc);
    max_blindex = build_bl_tree(s);
    opt_lenb = s.opt_len + 3 + 7 >>> 3;
    static_lenb = s.static_len + 3 + 7 >>> 3;
    if (static_lenb <= opt_lenb) {
      opt_lenb = static_lenb;
    }
  } else {
    opt_lenb = static_lenb = stored_len + 5;
  }
  if (stored_len + 4 <= opt_lenb && buf !== -1) {
    _tr_stored_block$1(s, buf, stored_len, last);
  } else if (s.strategy === Z_FIXED$1 || static_lenb === opt_lenb) {
    send_bits(s, (STATIC_TREES << 1) + (last ? 1 : 0), 3);
    compress_block(s, static_ltree, static_dtree);
  } else {
    send_bits(s, (DYN_TREES << 1) + (last ? 1 : 0), 3);
    send_all_trees(s, s.l_desc.max_code + 1, s.d_desc.max_code + 1, max_blindex + 1);
    compress_block(s, s.dyn_ltree, s.dyn_dtree);
  }
  init_block(s);
  if (last) {
    bi_windup(s);
  }
};
var _tr_tally$1 = (s, dist, lc) => {
  s.pending_buf[s.sym_buf + s.sym_next++] = dist;
  s.pending_buf[s.sym_buf + s.sym_next++] = dist >> 8;
  s.pending_buf[s.sym_buf + s.sym_next++] = lc;
  if (dist === 0) {
    s.dyn_ltree[lc * 2]++;
  } else {
    s.matches++;
    dist--;
    s.dyn_ltree[(_length_code[lc] + LITERALS$1 + 1) * 2]++;
    s.dyn_dtree[d_code(dist) * 2]++;
  }
  return s.sym_next === s.sym_end;
};
var _tr_init_1 = _tr_init$1;
var _tr_stored_block_1 = _tr_stored_block$1;
var _tr_flush_block_1 = _tr_flush_block$1;
var _tr_tally_1 = _tr_tally$1;
var _tr_align_1 = _tr_align$1;
var trees = {
  _tr_init: _tr_init_1,
  _tr_stored_block: _tr_stored_block_1,
  _tr_flush_block: _tr_flush_block_1,
  _tr_tally: _tr_tally_1,
  _tr_align: _tr_align_1
};
var adler32 = (adler, buf, len, pos) => {
  let s1 = adler & 65535 | 0, s2 = adler >>> 16 & 65535 | 0, n = 0;
  while (len !== 0) {
    n = len > 2e3 ? 2e3 : len;
    len -= n;
    do {
      s1 = s1 + buf[pos++] | 0;
      s2 = s2 + s1 | 0;
    } while (--n);
    s1 %= 65521;
    s2 %= 65521;
  }
  return s1 | s2 << 16 | 0;
};
var adler32_1 = adler32;
var makeTable = () => {
  let c, table = [];
  for (var n = 0; n < 256; n++) {
    c = n;
    for (var k = 0; k < 8; k++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    table[n] = c;
  }
  return table;
};
var crcTable = new Uint32Array(makeTable());
var crc32 = (crc, buf, len, pos) => {
  const t = crcTable;
  const end = pos + len;
  crc ^= -1;
  for (let i = pos; i < end; i++) {
    crc = crc >>> 8 ^ t[(crc ^ buf[i]) & 255];
  }
  return crc ^ -1;
};
var crc32_1 = crc32;
var messages = {
  2: "need dictionary",
  /* Z_NEED_DICT       2  */
  1: "stream end",
  /* Z_STREAM_END      1  */
  0: "",
  /* Z_OK              0  */
  "-1": "file error",
  /* Z_ERRNO         (-1) */
  "-2": "stream error",
  /* Z_STREAM_ERROR  (-2) */
  "-3": "data error",
  /* Z_DATA_ERROR    (-3) */
  "-4": "insufficient memory",
  /* Z_MEM_ERROR     (-4) */
  "-5": "buffer error",
  /* Z_BUF_ERROR     (-5) */
  "-6": "incompatible version"
  /* Z_VERSION_ERROR (-6) */
};
var constants$2 = {
  /* Allowed flush values; see deflate() and inflate() below for details */
  Z_NO_FLUSH: 0,
  Z_PARTIAL_FLUSH: 1,
  Z_SYNC_FLUSH: 2,
  Z_FULL_FLUSH: 3,
  Z_FINISH: 4,
  Z_BLOCK: 5,
  Z_TREES: 6,
  /* Return codes for the compression/decompression functions. Negative values
  * are errors, positive values are used for special but normal events.
  */
  Z_OK: 0,
  Z_STREAM_END: 1,
  Z_NEED_DICT: 2,
  Z_ERRNO: -1,
  Z_STREAM_ERROR: -2,
  Z_DATA_ERROR: -3,
  Z_MEM_ERROR: -4,
  Z_BUF_ERROR: -5,
  //Z_VERSION_ERROR: -6,
  /* compression levels */
  Z_NO_COMPRESSION: 0,
  Z_BEST_SPEED: 1,
  Z_BEST_COMPRESSION: 9,
  Z_DEFAULT_COMPRESSION: -1,
  Z_FILTERED: 1,
  Z_HUFFMAN_ONLY: 2,
  Z_RLE: 3,
  Z_FIXED: 4,
  Z_DEFAULT_STRATEGY: 0,
  /* Possible values of the data_type field (though see inflate()) */
  Z_BINARY: 0,
  Z_TEXT: 1,
  //Z_ASCII:                1, // = Z_TEXT (deprecated)
  Z_UNKNOWN: 2,
  /* The deflate compression method */
  Z_DEFLATED: 8
  //Z_NULL:                 null // Use -1 or null inline, depending on var type
};
var { _tr_init, _tr_stored_block, _tr_flush_block, _tr_tally, _tr_align } = trees;
var {
  Z_NO_FLUSH: Z_NO_FLUSH$2,
  Z_PARTIAL_FLUSH,
  Z_FULL_FLUSH: Z_FULL_FLUSH$1,
  Z_FINISH: Z_FINISH$3,
  Z_BLOCK: Z_BLOCK$1,
  Z_OK: Z_OK$3,
  Z_STREAM_END: Z_STREAM_END$3,
  Z_STREAM_ERROR: Z_STREAM_ERROR$2,
  Z_DATA_ERROR: Z_DATA_ERROR$2,
  Z_BUF_ERROR: Z_BUF_ERROR$1,
  Z_DEFAULT_COMPRESSION: Z_DEFAULT_COMPRESSION$1,
  Z_FILTERED,
  Z_HUFFMAN_ONLY,
  Z_RLE,
  Z_FIXED,
  Z_DEFAULT_STRATEGY: Z_DEFAULT_STRATEGY$1,
  Z_UNKNOWN,
  Z_DEFLATED: Z_DEFLATED$2
} = constants$2;
var MAX_MEM_LEVEL = 9;
var MAX_WBITS$1 = 15;
var DEF_MEM_LEVEL = 8;
var LENGTH_CODES = 29;
var LITERALS = 256;
var L_CODES = LITERALS + 1 + LENGTH_CODES;
var D_CODES = 30;
var BL_CODES = 19;
var HEAP_SIZE = 2 * L_CODES + 1;
var MAX_BITS = 15;
var MIN_MATCH = 3;
var MAX_MATCH = 258;
var MIN_LOOKAHEAD = MAX_MATCH + MIN_MATCH + 1;
var PRESET_DICT = 32;
var INIT_STATE = 42;
var GZIP_STATE = 57;
var EXTRA_STATE = 69;
var NAME_STATE = 73;
var COMMENT_STATE = 91;
var HCRC_STATE = 103;
var BUSY_STATE = 113;
var FINISH_STATE = 666;
var BS_NEED_MORE = 1;
var BS_BLOCK_DONE = 2;
var BS_FINISH_STARTED = 3;
var BS_FINISH_DONE = 4;
var OS_CODE = 3;
var err = (strm, errorCode) => {
  strm.msg = messages[errorCode];
  return errorCode;
};
var rank = (f) => {
  return f * 2 - (f > 4 ? 9 : 0);
};
var zero = (buf) => {
  let len = buf.length;
  while (--len >= 0) {
    buf[len] = 0;
  }
};
var slide_hash = (s) => {
  let n, m;
  let p;
  let wsize = s.w_size;
  n = s.hash_size;
  p = n;
  do {
    m = s.head[--p];
    s.head[p] = m >= wsize ? m - wsize : 0;
  } while (--n);
  n = wsize;
  p = n;
  do {
    m = s.prev[--p];
    s.prev[p] = m >= wsize ? m - wsize : 0;
  } while (--n);
};
var HASH_ZLIB = (s, prev, data) => (prev << s.hash_shift ^ data) & s.hash_mask;
var HASH = HASH_ZLIB;
var flush_pending = (strm) => {
  const s = strm.state;
  let len = s.pending;
  if (len > strm.avail_out) {
    len = strm.avail_out;
  }
  if (len === 0) {
    return;
  }
  strm.output.set(s.pending_buf.subarray(s.pending_out, s.pending_out + len), strm.next_out);
  strm.next_out += len;
  s.pending_out += len;
  strm.total_out += len;
  strm.avail_out -= len;
  s.pending -= len;
  if (s.pending === 0) {
    s.pending_out = 0;
  }
};
var flush_block_only = (s, last) => {
  _tr_flush_block(s, s.block_start >= 0 ? s.block_start : -1, s.strstart - s.block_start, last);
  s.block_start = s.strstart;
  flush_pending(s.strm);
};
var put_byte = (s, b) => {
  s.pending_buf[s.pending++] = b;
};
var putShortMSB = (s, b) => {
  s.pending_buf[s.pending++] = b >>> 8 & 255;
  s.pending_buf[s.pending++] = b & 255;
};
var read_buf = (strm, buf, start, size) => {
  let len = strm.avail_in;
  if (len > size) {
    len = size;
  }
  if (len === 0) {
    return 0;
  }
  strm.avail_in -= len;
  buf.set(strm.input.subarray(strm.next_in, strm.next_in + len), start);
  if (strm.state.wrap === 1) {
    strm.adler = adler32_1(strm.adler, buf, len, start);
  } else if (strm.state.wrap === 2) {
    strm.adler = crc32_1(strm.adler, buf, len, start);
  }
  strm.next_in += len;
  strm.total_in += len;
  return len;
};
var longest_match = (s, cur_match) => {
  let chain_length = s.max_chain_length;
  let scan = s.strstart;
  let match;
  let len;
  let best_len = s.prev_length;
  let nice_match = s.nice_match;
  const limit = s.strstart > s.w_size - MIN_LOOKAHEAD ? s.strstart - (s.w_size - MIN_LOOKAHEAD) : 0;
  const _win = s.window;
  const wmask = s.w_mask;
  const prev = s.prev;
  const strend = s.strstart + MAX_MATCH;
  let scan_end1 = _win[scan + best_len - 1];
  let scan_end = _win[scan + best_len];
  if (s.prev_length >= s.good_match) {
    chain_length >>= 2;
  }
  if (nice_match > s.lookahead) {
    nice_match = s.lookahead;
  }
  do {
    match = cur_match;
    if (_win[match + best_len] !== scan_end || _win[match + best_len - 1] !== scan_end1 || _win[match] !== _win[scan] || _win[++match] !== _win[scan + 1]) {
      continue;
    }
    scan += 2;
    match++;
    do {
    } while (_win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && scan < strend);
    len = MAX_MATCH - (strend - scan);
    scan = strend - MAX_MATCH;
    if (len > best_len) {
      s.match_start = cur_match;
      best_len = len;
      if (len >= nice_match) {
        break;
      }
      scan_end1 = _win[scan + best_len - 1];
      scan_end = _win[scan + best_len];
    }
  } while ((cur_match = prev[cur_match & wmask]) > limit && --chain_length !== 0);
  if (best_len <= s.lookahead) {
    return best_len;
  }
  return s.lookahead;
};
var fill_window = (s) => {
  const _w_size = s.w_size;
  let n, more, str;
  do {
    more = s.window_size - s.lookahead - s.strstart;
    if (s.strstart >= _w_size + (_w_size - MIN_LOOKAHEAD)) {
      s.window.set(s.window.subarray(_w_size, _w_size + _w_size - more), 0);
      s.match_start -= _w_size;
      s.strstart -= _w_size;
      s.block_start -= _w_size;
      if (s.insert > s.strstart) {
        s.insert = s.strstart;
      }
      slide_hash(s);
      more += _w_size;
    }
    if (s.strm.avail_in === 0) {
      break;
    }
    n = read_buf(s.strm, s.window, s.strstart + s.lookahead, more);
    s.lookahead += n;
    if (s.lookahead + s.insert >= MIN_MATCH) {
      str = s.strstart - s.insert;
      s.ins_h = s.window[str];
      s.ins_h = HASH(s, s.ins_h, s.window[str + 1]);
      while (s.insert) {
        s.ins_h = HASH(s, s.ins_h, s.window[str + MIN_MATCH - 1]);
        s.prev[str & s.w_mask] = s.head[s.ins_h];
        s.head[s.ins_h] = str;
        str++;
        s.insert--;
        if (s.lookahead + s.insert < MIN_MATCH) {
          break;
        }
      }
    }
  } while (s.lookahead < MIN_LOOKAHEAD && s.strm.avail_in !== 0);
};
var deflate_stored = (s, flush) => {
  let min_block = s.pending_buf_size - 5 > s.w_size ? s.w_size : s.pending_buf_size - 5;
  let len, left, have, last = 0;
  let used = s.strm.avail_in;
  do {
    len = 65535;
    have = s.bi_valid + 42 >> 3;
    if (s.strm.avail_out < have) {
      break;
    }
    have = s.strm.avail_out - have;
    left = s.strstart - s.block_start;
    if (len > left + s.strm.avail_in) {
      len = left + s.strm.avail_in;
    }
    if (len > have) {
      len = have;
    }
    if (len < min_block && (len === 0 && flush !== Z_FINISH$3 || flush === Z_NO_FLUSH$2 || len !== left + s.strm.avail_in)) {
      break;
    }
    last = flush === Z_FINISH$3 && len === left + s.strm.avail_in ? 1 : 0;
    _tr_stored_block(s, 0, 0, last);
    s.pending_buf[s.pending - 4] = len;
    s.pending_buf[s.pending - 3] = len >> 8;
    s.pending_buf[s.pending - 2] = ~len;
    s.pending_buf[s.pending - 1] = ~len >> 8;
    flush_pending(s.strm);
    if (left) {
      if (left > len) {
        left = len;
      }
      s.strm.output.set(s.window.subarray(s.block_start, s.block_start + left), s.strm.next_out);
      s.strm.next_out += left;
      s.strm.avail_out -= left;
      s.strm.total_out += left;
      s.block_start += left;
      len -= left;
    }
    if (len) {
      read_buf(s.strm, s.strm.output, s.strm.next_out, len);
      s.strm.next_out += len;
      s.strm.avail_out -= len;
      s.strm.total_out += len;
    }
  } while (last === 0);
  used -= s.strm.avail_in;
  if (used) {
    if (used >= s.w_size) {
      s.matches = 2;
      s.window.set(s.strm.input.subarray(s.strm.next_in - s.w_size, s.strm.next_in), 0);
      s.strstart = s.w_size;
      s.insert = s.strstart;
    } else {
      if (s.window_size - s.strstart <= used) {
        s.strstart -= s.w_size;
        s.window.set(s.window.subarray(s.w_size, s.w_size + s.strstart), 0);
        if (s.matches < 2) {
          s.matches++;
        }
        if (s.insert > s.strstart) {
          s.insert = s.strstart;
        }
      }
      s.window.set(s.strm.input.subarray(s.strm.next_in - used, s.strm.next_in), s.strstart);
      s.strstart += used;
      s.insert += used > s.w_size - s.insert ? s.w_size - s.insert : used;
    }
    s.block_start = s.strstart;
  }
  if (s.high_water < s.strstart) {
    s.high_water = s.strstart;
  }
  if (last) {
    return BS_FINISH_DONE;
  }
  if (flush !== Z_NO_FLUSH$2 && flush !== Z_FINISH$3 && s.strm.avail_in === 0 && s.strstart === s.block_start) {
    return BS_BLOCK_DONE;
  }
  have = s.window_size - s.strstart;
  if (s.strm.avail_in > have && s.block_start >= s.w_size) {
    s.block_start -= s.w_size;
    s.strstart -= s.w_size;
    s.window.set(s.window.subarray(s.w_size, s.w_size + s.strstart), 0);
    if (s.matches < 2) {
      s.matches++;
    }
    have += s.w_size;
    if (s.insert > s.strstart) {
      s.insert = s.strstart;
    }
  }
  if (have > s.strm.avail_in) {
    have = s.strm.avail_in;
  }
  if (have) {
    read_buf(s.strm, s.window, s.strstart, have);
    s.strstart += have;
    s.insert += have > s.w_size - s.insert ? s.w_size - s.insert : have;
  }
  if (s.high_water < s.strstart) {
    s.high_water = s.strstart;
  }
  have = s.bi_valid + 42 >> 3;
  have = s.pending_buf_size - have > 65535 ? 65535 : s.pending_buf_size - have;
  min_block = have > s.w_size ? s.w_size : have;
  left = s.strstart - s.block_start;
  if (left >= min_block || (left || flush === Z_FINISH$3) && flush !== Z_NO_FLUSH$2 && s.strm.avail_in === 0 && left <= have) {
    len = left > have ? have : left;
    last = flush === Z_FINISH$3 && s.strm.avail_in === 0 && len === left ? 1 : 0;
    _tr_stored_block(s, s.block_start, len, last);
    s.block_start += len;
    flush_pending(s.strm);
  }
  return last ? BS_FINISH_STARTED : BS_NEED_MORE;
};
var deflate_fast = (s, flush) => {
  let hash_head;
  let bflush;
  for (; ; ) {
    if (s.lookahead < MIN_LOOKAHEAD) {
      fill_window(s);
      if (s.lookahead < MIN_LOOKAHEAD && flush === Z_NO_FLUSH$2) {
        return BS_NEED_MORE;
      }
      if (s.lookahead === 0) {
        break;
      }
    }
    hash_head = 0;
    if (s.lookahead >= MIN_MATCH) {
      s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + MIN_MATCH - 1]);
      hash_head = s.prev[s.strstart & s.w_mask] = s.head[s.ins_h];
      s.head[s.ins_h] = s.strstart;
    }
    if (hash_head !== 0 && s.strstart - hash_head <= s.w_size - MIN_LOOKAHEAD) {
      s.match_length = longest_match(s, hash_head);
    }
    if (s.match_length >= MIN_MATCH) {
      bflush = _tr_tally(s, s.strstart - s.match_start, s.match_length - MIN_MATCH);
      s.lookahead -= s.match_length;
      if (s.match_length <= s.max_lazy_match && s.lookahead >= MIN_MATCH) {
        s.match_length--;
        do {
          s.strstart++;
          s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + MIN_MATCH - 1]);
          hash_head = s.prev[s.strstart & s.w_mask] = s.head[s.ins_h];
          s.head[s.ins_h] = s.strstart;
        } while (--s.match_length !== 0);
        s.strstart++;
      } else {
        s.strstart += s.match_length;
        s.match_length = 0;
        s.ins_h = s.window[s.strstart];
        s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + 1]);
      }
    } else {
      bflush = _tr_tally(s, 0, s.window[s.strstart]);
      s.lookahead--;
      s.strstart++;
    }
    if (bflush) {
      flush_block_only(s, false);
      if (s.strm.avail_out === 0) {
        return BS_NEED_MORE;
      }
    }
  }
  s.insert = s.strstart < MIN_MATCH - 1 ? s.strstart : MIN_MATCH - 1;
  if (flush === Z_FINISH$3) {
    flush_block_only(s, true);
    if (s.strm.avail_out === 0) {
      return BS_FINISH_STARTED;
    }
    return BS_FINISH_DONE;
  }
  if (s.sym_next) {
    flush_block_only(s, false);
    if (s.strm.avail_out === 0) {
      return BS_NEED_MORE;
    }
  }
  return BS_BLOCK_DONE;
};
var deflate_slow = (s, flush) => {
  let hash_head;
  let bflush;
  let max_insert;
  for (; ; ) {
    if (s.lookahead < MIN_LOOKAHEAD) {
      fill_window(s);
      if (s.lookahead < MIN_LOOKAHEAD && flush === Z_NO_FLUSH$2) {
        return BS_NEED_MORE;
      }
      if (s.lookahead === 0) {
        break;
      }
    }
    hash_head = 0;
    if (s.lookahead >= MIN_MATCH) {
      s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + MIN_MATCH - 1]);
      hash_head = s.prev[s.strstart & s.w_mask] = s.head[s.ins_h];
      s.head[s.ins_h] = s.strstart;
    }
    s.prev_length = s.match_length;
    s.prev_match = s.match_start;
    s.match_length = MIN_MATCH - 1;
    if (hash_head !== 0 && s.prev_length < s.max_lazy_match && s.strstart - hash_head <= s.w_size - MIN_LOOKAHEAD) {
      s.match_length = longest_match(s, hash_head);
      if (s.match_length <= 5 && (s.strategy === Z_FILTERED || s.match_length === MIN_MATCH && s.strstart - s.match_start > 4096)) {
        s.match_length = MIN_MATCH - 1;
      }
    }
    if (s.prev_length >= MIN_MATCH && s.match_length <= s.prev_length) {
      max_insert = s.strstart + s.lookahead - MIN_MATCH;
      bflush = _tr_tally(s, s.strstart - 1 - s.prev_match, s.prev_length - MIN_MATCH);
      s.lookahead -= s.prev_length - 1;
      s.prev_length -= 2;
      do {
        if (++s.strstart <= max_insert) {
          s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + MIN_MATCH - 1]);
          hash_head = s.prev[s.strstart & s.w_mask] = s.head[s.ins_h];
          s.head[s.ins_h] = s.strstart;
        }
      } while (--s.prev_length !== 0);
      s.match_available = 0;
      s.match_length = MIN_MATCH - 1;
      s.strstart++;
      if (bflush) {
        flush_block_only(s, false);
        if (s.strm.avail_out === 0) {
          return BS_NEED_MORE;
        }
      }
    } else if (s.match_available) {
      bflush = _tr_tally(s, 0, s.window[s.strstart - 1]);
      if (bflush) {
        flush_block_only(s, false);
      }
      s.strstart++;
      s.lookahead--;
      if (s.strm.avail_out === 0) {
        return BS_NEED_MORE;
      }
    } else {
      s.match_available = 1;
      s.strstart++;
      s.lookahead--;
    }
  }
  if (s.match_available) {
    bflush = _tr_tally(s, 0, s.window[s.strstart - 1]);
    s.match_available = 0;
  }
  s.insert = s.strstart < MIN_MATCH - 1 ? s.strstart : MIN_MATCH - 1;
  if (flush === Z_FINISH$3) {
    flush_block_only(s, true);
    if (s.strm.avail_out === 0) {
      return BS_FINISH_STARTED;
    }
    return BS_FINISH_DONE;
  }
  if (s.sym_next) {
    flush_block_only(s, false);
    if (s.strm.avail_out === 0) {
      return BS_NEED_MORE;
    }
  }
  return BS_BLOCK_DONE;
};
var deflate_rle = (s, flush) => {
  let bflush;
  let prev;
  let scan, strend;
  const _win = s.window;
  for (; ; ) {
    if (s.lookahead <= MAX_MATCH) {
      fill_window(s);
      if (s.lookahead <= MAX_MATCH && flush === Z_NO_FLUSH$2) {
        return BS_NEED_MORE;
      }
      if (s.lookahead === 0) {
        break;
      }
    }
    s.match_length = 0;
    if (s.lookahead >= MIN_MATCH && s.strstart > 0) {
      scan = s.strstart - 1;
      prev = _win[scan];
      if (prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan]) {
        strend = s.strstart + MAX_MATCH;
        do {
        } while (prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && scan < strend);
        s.match_length = MAX_MATCH - (strend - scan);
        if (s.match_length > s.lookahead) {
          s.match_length = s.lookahead;
        }
      }
    }
    if (s.match_length >= MIN_MATCH) {
      bflush = _tr_tally(s, 1, s.match_length - MIN_MATCH);
      s.lookahead -= s.match_length;
      s.strstart += s.match_length;
      s.match_length = 0;
    } else {
      bflush = _tr_tally(s, 0, s.window[s.strstart]);
      s.lookahead--;
      s.strstart++;
    }
    if (bflush) {
      flush_block_only(s, false);
      if (s.strm.avail_out === 0) {
        return BS_NEED_MORE;
      }
    }
  }
  s.insert = 0;
  if (flush === Z_FINISH$3) {
    flush_block_only(s, true);
    if (s.strm.avail_out === 0) {
      return BS_FINISH_STARTED;
    }
    return BS_FINISH_DONE;
  }
  if (s.sym_next) {
    flush_block_only(s, false);
    if (s.strm.avail_out === 0) {
      return BS_NEED_MORE;
    }
  }
  return BS_BLOCK_DONE;
};
var deflate_huff = (s, flush) => {
  let bflush;
  for (; ; ) {
    if (s.lookahead === 0) {
      fill_window(s);
      if (s.lookahead === 0) {
        if (flush === Z_NO_FLUSH$2) {
          return BS_NEED_MORE;
        }
        break;
      }
    }
    s.match_length = 0;
    bflush = _tr_tally(s, 0, s.window[s.strstart]);
    s.lookahead--;
    s.strstart++;
    if (bflush) {
      flush_block_only(s, false);
      if (s.strm.avail_out === 0) {
        return BS_NEED_MORE;
      }
    }
  }
  s.insert = 0;
  if (flush === Z_FINISH$3) {
    flush_block_only(s, true);
    if (s.strm.avail_out === 0) {
      return BS_FINISH_STARTED;
    }
    return BS_FINISH_DONE;
  }
  if (s.sym_next) {
    flush_block_only(s, false);
    if (s.strm.avail_out === 0) {
      return BS_NEED_MORE;
    }
  }
  return BS_BLOCK_DONE;
};
function Config(good_length, max_lazy, nice_length, max_chain, func) {
  this.good_length = good_length;
  this.max_lazy = max_lazy;
  this.nice_length = nice_length;
  this.max_chain = max_chain;
  this.func = func;
}
var configuration_table = [
  /*      good lazy nice chain */
  new Config(0, 0, 0, 0, deflate_stored),
  /* 0 store only */
  new Config(4, 4, 8, 4, deflate_fast),
  /* 1 max speed, no lazy matches */
  new Config(4, 5, 16, 8, deflate_fast),
  /* 2 */
  new Config(4, 6, 32, 32, deflate_fast),
  /* 3 */
  new Config(4, 4, 16, 16, deflate_slow),
  /* 4 lazy matches */
  new Config(8, 16, 32, 32, deflate_slow),
  /* 5 */
  new Config(8, 16, 128, 128, deflate_slow),
  /* 6 */
  new Config(8, 32, 128, 256, deflate_slow),
  /* 7 */
  new Config(32, 128, 258, 1024, deflate_slow),
  /* 8 */
  new Config(32, 258, 258, 4096, deflate_slow)
  /* 9 max compression */
];
var lm_init = (s) => {
  s.window_size = 2 * s.w_size;
  zero(s.head);
  s.max_lazy_match = configuration_table[s.level].max_lazy;
  s.good_match = configuration_table[s.level].good_length;
  s.nice_match = configuration_table[s.level].nice_length;
  s.max_chain_length = configuration_table[s.level].max_chain;
  s.strstart = 0;
  s.block_start = 0;
  s.lookahead = 0;
  s.insert = 0;
  s.match_length = s.prev_length = MIN_MATCH - 1;
  s.match_available = 0;
  s.ins_h = 0;
};
function DeflateState() {
  this.strm = null;
  this.status = 0;
  this.pending_buf = null;
  this.pending_buf_size = 0;
  this.pending_out = 0;
  this.pending = 0;
  this.wrap = 0;
  this.gzhead = null;
  this.gzindex = 0;
  this.method = Z_DEFLATED$2;
  this.last_flush = -1;
  this.w_size = 0;
  this.w_bits = 0;
  this.w_mask = 0;
  this.window = null;
  this.window_size = 0;
  this.prev = null;
  this.head = null;
  this.ins_h = 0;
  this.hash_size = 0;
  this.hash_bits = 0;
  this.hash_mask = 0;
  this.hash_shift = 0;
  this.block_start = 0;
  this.match_length = 0;
  this.prev_match = 0;
  this.match_available = 0;
  this.strstart = 0;
  this.match_start = 0;
  this.lookahead = 0;
  this.prev_length = 0;
  this.max_chain_length = 0;
  this.max_lazy_match = 0;
  this.level = 0;
  this.strategy = 0;
  this.good_match = 0;
  this.nice_match = 0;
  this.dyn_ltree = new Uint16Array(HEAP_SIZE * 2);
  this.dyn_dtree = new Uint16Array((2 * D_CODES + 1) * 2);
  this.bl_tree = new Uint16Array((2 * BL_CODES + 1) * 2);
  zero(this.dyn_ltree);
  zero(this.dyn_dtree);
  zero(this.bl_tree);
  this.l_desc = null;
  this.d_desc = null;
  this.bl_desc = null;
  this.bl_count = new Uint16Array(MAX_BITS + 1);
  this.heap = new Uint16Array(2 * L_CODES + 1);
  zero(this.heap);
  this.heap_len = 0;
  this.heap_max = 0;
  this.depth = new Uint16Array(2 * L_CODES + 1);
  zero(this.depth);
  this.sym_buf = 0;
  this.lit_bufsize = 0;
  this.sym_next = 0;
  this.sym_end = 0;
  this.opt_len = 0;
  this.static_len = 0;
  this.matches = 0;
  this.insert = 0;
  this.bi_buf = 0;
  this.bi_valid = 0;
}
var deflateStateCheck = (strm) => {
  if (!strm) {
    return 1;
  }
  const s = strm.state;
  if (!s || s.strm !== strm || s.status !== INIT_STATE && //#ifdef GZIP
  s.status !== GZIP_STATE && //#endif
  s.status !== EXTRA_STATE && s.status !== NAME_STATE && s.status !== COMMENT_STATE && s.status !== HCRC_STATE && s.status !== BUSY_STATE && s.status !== FINISH_STATE) {
    return 1;
  }
  return 0;
};
var deflateResetKeep = (strm) => {
  if (deflateStateCheck(strm)) {
    return err(strm, Z_STREAM_ERROR$2);
  }
  strm.total_in = strm.total_out = 0;
  strm.data_type = Z_UNKNOWN;
  const s = strm.state;
  s.pending = 0;
  s.pending_out = 0;
  if (s.wrap < 0) {
    s.wrap = -s.wrap;
  }
  s.status = //#ifdef GZIP
  s.wrap === 2 ? GZIP_STATE : (
    //#endif
    s.wrap ? INIT_STATE : BUSY_STATE
  );
  strm.adler = s.wrap === 2 ? 0 : 1;
  s.last_flush = -2;
  _tr_init(s);
  return Z_OK$3;
};
var deflateReset = (strm) => {
  const ret = deflateResetKeep(strm);
  if (ret === Z_OK$3) {
    lm_init(strm.state);
  }
  return ret;
};
var deflateSetHeader = (strm, head) => {
  if (deflateStateCheck(strm) || strm.state.wrap !== 2) {
    return Z_STREAM_ERROR$2;
  }
  strm.state.gzhead = head;
  return Z_OK$3;
};
var deflateInit2 = (strm, level, method, windowBits, memLevel, strategy) => {
  if (!strm) {
    return Z_STREAM_ERROR$2;
  }
  let wrap = 1;
  if (level === Z_DEFAULT_COMPRESSION$1) {
    level = 6;
  }
  if (windowBits < 0) {
    wrap = 0;
    windowBits = -windowBits;
  } else if (windowBits > 15) {
    wrap = 2;
    windowBits -= 16;
  }
  if (memLevel < 1 || memLevel > MAX_MEM_LEVEL || method !== Z_DEFLATED$2 || windowBits < 8 || windowBits > 15 || level < 0 || level > 9 || strategy < 0 || strategy > Z_FIXED || windowBits === 8 && wrap !== 1) {
    return err(strm, Z_STREAM_ERROR$2);
  }
  if (windowBits === 8) {
    windowBits = 9;
  }
  const s = new DeflateState();
  strm.state = s;
  s.strm = strm;
  s.status = INIT_STATE;
  s.wrap = wrap;
  s.gzhead = null;
  s.w_bits = windowBits;
  s.w_size = 1 << s.w_bits;
  s.w_mask = s.w_size - 1;
  s.hash_bits = memLevel + 7;
  s.hash_size = 1 << s.hash_bits;
  s.hash_mask = s.hash_size - 1;
  s.hash_shift = ~~((s.hash_bits + MIN_MATCH - 1) / MIN_MATCH);
  s.window = new Uint8Array(s.w_size * 2);
  s.head = new Uint16Array(s.hash_size);
  s.prev = new Uint16Array(s.w_size);
  s.lit_bufsize = 1 << memLevel + 6;
  s.pending_buf_size = s.lit_bufsize * 4;
  s.pending_buf = new Uint8Array(s.pending_buf_size);
  s.sym_buf = s.lit_bufsize;
  s.sym_end = (s.lit_bufsize - 1) * 3;
  s.level = level;
  s.strategy = strategy;
  s.method = method;
  return deflateReset(strm);
};
var deflateInit = (strm, level) => {
  return deflateInit2(strm, level, Z_DEFLATED$2, MAX_WBITS$1, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY$1);
};
var deflate$2 = (strm, flush) => {
  if (deflateStateCheck(strm) || flush > Z_BLOCK$1 || flush < 0) {
    return strm ? err(strm, Z_STREAM_ERROR$2) : Z_STREAM_ERROR$2;
  }
  const s = strm.state;
  if (!strm.output || strm.avail_in !== 0 && !strm.input || s.status === FINISH_STATE && flush !== Z_FINISH$3) {
    return err(strm, strm.avail_out === 0 ? Z_BUF_ERROR$1 : Z_STREAM_ERROR$2);
  }
  const old_flush = s.last_flush;
  s.last_flush = flush;
  if (s.pending !== 0) {
    flush_pending(strm);
    if (strm.avail_out === 0) {
      s.last_flush = -1;
      return Z_OK$3;
    }
  } else if (strm.avail_in === 0 && rank(flush) <= rank(old_flush) && flush !== Z_FINISH$3) {
    return err(strm, Z_BUF_ERROR$1);
  }
  if (s.status === FINISH_STATE && strm.avail_in !== 0) {
    return err(strm, Z_BUF_ERROR$1);
  }
  if (s.status === INIT_STATE && s.wrap === 0) {
    s.status = BUSY_STATE;
  }
  if (s.status === INIT_STATE) {
    let header = Z_DEFLATED$2 + (s.w_bits - 8 << 4) << 8;
    let level_flags = -1;
    if (s.strategy >= Z_HUFFMAN_ONLY || s.level < 2) {
      level_flags = 0;
    } else if (s.level < 6) {
      level_flags = 1;
    } else if (s.level === 6) {
      level_flags = 2;
    } else {
      level_flags = 3;
    }
    header |= level_flags << 6;
    if (s.strstart !== 0) {
      header |= PRESET_DICT;
    }
    header += 31 - header % 31;
    putShortMSB(s, header);
    if (s.strstart !== 0) {
      putShortMSB(s, strm.adler >>> 16);
      putShortMSB(s, strm.adler & 65535);
    }
    strm.adler = 1;
    s.status = BUSY_STATE;
    flush_pending(strm);
    if (s.pending !== 0) {
      s.last_flush = -1;
      return Z_OK$3;
    }
  }
  if (s.status === GZIP_STATE) {
    strm.adler = 0;
    put_byte(s, 31);
    put_byte(s, 139);
    put_byte(s, 8);
    if (!s.gzhead) {
      put_byte(s, 0);
      put_byte(s, 0);
      put_byte(s, 0);
      put_byte(s, 0);
      put_byte(s, 0);
      put_byte(s, s.level === 9 ? 2 : s.strategy >= Z_HUFFMAN_ONLY || s.level < 2 ? 4 : 0);
      put_byte(s, OS_CODE);
      s.status = BUSY_STATE;
      flush_pending(strm);
      if (s.pending !== 0) {
        s.last_flush = -1;
        return Z_OK$3;
      }
    } else {
      put_byte(
        s,
        (s.gzhead.text ? 1 : 0) + (s.gzhead.hcrc ? 2 : 0) + (!s.gzhead.extra ? 0 : 4) + (!s.gzhead.name ? 0 : 8) + (!s.gzhead.comment ? 0 : 16)
      );
      put_byte(s, s.gzhead.time & 255);
      put_byte(s, s.gzhead.time >> 8 & 255);
      put_byte(s, s.gzhead.time >> 16 & 255);
      put_byte(s, s.gzhead.time >> 24 & 255);
      put_byte(s, s.level === 9 ? 2 : s.strategy >= Z_HUFFMAN_ONLY || s.level < 2 ? 4 : 0);
      put_byte(s, s.gzhead.os & 255);
      if (s.gzhead.extra && s.gzhead.extra.length) {
        put_byte(s, s.gzhead.extra.length & 255);
        put_byte(s, s.gzhead.extra.length >> 8 & 255);
      }
      if (s.gzhead.hcrc) {
        strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending, 0);
      }
      s.gzindex = 0;
      s.status = EXTRA_STATE;
    }
  }
  if (s.status === EXTRA_STATE) {
    if (s.gzhead.extra) {
      let beg = s.pending;
      let left = (s.gzhead.extra.length & 65535) - s.gzindex;
      while (s.pending + left > s.pending_buf_size) {
        let copy = s.pending_buf_size - s.pending;
        s.pending_buf.set(s.gzhead.extra.subarray(s.gzindex, s.gzindex + copy), s.pending);
        s.pending = s.pending_buf_size;
        if (s.gzhead.hcrc && s.pending > beg) {
          strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
        }
        s.gzindex += copy;
        flush_pending(strm);
        if (s.pending !== 0) {
          s.last_flush = -1;
          return Z_OK$3;
        }
        beg = 0;
        left -= copy;
      }
      let gzhead_extra = new Uint8Array(s.gzhead.extra);
      s.pending_buf.set(gzhead_extra.subarray(s.gzindex, s.gzindex + left), s.pending);
      s.pending += left;
      if (s.gzhead.hcrc && s.pending > beg) {
        strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
      }
      s.gzindex = 0;
    }
    s.status = NAME_STATE;
  }
  if (s.status === NAME_STATE) {
    if (s.gzhead.name) {
      let beg = s.pending;
      let val;
      do {
        if (s.pending === s.pending_buf_size) {
          if (s.gzhead.hcrc && s.pending > beg) {
            strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
          }
          flush_pending(strm);
          if (s.pending !== 0) {
            s.last_flush = -1;
            return Z_OK$3;
          }
          beg = 0;
        }
        if (s.gzindex < s.gzhead.name.length) {
          val = s.gzhead.name.charCodeAt(s.gzindex++) & 255;
        } else {
          val = 0;
        }
        put_byte(s, val);
      } while (val !== 0);
      if (s.gzhead.hcrc && s.pending > beg) {
        strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
      }
      s.gzindex = 0;
    }
    s.status = COMMENT_STATE;
  }
  if (s.status === COMMENT_STATE) {
    if (s.gzhead.comment) {
      let beg = s.pending;
      let val;
      do {
        if (s.pending === s.pending_buf_size) {
          if (s.gzhead.hcrc && s.pending > beg) {
            strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
          }
          flush_pending(strm);
          if (s.pending !== 0) {
            s.last_flush = -1;
            return Z_OK$3;
          }
          beg = 0;
        }
        if (s.gzindex < s.gzhead.comment.length) {
          val = s.gzhead.comment.charCodeAt(s.gzindex++) & 255;
        } else {
          val = 0;
        }
        put_byte(s, val);
      } while (val !== 0);
      if (s.gzhead.hcrc && s.pending > beg) {
        strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
      }
    }
    s.status = HCRC_STATE;
  }
  if (s.status === HCRC_STATE) {
    if (s.gzhead.hcrc) {
      if (s.pending + 2 > s.pending_buf_size) {
        flush_pending(strm);
        if (s.pending !== 0) {
          s.last_flush = -1;
          return Z_OK$3;
        }
      }
      put_byte(s, strm.adler & 255);
      put_byte(s, strm.adler >> 8 & 255);
      strm.adler = 0;
    }
    s.status = BUSY_STATE;
    flush_pending(strm);
    if (s.pending !== 0) {
      s.last_flush = -1;
      return Z_OK$3;
    }
  }
  if (strm.avail_in !== 0 || s.lookahead !== 0 || flush !== Z_NO_FLUSH$2 && s.status !== FINISH_STATE) {
    let bstate = s.level === 0 ? deflate_stored(s, flush) : s.strategy === Z_HUFFMAN_ONLY ? deflate_huff(s, flush) : s.strategy === Z_RLE ? deflate_rle(s, flush) : configuration_table[s.level].func(s, flush);
    if (bstate === BS_FINISH_STARTED || bstate === BS_FINISH_DONE) {
      s.status = FINISH_STATE;
    }
    if (bstate === BS_NEED_MORE || bstate === BS_FINISH_STARTED) {
      if (strm.avail_out === 0) {
        s.last_flush = -1;
      }
      return Z_OK$3;
    }
    if (bstate === BS_BLOCK_DONE) {
      if (flush === Z_PARTIAL_FLUSH) {
        _tr_align(s);
      } else if (flush !== Z_BLOCK$1) {
        _tr_stored_block(s, 0, 0, false);
        if (flush === Z_FULL_FLUSH$1) {
          zero(s.head);
          if (s.lookahead === 0) {
            s.strstart = 0;
            s.block_start = 0;
            s.insert = 0;
          }
        }
      }
      flush_pending(strm);
      if (strm.avail_out === 0) {
        s.last_flush = -1;
        return Z_OK$3;
      }
    }
  }
  if (flush !== Z_FINISH$3) {
    return Z_OK$3;
  }
  if (s.wrap <= 0) {
    return Z_STREAM_END$3;
  }
  if (s.wrap === 2) {
    put_byte(s, strm.adler & 255);
    put_byte(s, strm.adler >> 8 & 255);
    put_byte(s, strm.adler >> 16 & 255);
    put_byte(s, strm.adler >> 24 & 255);
    put_byte(s, strm.total_in & 255);
    put_byte(s, strm.total_in >> 8 & 255);
    put_byte(s, strm.total_in >> 16 & 255);
    put_byte(s, strm.total_in >> 24 & 255);
  } else {
    putShortMSB(s, strm.adler >>> 16);
    putShortMSB(s, strm.adler & 65535);
  }
  flush_pending(strm);
  if (s.wrap > 0) {
    s.wrap = -s.wrap;
  }
  return s.pending !== 0 ? Z_OK$3 : Z_STREAM_END$3;
};
var deflateEnd = (strm) => {
  if (deflateStateCheck(strm)) {
    return Z_STREAM_ERROR$2;
  }
  const status = strm.state.status;
  strm.state = null;
  return status === BUSY_STATE ? err(strm, Z_DATA_ERROR$2) : Z_OK$3;
};
var deflateSetDictionary = (strm, dictionary) => {
  let dictLength = dictionary.length;
  if (deflateStateCheck(strm)) {
    return Z_STREAM_ERROR$2;
  }
  const s = strm.state;
  const wrap = s.wrap;
  if (wrap === 2 || wrap === 1 && s.status !== INIT_STATE || s.lookahead) {
    return Z_STREAM_ERROR$2;
  }
  if (wrap === 1) {
    strm.adler = adler32_1(strm.adler, dictionary, dictLength, 0);
  }
  s.wrap = 0;
  if (dictLength >= s.w_size) {
    if (wrap === 0) {
      zero(s.head);
      s.strstart = 0;
      s.block_start = 0;
      s.insert = 0;
    }
    let tmpDict = new Uint8Array(s.w_size);
    tmpDict.set(dictionary.subarray(dictLength - s.w_size, dictLength), 0);
    dictionary = tmpDict;
    dictLength = s.w_size;
  }
  const avail = strm.avail_in;
  const next = strm.next_in;
  const input = strm.input;
  strm.avail_in = dictLength;
  strm.next_in = 0;
  strm.input = dictionary;
  fill_window(s);
  while (s.lookahead >= MIN_MATCH) {
    let str = s.strstart;
    let n = s.lookahead - (MIN_MATCH - 1);
    do {
      s.ins_h = HASH(s, s.ins_h, s.window[str + MIN_MATCH - 1]);
      s.prev[str & s.w_mask] = s.head[s.ins_h];
      s.head[s.ins_h] = str;
      str++;
    } while (--n);
    s.strstart = str;
    s.lookahead = MIN_MATCH - 1;
    fill_window(s);
  }
  s.strstart += s.lookahead;
  s.block_start = s.strstart;
  s.insert = s.lookahead;
  s.lookahead = 0;
  s.match_length = s.prev_length = MIN_MATCH - 1;
  s.match_available = 0;
  strm.next_in = next;
  strm.input = input;
  strm.avail_in = avail;
  s.wrap = wrap;
  return Z_OK$3;
};
var deflateInit_1 = deflateInit;
var deflateInit2_1 = deflateInit2;
var deflateReset_1 = deflateReset;
var deflateResetKeep_1 = deflateResetKeep;
var deflateSetHeader_1 = deflateSetHeader;
var deflate_2$1 = deflate$2;
var deflateEnd_1 = deflateEnd;
var deflateSetDictionary_1 = deflateSetDictionary;
var deflateInfo = "pako deflate (from Nodeca project)";
var deflate_1$2 = {
  deflateInit: deflateInit_1,
  deflateInit2: deflateInit2_1,
  deflateReset: deflateReset_1,
  deflateResetKeep: deflateResetKeep_1,
  deflateSetHeader: deflateSetHeader_1,
  deflate: deflate_2$1,
  deflateEnd: deflateEnd_1,
  deflateSetDictionary: deflateSetDictionary_1,
  deflateInfo
};
var _has = (obj, key) => {
  return Object.prototype.hasOwnProperty.call(obj, key);
};
var assign = function(obj) {
  const sources = Array.prototype.slice.call(arguments, 1);
  while (sources.length) {
    const source = sources.shift();
    if (!source) {
      continue;
    }
    if (typeof source !== "object") {
      throw new TypeError(source + "must be non-object");
    }
    for (const p in source) {
      if (_has(source, p)) {
        obj[p] = source[p];
      }
    }
  }
  return obj;
};
var flattenChunks = (chunks) => {
  let len = 0;
  for (let i = 0, l = chunks.length; i < l; i++) {
    len += chunks[i].length;
  }
  const result = new Uint8Array(len);
  for (let i = 0, pos = 0, l = chunks.length; i < l; i++) {
    let chunk = chunks[i];
    result.set(chunk, pos);
    pos += chunk.length;
  }
  return result;
};
var common = {
  assign,
  flattenChunks
};
var STR_APPLY_UIA_OK = true;
try {
  String.fromCharCode.apply(null, new Uint8Array(1));
} catch (__) {
  STR_APPLY_UIA_OK = false;
}
var _utf8len = new Uint8Array(256);
for (let q = 0; q < 256; q++) {
  _utf8len[q] = q >= 252 ? 6 : q >= 248 ? 5 : q >= 240 ? 4 : q >= 224 ? 3 : q >= 192 ? 2 : 1;
}
_utf8len[254] = _utf8len[254] = 1;
var string2buf = (str) => {
  if (typeof TextEncoder === "function" && TextEncoder.prototype.encode) {
    return new TextEncoder().encode(str);
  }
  let buf, c, c2, m_pos, i, str_len = str.length, buf_len = 0;
  for (m_pos = 0; m_pos < str_len; m_pos++) {
    c = str.charCodeAt(m_pos);
    if ((c & 64512) === 55296 && m_pos + 1 < str_len) {
      c2 = str.charCodeAt(m_pos + 1);
      if ((c2 & 64512) === 56320) {
        c = 65536 + (c - 55296 << 10) + (c2 - 56320);
        m_pos++;
      }
    }
    buf_len += c < 128 ? 1 : c < 2048 ? 2 : c < 65536 ? 3 : 4;
  }
  buf = new Uint8Array(buf_len);
  for (i = 0, m_pos = 0; i < buf_len; m_pos++) {
    c = str.charCodeAt(m_pos);
    if ((c & 64512) === 55296 && m_pos + 1 < str_len) {
      c2 = str.charCodeAt(m_pos + 1);
      if ((c2 & 64512) === 56320) {
        c = 65536 + (c - 55296 << 10) + (c2 - 56320);
        m_pos++;
      }
    }
    if (c < 128) {
      buf[i++] = c;
    } else if (c < 2048) {
      buf[i++] = 192 | c >>> 6;
      buf[i++] = 128 | c & 63;
    } else if (c < 65536) {
      buf[i++] = 224 | c >>> 12;
      buf[i++] = 128 | c >>> 6 & 63;
      buf[i++] = 128 | c & 63;
    } else {
      buf[i++] = 240 | c >>> 18;
      buf[i++] = 128 | c >>> 12 & 63;
      buf[i++] = 128 | c >>> 6 & 63;
      buf[i++] = 128 | c & 63;
    }
  }
  return buf;
};
var buf2binstring = (buf, len) => {
  if (len < 65534) {
    if (buf.subarray && STR_APPLY_UIA_OK) {
      return String.fromCharCode.apply(null, buf.length === len ? buf : buf.subarray(0, len));
    }
  }
  let result = "";
  for (let i = 0; i < len; i++) {
    result += String.fromCharCode(buf[i]);
  }
  return result;
};
var buf2string = (buf, max) => {
  const len = max || buf.length;
  if (typeof TextDecoder === "function" && TextDecoder.prototype.decode) {
    return new TextDecoder().decode(buf.subarray(0, max));
  }
  let i, out;
  const utf16buf = new Array(len * 2);
  for (out = 0, i = 0; i < len; ) {
    let c = buf[i++];
    if (c < 128) {
      utf16buf[out++] = c;
      continue;
    }
    let c_len = _utf8len[c];
    if (c_len > 4) {
      utf16buf[out++] = 65533;
      i += c_len - 1;
      continue;
    }
    c &= c_len === 2 ? 31 : c_len === 3 ? 15 : 7;
    while (c_len > 1 && i < len) {
      c = c << 6 | buf[i++] & 63;
      c_len--;
    }
    if (c_len > 1) {
      utf16buf[out++] = 65533;
      continue;
    }
    if (c < 65536) {
      utf16buf[out++] = c;
    } else {
      c -= 65536;
      utf16buf[out++] = 55296 | c >> 10 & 1023;
      utf16buf[out++] = 56320 | c & 1023;
    }
  }
  return buf2binstring(utf16buf, out);
};
var utf8border = (buf, max) => {
  max = max || buf.length;
  if (max > buf.length) {
    max = buf.length;
  }
  let pos = max - 1;
  while (pos >= 0 && (buf[pos] & 192) === 128) {
    pos--;
  }
  if (pos < 0) {
    return max;
  }
  if (pos === 0) {
    return max;
  }
  return pos + _utf8len[buf[pos]] > max ? pos : max;
};
var strings = {
  string2buf,
  buf2string,
  utf8border
};
function ZStream() {
  this.input = null;
  this.next_in = 0;
  this.avail_in = 0;
  this.total_in = 0;
  this.output = null;
  this.next_out = 0;
  this.avail_out = 0;
  this.total_out = 0;
  this.msg = "";
  this.state = null;
  this.data_type = 2;
  this.adler = 0;
}
var zstream = ZStream;
var toString$1 = Object.prototype.toString;
var {
  Z_NO_FLUSH: Z_NO_FLUSH$1,
  Z_SYNC_FLUSH,
  Z_FULL_FLUSH,
  Z_FINISH: Z_FINISH$2,
  Z_OK: Z_OK$2,
  Z_STREAM_END: Z_STREAM_END$2,
  Z_DEFAULT_COMPRESSION,
  Z_DEFAULT_STRATEGY,
  Z_DEFLATED: Z_DEFLATED$1
} = constants$2;
function Deflate$1(options) {
  this.options = common.assign({
    level: Z_DEFAULT_COMPRESSION,
    method: Z_DEFLATED$1,
    chunkSize: 16384,
    windowBits: 15,
    memLevel: 8,
    strategy: Z_DEFAULT_STRATEGY
  }, options || {});
  let opt = this.options;
  if (opt.raw && opt.windowBits > 0) {
    opt.windowBits = -opt.windowBits;
  } else if (opt.gzip && opt.windowBits > 0 && opt.windowBits < 16) {
    opt.windowBits += 16;
  }
  this.err = 0;
  this.msg = "";
  this.ended = false;
  this.chunks = [];
  this.strm = new zstream();
  this.strm.avail_out = 0;
  let status = deflate_1$2.deflateInit2(
    this.strm,
    opt.level,
    opt.method,
    opt.windowBits,
    opt.memLevel,
    opt.strategy
  );
  if (status !== Z_OK$2) {
    throw new Error(messages[status]);
  }
  if (opt.header) {
    deflate_1$2.deflateSetHeader(this.strm, opt.header);
  }
  if (opt.dictionary) {
    let dict;
    if (typeof opt.dictionary === "string") {
      dict = strings.string2buf(opt.dictionary);
    } else if (toString$1.call(opt.dictionary) === "[object ArrayBuffer]") {
      dict = new Uint8Array(opt.dictionary);
    } else {
      dict = opt.dictionary;
    }
    status = deflate_1$2.deflateSetDictionary(this.strm, dict);
    if (status !== Z_OK$2) {
      throw new Error(messages[status]);
    }
    this._dict_set = true;
  }
}
Deflate$1.prototype.push = function(data, flush_mode) {
  const strm = this.strm;
  const chunkSize = this.options.chunkSize;
  let status, _flush_mode;
  if (this.ended) {
    return false;
  }
  if (flush_mode === ~~flush_mode) _flush_mode = flush_mode;
  else _flush_mode = flush_mode === true ? Z_FINISH$2 : Z_NO_FLUSH$1;
  if (typeof data === "string") {
    strm.input = strings.string2buf(data);
  } else if (toString$1.call(data) === "[object ArrayBuffer]") {
    strm.input = new Uint8Array(data);
  } else {
    strm.input = data;
  }
  strm.next_in = 0;
  strm.avail_in = strm.input.length;
  for (; ; ) {
    if (strm.avail_out === 0) {
      strm.output = new Uint8Array(chunkSize);
      strm.next_out = 0;
      strm.avail_out = chunkSize;
    }
    if ((_flush_mode === Z_SYNC_FLUSH || _flush_mode === Z_FULL_FLUSH) && strm.avail_out <= 6) {
      this.onData(strm.output.subarray(0, strm.next_out));
      strm.avail_out = 0;
      continue;
    }
    status = deflate_1$2.deflate(strm, _flush_mode);
    if (status === Z_STREAM_END$2) {
      if (strm.next_out > 0) {
        this.onData(strm.output.subarray(0, strm.next_out));
      }
      status = deflate_1$2.deflateEnd(this.strm);
      this.onEnd(status);
      this.ended = true;
      return status === Z_OK$2;
    }
    if (strm.avail_out === 0) {
      this.onData(strm.output);
      continue;
    }
    if (_flush_mode > 0 && strm.next_out > 0) {
      this.onData(strm.output.subarray(0, strm.next_out));
      strm.avail_out = 0;
      continue;
    }
    if (strm.avail_in === 0) break;
  }
  return true;
};
Deflate$1.prototype.onData = function(chunk) {
  this.chunks.push(chunk);
};
Deflate$1.prototype.onEnd = function(status) {
  if (status === Z_OK$2) {
    this.result = common.flattenChunks(this.chunks);
  }
  this.chunks = [];
  this.err = status;
  this.msg = this.strm.msg;
};
function deflate$1(input, options) {
  const deflator = new Deflate$1(options);
  deflator.push(input, true);
  if (deflator.err) {
    throw deflator.msg || messages[deflator.err];
  }
  return deflator.result;
}
function deflateRaw$1(input, options) {
  options = options || {};
  options.raw = true;
  return deflate$1(input, options);
}
function gzip$1(input, options) {
  options = options || {};
  options.gzip = true;
  return deflate$1(input, options);
}
var Deflate_1$1 = Deflate$1;
var deflate_2 = deflate$1;
var deflateRaw_1$1 = deflateRaw$1;
var gzip_1$1 = gzip$1;
var constants$1 = constants$2;
var deflate_1$1 = {
  Deflate: Deflate_1$1,
  deflate: deflate_2,
  deflateRaw: deflateRaw_1$1,
  gzip: gzip_1$1,
  constants: constants$1
};
var BAD$1 = 16209;
var TYPE$1 = 16191;
var inffast = function inflate_fast(strm, start) {
  let _in;
  let last;
  let _out;
  let beg;
  let end;
  let dmax;
  let wsize;
  let whave;
  let wnext;
  let s_window;
  let hold;
  let bits;
  let lcode;
  let dcode;
  let lmask;
  let dmask;
  let here;
  let op;
  let len;
  let dist;
  let from;
  let from_source;
  let input, output;
  const state = strm.state;
  _in = strm.next_in;
  input = strm.input;
  last = _in + (strm.avail_in - 5);
  _out = strm.next_out;
  output = strm.output;
  beg = _out - (start - strm.avail_out);
  end = _out + (strm.avail_out - 257);
  dmax = state.dmax;
  wsize = state.wsize;
  whave = state.whave;
  wnext = state.wnext;
  s_window = state.window;
  hold = state.hold;
  bits = state.bits;
  lcode = state.lencode;
  dcode = state.distcode;
  lmask = (1 << state.lenbits) - 1;
  dmask = (1 << state.distbits) - 1;
  top:
    do {
      if (bits < 15) {
        hold += input[_in++] << bits;
        bits += 8;
        hold += input[_in++] << bits;
        bits += 8;
      }
      here = lcode[hold & lmask];
      dolen:
        for (; ; ) {
          op = here >>> 24;
          hold >>>= op;
          bits -= op;
          op = here >>> 16 & 255;
          if (op === 0) {
            output[_out++] = here & 65535;
          } else if (op & 16) {
            len = here & 65535;
            op &= 15;
            if (op) {
              if (bits < op) {
                hold += input[_in++] << bits;
                bits += 8;
              }
              len += hold & (1 << op) - 1;
              hold >>>= op;
              bits -= op;
            }
            if (bits < 15) {
              hold += input[_in++] << bits;
              bits += 8;
              hold += input[_in++] << bits;
              bits += 8;
            }
            here = dcode[hold & dmask];
            dodist:
              for (; ; ) {
                op = here >>> 24;
                hold >>>= op;
                bits -= op;
                op = here >>> 16 & 255;
                if (op & 16) {
                  dist = here & 65535;
                  op &= 15;
                  if (bits < op) {
                    hold += input[_in++] << bits;
                    bits += 8;
                    if (bits < op) {
                      hold += input[_in++] << bits;
                      bits += 8;
                    }
                  }
                  dist += hold & (1 << op) - 1;
                  if (dist > dmax) {
                    strm.msg = "invalid distance too far back";
                    state.mode = BAD$1;
                    break top;
                  }
                  hold >>>= op;
                  bits -= op;
                  op = _out - beg;
                  if (dist > op) {
                    op = dist - op;
                    if (op > whave) {
                      if (state.sane) {
                        strm.msg = "invalid distance too far back";
                        state.mode = BAD$1;
                        break top;
                      }
                    }
                    from = 0;
                    from_source = s_window;
                    if (wnext === 0) {
                      from += wsize - op;
                      if (op < len) {
                        len -= op;
                        do {
                          output[_out++] = s_window[from++];
                        } while (--op);
                        from = _out - dist;
                        from_source = output;
                      }
                    } else if (wnext < op) {
                      from += wsize + wnext - op;
                      op -= wnext;
                      if (op < len) {
                        len -= op;
                        do {
                          output[_out++] = s_window[from++];
                        } while (--op);
                        from = 0;
                        if (wnext < len) {
                          op = wnext;
                          len -= op;
                          do {
                            output[_out++] = s_window[from++];
                          } while (--op);
                          from = _out - dist;
                          from_source = output;
                        }
                      }
                    } else {
                      from += wnext - op;
                      if (op < len) {
                        len -= op;
                        do {
                          output[_out++] = s_window[from++];
                        } while (--op);
                        from = _out - dist;
                        from_source = output;
                      }
                    }
                    while (len > 2) {
                      output[_out++] = from_source[from++];
                      output[_out++] = from_source[from++];
                      output[_out++] = from_source[from++];
                      len -= 3;
                    }
                    if (len) {
                      output[_out++] = from_source[from++];
                      if (len > 1) {
                        output[_out++] = from_source[from++];
                      }
                    }
                  } else {
                    from = _out - dist;
                    do {
                      output[_out++] = output[from++];
                      output[_out++] = output[from++];
                      output[_out++] = output[from++];
                      len -= 3;
                    } while (len > 2);
                    if (len) {
                      output[_out++] = output[from++];
                      if (len > 1) {
                        output[_out++] = output[from++];
                      }
                    }
                  }
                } else if ((op & 64) === 0) {
                  here = dcode[(here & 65535) + (hold & (1 << op) - 1)];
                  continue dodist;
                } else {
                  strm.msg = "invalid distance code";
                  state.mode = BAD$1;
                  break top;
                }
                break;
              }
          } else if ((op & 64) === 0) {
            here = lcode[(here & 65535) + (hold & (1 << op) - 1)];
            continue dolen;
          } else if (op & 32) {
            state.mode = TYPE$1;
            break top;
          } else {
            strm.msg = "invalid literal/length code";
            state.mode = BAD$1;
            break top;
          }
          break;
        }
    } while (_in < last && _out < end);
  len = bits >> 3;
  _in -= len;
  bits -= len << 3;
  hold &= (1 << bits) - 1;
  strm.next_in = _in;
  strm.next_out = _out;
  strm.avail_in = _in < last ? 5 + (last - _in) : 5 - (_in - last);
  strm.avail_out = _out < end ? 257 + (end - _out) : 257 - (_out - end);
  state.hold = hold;
  state.bits = bits;
  return;
};
var MAXBITS = 15;
var ENOUGH_LENS$1 = 852;
var ENOUGH_DISTS$1 = 592;
var CODES$1 = 0;
var LENS$1 = 1;
var DISTS$1 = 2;
var lbase = new Uint16Array([
  /* Length codes 257..285 base */
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  13,
  15,
  17,
  19,
  23,
  27,
  31,
  35,
  43,
  51,
  59,
  67,
  83,
  99,
  115,
  131,
  163,
  195,
  227,
  258,
  0,
  0
]);
var lext = new Uint8Array([
  /* Length codes 257..285 extra */
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  17,
  17,
  17,
  17,
  18,
  18,
  18,
  18,
  19,
  19,
  19,
  19,
  20,
  20,
  20,
  20,
  21,
  21,
  21,
  21,
  16,
  72,
  78
]);
var dbase = new Uint16Array([
  /* Distance codes 0..29 base */
  1,
  2,
  3,
  4,
  5,
  7,
  9,
  13,
  17,
  25,
  33,
  49,
  65,
  97,
  129,
  193,
  257,
  385,
  513,
  769,
  1025,
  1537,
  2049,
  3073,
  4097,
  6145,
  8193,
  12289,
  16385,
  24577,
  0,
  0
]);
var dext = new Uint8Array([
  /* Distance codes 0..29 extra */
  16,
  16,
  16,
  16,
  17,
  17,
  18,
  18,
  19,
  19,
  20,
  20,
  21,
  21,
  22,
  22,
  23,
  23,
  24,
  24,
  25,
  25,
  26,
  26,
  27,
  27,
  28,
  28,
  29,
  29,
  64,
  64
]);
var inflate_table = (type, lens, lens_index, codes, table, table_index, work, opts) => {
  const bits = opts.bits;
  let len = 0;
  let sym = 0;
  let min = 0, max = 0;
  let root = 0;
  let curr = 0;
  let drop = 0;
  let left = 0;
  let used = 0;
  let huff = 0;
  let incr;
  let fill;
  let low;
  let mask;
  let next;
  let base = null;
  let match;
  const count = new Uint16Array(MAXBITS + 1);
  const offs = new Uint16Array(MAXBITS + 1);
  let extra = null;
  let here_bits, here_op, here_val;
  for (len = 0; len <= MAXBITS; len++) {
    count[len] = 0;
  }
  for (sym = 0; sym < codes; sym++) {
    count[lens[lens_index + sym]]++;
  }
  root = bits;
  for (max = MAXBITS; max >= 1; max--) {
    if (count[max] !== 0) {
      break;
    }
  }
  if (root > max) {
    root = max;
  }
  if (max === 0) {
    table[table_index++] = 1 << 24 | 64 << 16 | 0;
    table[table_index++] = 1 << 24 | 64 << 16 | 0;
    opts.bits = 1;
    return 0;
  }
  for (min = 1; min < max; min++) {
    if (count[min] !== 0) {
      break;
    }
  }
  if (root < min) {
    root = min;
  }
  left = 1;
  for (len = 1; len <= MAXBITS; len++) {
    left <<= 1;
    left -= count[len];
    if (left < 0) {
      return -1;
    }
  }
  if (left > 0 && (type === CODES$1 || max !== 1)) {
    return -1;
  }
  offs[1] = 0;
  for (len = 1; len < MAXBITS; len++) {
    offs[len + 1] = offs[len] + count[len];
  }
  for (sym = 0; sym < codes; sym++) {
    if (lens[lens_index + sym] !== 0) {
      work[offs[lens[lens_index + sym]]++] = sym;
    }
  }
  if (type === CODES$1) {
    base = extra = work;
    match = 20;
  } else if (type === LENS$1) {
    base = lbase;
    extra = lext;
    match = 257;
  } else {
    base = dbase;
    extra = dext;
    match = 0;
  }
  huff = 0;
  sym = 0;
  len = min;
  next = table_index;
  curr = root;
  drop = 0;
  low = -1;
  used = 1 << root;
  mask = used - 1;
  if (type === LENS$1 && used > ENOUGH_LENS$1 || type === DISTS$1 && used > ENOUGH_DISTS$1) {
    return 1;
  }
  for (; ; ) {
    here_bits = len - drop;
    if (work[sym] + 1 < match) {
      here_op = 0;
      here_val = work[sym];
    } else if (work[sym] >= match) {
      here_op = extra[work[sym] - match];
      here_val = base[work[sym] - match];
    } else {
      here_op = 32 + 64;
      here_val = 0;
    }
    incr = 1 << len - drop;
    fill = 1 << curr;
    min = fill;
    do {
      fill -= incr;
      table[next + (huff >> drop) + fill] = here_bits << 24 | here_op << 16 | here_val | 0;
    } while (fill !== 0);
    incr = 1 << len - 1;
    while (huff & incr) {
      incr >>= 1;
    }
    if (incr !== 0) {
      huff &= incr - 1;
      huff += incr;
    } else {
      huff = 0;
    }
    sym++;
    if (--count[len] === 0) {
      if (len === max) {
        break;
      }
      len = lens[lens_index + work[sym]];
    }
    if (len > root && (huff & mask) !== low) {
      if (drop === 0) {
        drop = root;
      }
      next += min;
      curr = len - drop;
      left = 1 << curr;
      while (curr + drop < max) {
        left -= count[curr + drop];
        if (left <= 0) {
          break;
        }
        curr++;
        left <<= 1;
      }
      used += 1 << curr;
      if (type === LENS$1 && used > ENOUGH_LENS$1 || type === DISTS$1 && used > ENOUGH_DISTS$1) {
        return 1;
      }
      low = huff & mask;
      table[low] = root << 24 | curr << 16 | next - table_index | 0;
    }
  }
  if (huff !== 0) {
    table[next + huff] = len - drop << 24 | 64 << 16 | 0;
  }
  opts.bits = root;
  return 0;
};
var inftrees = inflate_table;
var CODES = 0;
var LENS = 1;
var DISTS = 2;
var {
  Z_FINISH: Z_FINISH$1,
  Z_BLOCK,
  Z_TREES,
  Z_OK: Z_OK$1,
  Z_STREAM_END: Z_STREAM_END$1,
  Z_NEED_DICT: Z_NEED_DICT$1,
  Z_STREAM_ERROR: Z_STREAM_ERROR$1,
  Z_DATA_ERROR: Z_DATA_ERROR$1,
  Z_MEM_ERROR: Z_MEM_ERROR$1,
  Z_BUF_ERROR,
  Z_DEFLATED
} = constants$2;
var HEAD = 16180;
var FLAGS = 16181;
var TIME = 16182;
var OS = 16183;
var EXLEN = 16184;
var EXTRA = 16185;
var NAME = 16186;
var COMMENT = 16187;
var HCRC = 16188;
var DICTID = 16189;
var DICT = 16190;
var TYPE = 16191;
var TYPEDO = 16192;
var STORED = 16193;
var COPY_ = 16194;
var COPY = 16195;
var TABLE = 16196;
var LENLENS = 16197;
var CODELENS = 16198;
var LEN_ = 16199;
var LEN = 16200;
var LENEXT = 16201;
var DIST = 16202;
var DISTEXT = 16203;
var MATCH = 16204;
var LIT = 16205;
var CHECK = 16206;
var LENGTH = 16207;
var DONE = 16208;
var BAD = 16209;
var MEM = 16210;
var SYNC = 16211;
var ENOUGH_LENS = 852;
var ENOUGH_DISTS = 592;
var MAX_WBITS = 15;
var DEF_WBITS = MAX_WBITS;
var zswap32 = (q) => {
  return (q >>> 24 & 255) + (q >>> 8 & 65280) + ((q & 65280) << 8) + ((q & 255) << 24);
};
function InflateState() {
  this.strm = null;
  this.mode = 0;
  this.last = false;
  this.wrap = 0;
  this.havedict = false;
  this.flags = 0;
  this.dmax = 0;
  this.check = 0;
  this.total = 0;
  this.head = null;
  this.wbits = 0;
  this.wsize = 0;
  this.whave = 0;
  this.wnext = 0;
  this.window = null;
  this.hold = 0;
  this.bits = 0;
  this.length = 0;
  this.offset = 0;
  this.extra = 0;
  this.lencode = null;
  this.distcode = null;
  this.lenbits = 0;
  this.distbits = 0;
  this.ncode = 0;
  this.nlen = 0;
  this.ndist = 0;
  this.have = 0;
  this.next = null;
  this.lens = new Uint16Array(320);
  this.work = new Uint16Array(288);
  this.lendyn = null;
  this.distdyn = null;
  this.sane = 0;
  this.back = 0;
  this.was = 0;
}
var inflateStateCheck = (strm) => {
  if (!strm) {
    return 1;
  }
  const state = strm.state;
  if (!state || state.strm !== strm || state.mode < HEAD || state.mode > SYNC) {
    return 1;
  }
  return 0;
};
var inflateResetKeep = (strm) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  strm.total_in = strm.total_out = state.total = 0;
  strm.msg = "";
  if (state.wrap) {
    strm.adler = state.wrap & 1;
  }
  state.mode = HEAD;
  state.last = 0;
  state.havedict = 0;
  state.flags = -1;
  state.dmax = 32768;
  state.head = null;
  state.hold = 0;
  state.bits = 0;
  state.lencode = state.lendyn = new Int32Array(ENOUGH_LENS);
  state.distcode = state.distdyn = new Int32Array(ENOUGH_DISTS);
  state.sane = 1;
  state.back = -1;
  return Z_OK$1;
};
var inflateReset = (strm) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  state.wsize = 0;
  state.whave = 0;
  state.wnext = 0;
  return inflateResetKeep(strm);
};
var inflateReset2 = (strm, windowBits) => {
  let wrap;
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  if (windowBits < 0) {
    wrap = 0;
    windowBits = -windowBits;
  } else {
    wrap = (windowBits >> 4) + 5;
    if (windowBits < 48) {
      windowBits &= 15;
    }
  }
  if (windowBits && (windowBits < 8 || windowBits > 15)) {
    return Z_STREAM_ERROR$1;
  }
  if (state.window !== null && state.wbits !== windowBits) {
    state.window = null;
  }
  state.wrap = wrap;
  state.wbits = windowBits;
  return inflateReset(strm);
};
var inflateInit2 = (strm, windowBits) => {
  if (!strm) {
    return Z_STREAM_ERROR$1;
  }
  const state = new InflateState();
  strm.state = state;
  state.strm = strm;
  state.window = null;
  state.mode = HEAD;
  const ret = inflateReset2(strm, windowBits);
  if (ret !== Z_OK$1) {
    strm.state = null;
  }
  return ret;
};
var inflateInit = (strm) => {
  return inflateInit2(strm, DEF_WBITS);
};
var virgin = true;
var lenfix;
var distfix;
var fixedtables = (state) => {
  if (virgin) {
    lenfix = new Int32Array(512);
    distfix = new Int32Array(32);
    let sym = 0;
    while (sym < 144) {
      state.lens[sym++] = 8;
    }
    while (sym < 256) {
      state.lens[sym++] = 9;
    }
    while (sym < 280) {
      state.lens[sym++] = 7;
    }
    while (sym < 288) {
      state.lens[sym++] = 8;
    }
    inftrees(LENS, state.lens, 0, 288, lenfix, 0, state.work, { bits: 9 });
    sym = 0;
    while (sym < 32) {
      state.lens[sym++] = 5;
    }
    inftrees(DISTS, state.lens, 0, 32, distfix, 0, state.work, { bits: 5 });
    virgin = false;
  }
  state.lencode = lenfix;
  state.lenbits = 9;
  state.distcode = distfix;
  state.distbits = 5;
};
var updatewindow = (strm, src, end, copy) => {
  let dist;
  const state = strm.state;
  if (state.window === null) {
    state.wsize = 1 << state.wbits;
    state.wnext = 0;
    state.whave = 0;
    state.window = new Uint8Array(state.wsize);
  }
  if (copy >= state.wsize) {
    state.window.set(src.subarray(end - state.wsize, end), 0);
    state.wnext = 0;
    state.whave = state.wsize;
  } else {
    dist = state.wsize - state.wnext;
    if (dist > copy) {
      dist = copy;
    }
    state.window.set(src.subarray(end - copy, end - copy + dist), state.wnext);
    copy -= dist;
    if (copy) {
      state.window.set(src.subarray(end - copy, end), 0);
      state.wnext = copy;
      state.whave = state.wsize;
    } else {
      state.wnext += dist;
      if (state.wnext === state.wsize) {
        state.wnext = 0;
      }
      if (state.whave < state.wsize) {
        state.whave += dist;
      }
    }
  }
  return 0;
};
var inflate$2 = (strm, flush) => {
  let state;
  let input, output;
  let next;
  let put;
  let have, left;
  let hold;
  let bits;
  let _in, _out;
  let copy;
  let from;
  let from_source;
  let here = 0;
  let here_bits, here_op, here_val;
  let last_bits, last_op, last_val;
  let len;
  let ret;
  const hbuf = new Uint8Array(4);
  let opts;
  let n;
  const order = (
    /* permutation of code lengths */
    new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15])
  );
  if (inflateStateCheck(strm) || !strm.output || !strm.input && strm.avail_in !== 0) {
    return Z_STREAM_ERROR$1;
  }
  state = strm.state;
  if (state.mode === TYPE) {
    state.mode = TYPEDO;
  }
  put = strm.next_out;
  output = strm.output;
  left = strm.avail_out;
  next = strm.next_in;
  input = strm.input;
  have = strm.avail_in;
  hold = state.hold;
  bits = state.bits;
  _in = have;
  _out = left;
  ret = Z_OK$1;
  inf_leave:
    for (; ; ) {
      switch (state.mode) {
        case HEAD:
          if (state.wrap === 0) {
            state.mode = TYPEDO;
            break;
          }
          while (bits < 16) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (state.wrap & 2 && hold === 35615) {
            if (state.wbits === 0) {
              state.wbits = 15;
            }
            state.check = 0;
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            state.check = crc32_1(state.check, hbuf, 2, 0);
            hold = 0;
            bits = 0;
            state.mode = FLAGS;
            break;
          }
          if (state.head) {
            state.head.done = false;
          }
          if (!(state.wrap & 1) || /* check if zlib header allowed */
          (((hold & 255) << 8) + (hold >> 8)) % 31) {
            strm.msg = "incorrect header check";
            state.mode = BAD;
            break;
          }
          if ((hold & 15) !== Z_DEFLATED) {
            strm.msg = "unknown compression method";
            state.mode = BAD;
            break;
          }
          hold >>>= 4;
          bits -= 4;
          len = (hold & 15) + 8;
          if (state.wbits === 0) {
            state.wbits = len;
          }
          if (len > 15 || len > state.wbits) {
            strm.msg = "invalid window size";
            state.mode = BAD;
            break;
          }
          state.dmax = 1 << state.wbits;
          state.flags = 0;
          strm.adler = state.check = 1;
          state.mode = hold & 512 ? DICTID : TYPE;
          hold = 0;
          bits = 0;
          break;
        case FLAGS:
          while (bits < 16) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          state.flags = hold;
          if ((state.flags & 255) !== Z_DEFLATED) {
            strm.msg = "unknown compression method";
            state.mode = BAD;
            break;
          }
          if (state.flags & 57344) {
            strm.msg = "unknown header flags set";
            state.mode = BAD;
            break;
          }
          if (state.head) {
            state.head.text = hold >> 8 & 1;
          }
          if (state.flags & 512 && state.wrap & 4) {
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            state.check = crc32_1(state.check, hbuf, 2, 0);
          }
          hold = 0;
          bits = 0;
          state.mode = TIME;
        /* falls through */
        case TIME:
          while (bits < 32) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (state.head) {
            state.head.time = hold;
          }
          if (state.flags & 512 && state.wrap & 4) {
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            hbuf[2] = hold >>> 16 & 255;
            hbuf[3] = hold >>> 24 & 255;
            state.check = crc32_1(state.check, hbuf, 4, 0);
          }
          hold = 0;
          bits = 0;
          state.mode = OS;
        /* falls through */
        case OS:
          while (bits < 16) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (state.head) {
            state.head.xflags = hold & 255;
            state.head.os = hold >> 8;
          }
          if (state.flags & 512 && state.wrap & 4) {
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            state.check = crc32_1(state.check, hbuf, 2, 0);
          }
          hold = 0;
          bits = 0;
          state.mode = EXLEN;
        /* falls through */
        case EXLEN:
          if (state.flags & 1024) {
            while (bits < 16) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.length = hold;
            if (state.head) {
              state.head.extra_len = hold;
            }
            if (state.flags & 512 && state.wrap & 4) {
              hbuf[0] = hold & 255;
              hbuf[1] = hold >>> 8 & 255;
              state.check = crc32_1(state.check, hbuf, 2, 0);
            }
            hold = 0;
            bits = 0;
          } else if (state.head) {
            state.head.extra = null;
          }
          state.mode = EXTRA;
        /* falls through */
        case EXTRA:
          if (state.flags & 1024) {
            copy = state.length;
            if (copy > have) {
              copy = have;
            }
            if (copy) {
              if (state.head) {
                len = state.head.extra_len - state.length;
                if (!state.head.extra) {
                  state.head.extra = new Uint8Array(state.head.extra_len);
                }
                state.head.extra.set(
                  input.subarray(
                    next,
                    // extra field is limited to 65536 bytes
                    // - no need for additional size check
                    next + copy
                  ),
                  /*len + copy > state.head.extra_max - len ? state.head.extra_max : copy,*/
                  len
                );
              }
              if (state.flags & 512 && state.wrap & 4) {
                state.check = crc32_1(state.check, input, copy, next);
              }
              have -= copy;
              next += copy;
              state.length -= copy;
            }
            if (state.length) {
              break inf_leave;
            }
          }
          state.length = 0;
          state.mode = NAME;
        /* falls through */
        case NAME:
          if (state.flags & 2048) {
            if (have === 0) {
              break inf_leave;
            }
            copy = 0;
            do {
              len = input[next + copy++];
              if (state.head && len && state.length < 65536) {
                state.head.name += String.fromCharCode(len);
              }
            } while (len && copy < have);
            if (state.flags & 512 && state.wrap & 4) {
              state.check = crc32_1(state.check, input, copy, next);
            }
            have -= copy;
            next += copy;
            if (len) {
              break inf_leave;
            }
          } else if (state.head) {
            state.head.name = null;
          }
          state.length = 0;
          state.mode = COMMENT;
        /* falls through */
        case COMMENT:
          if (state.flags & 4096) {
            if (have === 0) {
              break inf_leave;
            }
            copy = 0;
            do {
              len = input[next + copy++];
              if (state.head && len && state.length < 65536) {
                state.head.comment += String.fromCharCode(len);
              }
            } while (len && copy < have);
            if (state.flags & 512 && state.wrap & 4) {
              state.check = crc32_1(state.check, input, copy, next);
            }
            have -= copy;
            next += copy;
            if (len) {
              break inf_leave;
            }
          } else if (state.head) {
            state.head.comment = null;
          }
          state.mode = HCRC;
        /* falls through */
        case HCRC:
          if (state.flags & 512) {
            while (bits < 16) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            if (state.wrap & 4 && hold !== (state.check & 65535)) {
              strm.msg = "header crc mismatch";
              state.mode = BAD;
              break;
            }
            hold = 0;
            bits = 0;
          }
          if (state.head) {
            state.head.hcrc = state.flags >> 9 & 1;
            state.head.done = true;
          }
          strm.adler = state.check = 0;
          state.mode = TYPE;
          break;
        case DICTID:
          while (bits < 32) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          strm.adler = state.check = zswap32(hold);
          hold = 0;
          bits = 0;
          state.mode = DICT;
        /* falls through */
        case DICT:
          if (state.havedict === 0) {
            strm.next_out = put;
            strm.avail_out = left;
            strm.next_in = next;
            strm.avail_in = have;
            state.hold = hold;
            state.bits = bits;
            return Z_NEED_DICT$1;
          }
          strm.adler = state.check = 1;
          state.mode = TYPE;
        /* falls through */
        case TYPE:
          if (flush === Z_BLOCK || flush === Z_TREES) {
            break inf_leave;
          }
        /* falls through */
        case TYPEDO:
          if (state.last) {
            hold >>>= bits & 7;
            bits -= bits & 7;
            state.mode = CHECK;
            break;
          }
          while (bits < 3) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          state.last = hold & 1;
          hold >>>= 1;
          bits -= 1;
          switch (hold & 3) {
            case 0:
              state.mode = STORED;
              break;
            case 1:
              fixedtables(state);
              state.mode = LEN_;
              if (flush === Z_TREES) {
                hold >>>= 2;
                bits -= 2;
                break inf_leave;
              }
              break;
            case 2:
              state.mode = TABLE;
              break;
            case 3:
              strm.msg = "invalid block type";
              state.mode = BAD;
          }
          hold >>>= 2;
          bits -= 2;
          break;
        case STORED:
          hold >>>= bits & 7;
          bits -= bits & 7;
          while (bits < 32) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if ((hold & 65535) !== (hold >>> 16 ^ 65535)) {
            strm.msg = "invalid stored block lengths";
            state.mode = BAD;
            break;
          }
          state.length = hold & 65535;
          hold = 0;
          bits = 0;
          state.mode = COPY_;
          if (flush === Z_TREES) {
            break inf_leave;
          }
        /* falls through */
        case COPY_:
          state.mode = COPY;
        /* falls through */
        case COPY:
          copy = state.length;
          if (copy) {
            if (copy > have) {
              copy = have;
            }
            if (copy > left) {
              copy = left;
            }
            if (copy === 0) {
              break inf_leave;
            }
            output.set(input.subarray(next, next + copy), put);
            have -= copy;
            next += copy;
            left -= copy;
            put += copy;
            state.length -= copy;
            break;
          }
          state.mode = TYPE;
          break;
        case TABLE:
          while (bits < 14) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          state.nlen = (hold & 31) + 257;
          hold >>>= 5;
          bits -= 5;
          state.ndist = (hold & 31) + 1;
          hold >>>= 5;
          bits -= 5;
          state.ncode = (hold & 15) + 4;
          hold >>>= 4;
          bits -= 4;
          if (state.nlen > 286 || state.ndist > 30) {
            strm.msg = "too many length or distance symbols";
            state.mode = BAD;
            break;
          }
          state.have = 0;
          state.mode = LENLENS;
        /* falls through */
        case LENLENS:
          while (state.have < state.ncode) {
            while (bits < 3) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.lens[order[state.have++]] = hold & 7;
            hold >>>= 3;
            bits -= 3;
          }
          while (state.have < 19) {
            state.lens[order[state.have++]] = 0;
          }
          state.lencode = state.lendyn;
          state.lenbits = 7;
          opts = { bits: state.lenbits };
          ret = inftrees(CODES, state.lens, 0, 19, state.lencode, 0, state.work, opts);
          state.lenbits = opts.bits;
          if (ret) {
            strm.msg = "invalid code lengths set";
            state.mode = BAD;
            break;
          }
          state.have = 0;
          state.mode = CODELENS;
        /* falls through */
        case CODELENS:
          while (state.have < state.nlen + state.ndist) {
            for (; ; ) {
              here = state.lencode[hold & (1 << state.lenbits) - 1];
              here_bits = here >>> 24;
              here_op = here >>> 16 & 255;
              here_val = here & 65535;
              if (here_bits <= bits) {
                break;
              }
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            if (here_val < 16) {
              hold >>>= here_bits;
              bits -= here_bits;
              state.lens[state.have++] = here_val;
            } else {
              if (here_val === 16) {
                n = here_bits + 2;
                while (bits < n) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= here_bits;
                bits -= here_bits;
                if (state.have === 0) {
                  strm.msg = "invalid bit length repeat";
                  state.mode = BAD;
                  break;
                }
                len = state.lens[state.have - 1];
                copy = 3 + (hold & 3);
                hold >>>= 2;
                bits -= 2;
              } else if (here_val === 17) {
                n = here_bits + 3;
                while (bits < n) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= here_bits;
                bits -= here_bits;
                len = 0;
                copy = 3 + (hold & 7);
                hold >>>= 3;
                bits -= 3;
              } else {
                n = here_bits + 7;
                while (bits < n) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= here_bits;
                bits -= here_bits;
                len = 0;
                copy = 11 + (hold & 127);
                hold >>>= 7;
                bits -= 7;
              }
              if (state.have + copy > state.nlen + state.ndist) {
                strm.msg = "invalid bit length repeat";
                state.mode = BAD;
                break;
              }
              while (copy--) {
                state.lens[state.have++] = len;
              }
            }
          }
          if (state.mode === BAD) {
            break;
          }
          if (state.lens[256] === 0) {
            strm.msg = "invalid code -- missing end-of-block";
            state.mode = BAD;
            break;
          }
          state.lenbits = 9;
          opts = { bits: state.lenbits };
          ret = inftrees(LENS, state.lens, 0, state.nlen, state.lencode, 0, state.work, opts);
          state.lenbits = opts.bits;
          if (ret) {
            strm.msg = "invalid literal/lengths set";
            state.mode = BAD;
            break;
          }
          state.distbits = 6;
          state.distcode = state.distdyn;
          opts = { bits: state.distbits };
          ret = inftrees(DISTS, state.lens, state.nlen, state.ndist, state.distcode, 0, state.work, opts);
          state.distbits = opts.bits;
          if (ret) {
            strm.msg = "invalid distances set";
            state.mode = BAD;
            break;
          }
          state.mode = LEN_;
          if (flush === Z_TREES) {
            break inf_leave;
          }
        /* falls through */
        case LEN_:
          state.mode = LEN;
        /* falls through */
        case LEN:
          if (have >= 6 && left >= 258) {
            strm.next_out = put;
            strm.avail_out = left;
            strm.next_in = next;
            strm.avail_in = have;
            state.hold = hold;
            state.bits = bits;
            inffast(strm, _out);
            put = strm.next_out;
            output = strm.output;
            left = strm.avail_out;
            next = strm.next_in;
            input = strm.input;
            have = strm.avail_in;
            hold = state.hold;
            bits = state.bits;
            if (state.mode === TYPE) {
              state.back = -1;
            }
            break;
          }
          state.back = 0;
          for (; ; ) {
            here = state.lencode[hold & (1 << state.lenbits) - 1];
            here_bits = here >>> 24;
            here_op = here >>> 16 & 255;
            here_val = here & 65535;
            if (here_bits <= bits) {
              break;
            }
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (here_op && (here_op & 240) === 0) {
            last_bits = here_bits;
            last_op = here_op;
            last_val = here_val;
            for (; ; ) {
              here = state.lencode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
              here_bits = here >>> 24;
              here_op = here >>> 16 & 255;
              here_val = here & 65535;
              if (last_bits + here_bits <= bits) {
                break;
              }
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            hold >>>= last_bits;
            bits -= last_bits;
            state.back += last_bits;
          }
          hold >>>= here_bits;
          bits -= here_bits;
          state.back += here_bits;
          state.length = here_val;
          if (here_op === 0) {
            state.mode = LIT;
            break;
          }
          if (here_op & 32) {
            state.back = -1;
            state.mode = TYPE;
            break;
          }
          if (here_op & 64) {
            strm.msg = "invalid literal/length code";
            state.mode = BAD;
            break;
          }
          state.extra = here_op & 15;
          state.mode = LENEXT;
        /* falls through */
        case LENEXT:
          if (state.extra) {
            n = state.extra;
            while (bits < n) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.length += hold & (1 << state.extra) - 1;
            hold >>>= state.extra;
            bits -= state.extra;
            state.back += state.extra;
          }
          state.was = state.length;
          state.mode = DIST;
        /* falls through */
        case DIST:
          for (; ; ) {
            here = state.distcode[hold & (1 << state.distbits) - 1];
            here_bits = here >>> 24;
            here_op = here >>> 16 & 255;
            here_val = here & 65535;
            if (here_bits <= bits) {
              break;
            }
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if ((here_op & 240) === 0) {
            last_bits = here_bits;
            last_op = here_op;
            last_val = here_val;
            for (; ; ) {
              here = state.distcode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
              here_bits = here >>> 24;
              here_op = here >>> 16 & 255;
              here_val = here & 65535;
              if (last_bits + here_bits <= bits) {
                break;
              }
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            hold >>>= last_bits;
            bits -= last_bits;
            state.back += last_bits;
          }
          hold >>>= here_bits;
          bits -= here_bits;
          state.back += here_bits;
          if (here_op & 64) {
            strm.msg = "invalid distance code";
            state.mode = BAD;
            break;
          }
          state.offset = here_val;
          state.extra = here_op & 15;
          state.mode = DISTEXT;
        /* falls through */
        case DISTEXT:
          if (state.extra) {
            n = state.extra;
            while (bits < n) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.offset += hold & (1 << state.extra) - 1;
            hold >>>= state.extra;
            bits -= state.extra;
            state.back += state.extra;
          }
          if (state.offset > state.dmax) {
            strm.msg = "invalid distance too far back";
            state.mode = BAD;
            break;
          }
          state.mode = MATCH;
        /* falls through */
        case MATCH:
          if (left === 0) {
            break inf_leave;
          }
          copy = _out - left;
          if (state.offset > copy) {
            copy = state.offset - copy;
            if (copy > state.whave) {
              if (state.sane) {
                strm.msg = "invalid distance too far back";
                state.mode = BAD;
                break;
              }
            }
            if (copy > state.wnext) {
              copy -= state.wnext;
              from = state.wsize - copy;
            } else {
              from = state.wnext - copy;
            }
            if (copy > state.length) {
              copy = state.length;
            }
            from_source = state.window;
          } else {
            from_source = output;
            from = put - state.offset;
            copy = state.length;
          }
          if (copy > left) {
            copy = left;
          }
          left -= copy;
          state.length -= copy;
          do {
            output[put++] = from_source[from++];
          } while (--copy);
          if (state.length === 0) {
            state.mode = LEN;
          }
          break;
        case LIT:
          if (left === 0) {
            break inf_leave;
          }
          output[put++] = state.length;
          left--;
          state.mode = LEN;
          break;
        case CHECK:
          if (state.wrap) {
            while (bits < 32) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold |= input[next++] << bits;
              bits += 8;
            }
            _out -= left;
            strm.total_out += _out;
            state.total += _out;
            if (state.wrap & 4 && _out) {
              strm.adler = state.check = /*UPDATE_CHECK(state.check, put - _out, _out);*/
              state.flags ? crc32_1(state.check, output, _out, put - _out) : adler32_1(state.check, output, _out, put - _out);
            }
            _out = left;
            if (state.wrap & 4 && (state.flags ? hold : zswap32(hold)) !== state.check) {
              strm.msg = "incorrect data check";
              state.mode = BAD;
              break;
            }
            hold = 0;
            bits = 0;
          }
          state.mode = LENGTH;
        /* falls through */
        case LENGTH:
          if (state.wrap && state.flags) {
            while (bits < 32) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            if (state.wrap & 4 && hold !== (state.total & 4294967295)) {
              strm.msg = "incorrect length check";
              state.mode = BAD;
              break;
            }
            hold = 0;
            bits = 0;
          }
          state.mode = DONE;
        /* falls through */
        case DONE:
          ret = Z_STREAM_END$1;
          break inf_leave;
        case BAD:
          ret = Z_DATA_ERROR$1;
          break inf_leave;
        case MEM:
          return Z_MEM_ERROR$1;
        case SYNC:
        /* falls through */
        default:
          return Z_STREAM_ERROR$1;
      }
    }
  strm.next_out = put;
  strm.avail_out = left;
  strm.next_in = next;
  strm.avail_in = have;
  state.hold = hold;
  state.bits = bits;
  if (state.wsize || _out !== strm.avail_out && state.mode < BAD && (state.mode < CHECK || flush !== Z_FINISH$1)) {
    if (updatewindow(strm, strm.output, strm.next_out, _out - strm.avail_out)) ;
  }
  _in -= strm.avail_in;
  _out -= strm.avail_out;
  strm.total_in += _in;
  strm.total_out += _out;
  state.total += _out;
  if (state.wrap & 4 && _out) {
    strm.adler = state.check = /*UPDATE_CHECK(state.check, strm.next_out - _out, _out);*/
    state.flags ? crc32_1(state.check, output, _out, strm.next_out - _out) : adler32_1(state.check, output, _out, strm.next_out - _out);
  }
  strm.data_type = state.bits + (state.last ? 64 : 0) + (state.mode === TYPE ? 128 : 0) + (state.mode === LEN_ || state.mode === COPY_ ? 256 : 0);
  if ((_in === 0 && _out === 0 || flush === Z_FINISH$1) && ret === Z_OK$1) {
    ret = Z_BUF_ERROR;
  }
  return ret;
};
var inflateEnd = (strm) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  let state = strm.state;
  if (state.window) {
    state.window = null;
  }
  strm.state = null;
  return Z_OK$1;
};
var inflateGetHeader = (strm, head) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  if ((state.wrap & 2) === 0) {
    return Z_STREAM_ERROR$1;
  }
  state.head = head;
  head.done = false;
  return Z_OK$1;
};
var inflateSetDictionary = (strm, dictionary) => {
  const dictLength = dictionary.length;
  let state;
  let dictid;
  let ret;
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  state = strm.state;
  if (state.wrap !== 0 && state.mode !== DICT) {
    return Z_STREAM_ERROR$1;
  }
  if (state.mode === DICT) {
    dictid = 1;
    dictid = adler32_1(dictid, dictionary, dictLength, 0);
    if (dictid !== state.check) {
      return Z_DATA_ERROR$1;
    }
  }
  ret = updatewindow(strm, dictionary, dictLength, dictLength);
  if (ret) {
    state.mode = MEM;
    return Z_MEM_ERROR$1;
  }
  state.havedict = 1;
  return Z_OK$1;
};
var inflateReset_1 = inflateReset;
var inflateReset2_1 = inflateReset2;
var inflateResetKeep_1 = inflateResetKeep;
var inflateInit_1 = inflateInit;
var inflateInit2_1 = inflateInit2;
var inflate_2$1 = inflate$2;
var inflateEnd_1 = inflateEnd;
var inflateGetHeader_1 = inflateGetHeader;
var inflateSetDictionary_1 = inflateSetDictionary;
var inflateInfo = "pako inflate (from Nodeca project)";
var inflate_1$2 = {
  inflateReset: inflateReset_1,
  inflateReset2: inflateReset2_1,
  inflateResetKeep: inflateResetKeep_1,
  inflateInit: inflateInit_1,
  inflateInit2: inflateInit2_1,
  inflate: inflate_2$1,
  inflateEnd: inflateEnd_1,
  inflateGetHeader: inflateGetHeader_1,
  inflateSetDictionary: inflateSetDictionary_1,
  inflateInfo
};
function GZheader() {
  this.text = 0;
  this.time = 0;
  this.xflags = 0;
  this.os = 0;
  this.extra = null;
  this.extra_len = 0;
  this.name = "";
  this.comment = "";
  this.hcrc = 0;
  this.done = false;
}
var gzheader = GZheader;
var toString = Object.prototype.toString;
var {
  Z_NO_FLUSH,
  Z_FINISH,
  Z_OK,
  Z_STREAM_END,
  Z_NEED_DICT,
  Z_STREAM_ERROR,
  Z_DATA_ERROR,
  Z_MEM_ERROR
} = constants$2;
function Inflate$1(options) {
  this.options = common.assign({
    chunkSize: 1024 * 64,
    windowBits: 15,
    to: ""
  }, options || {});
  const opt = this.options;
  if (opt.raw && opt.windowBits >= 0 && opt.windowBits < 16) {
    opt.windowBits = -opt.windowBits;
    if (opt.windowBits === 0) {
      opt.windowBits = -15;
    }
  }
  if (opt.windowBits >= 0 && opt.windowBits < 16 && !(options && options.windowBits)) {
    opt.windowBits += 32;
  }
  if (opt.windowBits > 15 && opt.windowBits < 48) {
    if ((opt.windowBits & 15) === 0) {
      opt.windowBits |= 15;
    }
  }
  this.err = 0;
  this.msg = "";
  this.ended = false;
  this.chunks = [];
  this.strm = new zstream();
  this.strm.avail_out = 0;
  let status = inflate_1$2.inflateInit2(
    this.strm,
    opt.windowBits
  );
  if (status !== Z_OK) {
    throw new Error(messages[status]);
  }
  this.header = new gzheader();
  inflate_1$2.inflateGetHeader(this.strm, this.header);
  if (opt.dictionary) {
    if (typeof opt.dictionary === "string") {
      opt.dictionary = strings.string2buf(opt.dictionary);
    } else if (toString.call(opt.dictionary) === "[object ArrayBuffer]") {
      opt.dictionary = new Uint8Array(opt.dictionary);
    }
    if (opt.raw) {
      status = inflate_1$2.inflateSetDictionary(this.strm, opt.dictionary);
      if (status !== Z_OK) {
        throw new Error(messages[status]);
      }
    }
  }
}
Inflate$1.prototype.push = function(data, flush_mode) {
  const strm = this.strm;
  const chunkSize = this.options.chunkSize;
  const dictionary = this.options.dictionary;
  let status, _flush_mode, last_avail_out;
  if (this.ended) return false;
  if (flush_mode === ~~flush_mode) _flush_mode = flush_mode;
  else _flush_mode = flush_mode === true ? Z_FINISH : Z_NO_FLUSH;
  if (toString.call(data) === "[object ArrayBuffer]") {
    strm.input = new Uint8Array(data);
  } else {
    strm.input = data;
  }
  strm.next_in = 0;
  strm.avail_in = strm.input.length;
  for (; ; ) {
    if (strm.avail_out === 0) {
      strm.output = new Uint8Array(chunkSize);
      strm.next_out = 0;
      strm.avail_out = chunkSize;
    }
    status = inflate_1$2.inflate(strm, _flush_mode);
    if (status === Z_NEED_DICT && dictionary) {
      status = inflate_1$2.inflateSetDictionary(strm, dictionary);
      if (status === Z_OK) {
        status = inflate_1$2.inflate(strm, _flush_mode);
      } else if (status === Z_DATA_ERROR) {
        status = Z_NEED_DICT;
      }
    }
    while (strm.avail_in > 0 && status === Z_STREAM_END && strm.state.wrap > 0 && data[strm.next_in] !== 0) {
      inflate_1$2.inflateReset(strm);
      status = inflate_1$2.inflate(strm, _flush_mode);
    }
    switch (status) {
      case Z_STREAM_ERROR:
      case Z_DATA_ERROR:
      case Z_NEED_DICT:
      case Z_MEM_ERROR:
        this.onEnd(status);
        this.ended = true;
        return false;
    }
    last_avail_out = strm.avail_out;
    if (strm.next_out) {
      if (strm.avail_out === 0 || status === Z_STREAM_END) {
        if (this.options.to === "string") {
          let next_out_utf8 = strings.utf8border(strm.output, strm.next_out);
          let tail = strm.next_out - next_out_utf8;
          let utf8str = strings.buf2string(strm.output, next_out_utf8);
          strm.next_out = tail;
          strm.avail_out = chunkSize - tail;
          if (tail) strm.output.set(strm.output.subarray(next_out_utf8, next_out_utf8 + tail), 0);
          this.onData(utf8str);
        } else {
          this.onData(strm.output.length === strm.next_out ? strm.output : strm.output.subarray(0, strm.next_out));
        }
      }
    }
    if (status === Z_OK && last_avail_out === 0) continue;
    if (status === Z_STREAM_END) {
      status = inflate_1$2.inflateEnd(this.strm);
      this.onEnd(status);
      this.ended = true;
      return true;
    }
    if (strm.avail_in === 0) break;
  }
  return true;
};
Inflate$1.prototype.onData = function(chunk) {
  this.chunks.push(chunk);
};
Inflate$1.prototype.onEnd = function(status) {
  if (status === Z_OK) {
    if (this.options.to === "string") {
      this.result = this.chunks.join("");
    } else {
      this.result = common.flattenChunks(this.chunks);
    }
  }
  this.chunks = [];
  this.err = status;
  this.msg = this.strm.msg;
};
function inflate$1(input, options) {
  const inflator = new Inflate$1(options);
  inflator.push(input);
  if (inflator.err) throw inflator.msg || messages[inflator.err];
  return inflator.result;
}
function inflateRaw$1(input, options) {
  options = options || {};
  options.raw = true;
  return inflate$1(input, options);
}
var Inflate_1$1 = Inflate$1;
var inflate_2 = inflate$1;
var inflateRaw_1$1 = inflateRaw$1;
var ungzip$1 = inflate$1;
var constants = constants$2;
var inflate_1$1 = {
  Inflate: Inflate_1$1,
  inflate: inflate_2,
  inflateRaw: inflateRaw_1$1,
  ungzip: ungzip$1,
  constants
};
var { Deflate, deflate, deflateRaw, gzip } = deflate_1$1;
var { Inflate, inflate, inflateRaw, ungzip } = inflate_1$1;
var Deflate_1 = Deflate;
var deflate_1 = deflate;
var deflateRaw_1 = deflateRaw;
var gzip_1 = gzip;
var Inflate_1 = Inflate;
var inflate_1 = inflate;
var inflateRaw_1 = inflateRaw;
var ungzip_1 = ungzip;
var constants_1 = constants$2;
var pako = {
  Deflate: Deflate_1,
  deflate: deflate_1,
  deflateRaw: deflateRaw_1,
  gzip: gzip_1,
  Inflate: Inflate_1,
  inflate: inflate_1,
  inflateRaw: inflateRaw_1,
  ungzip: ungzip_1,
  constants: constants_1
};

// src/parsers/saml.ts
var import_fast_xml_parser = __toESM(require_fxp());
var xmlParser = new import_fast_xml_parser.XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  removeNSPrefix: true,
  parseTagValue: false
});
var decodeBase64 = (raw) => {
  const normalized = raw.replace(/-/g, "+").replace(/_/g, "/").replace(/\s/g, "");
  const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
  return atob(padded);
};
var decodeRedirectPayload = (raw) => {
  const binary = decodeBase64(raw);
  const uint8 = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  return pako.inflateRaw(uint8, { to: "string" });
};
var getNodeText = (node) => {
  if (node === void 0 || node === null) return void 0;
  if (typeof node === "string") return node;
  if (Array.isArray(node)) return getNodeText(node[0]);
  if (typeof node !== "object") return void 0;
  const obj = node;
  if (typeof obj["#text"] === "string") return obj["#text"];
  if (typeof obj["#"] === "string") return obj["#"];
  const textValue = Object.values(obj).find((v) => typeof v === "string" && !v.startsWith("@_"));
  return typeof textValue === "string" ? textValue : void 0;
};
var getElementAttribute = (node, attr) => {
  if (!node || typeof node !== "object") return void 0;
  if (Array.isArray(node)) return getElementAttribute(node[0], attr);
  const obj = node;
  const prefixedKey = `@_${attr}`;
  if (typeof obj[prefixedKey] === "string") return obj[prefixedKey];
  return void 0;
};
var findElement = (node, elementName) => {
  if (!node || typeof node !== "object") return void 0;
  if (Array.isArray(node)) {
    for (const child of node) {
      const found = findElement(child, elementName);
      if (found) return found;
    }
    return void 0;
  }
  const obj = node;
  if (elementName in obj) return obj[elementName];
  for (const value of Object.values(obj)) {
    const found = findElement(value, elementName);
    if (found) return found;
  }
  return void 0;
};
var findValue = (node, key) => {
  if (!node || typeof node !== "object") return void 0;
  if (Array.isArray(node)) {
    for (const child of node) {
      const value = findValue(child, key);
      if (value) return value;
    }
    return void 0;
  }
  const obj = node;
  const direct = obj[key];
  if (typeof direct === "string") return direct;
  for (const value of Object.values(obj)) {
    const found = findValue(value, key);
    if (found) return found;
  }
  return void 0;
};
var hasNode = (node, key) => {
  if (!node || typeof node !== "object") return false;
  if (Array.isArray(node)) return node.some((entry) => hasNode(entry, key));
  const obj = node;
  if (key in obj) return true;
  return Object.values(obj).some((entry) => hasNode(entry, key));
};
var extractNameId = (parsed) => {
  const subject = findElement(parsed, "Subject");
  if (!subject) return {};
  const nameIdElement = findElement(subject, "NameID");
  if (!nameIdElement) return {};
  const nameId = getNodeText(nameIdElement);
  const nameIdFormat = getElementAttribute(nameIdElement, "Format");
  return { nameId, nameIdFormat };
};
var decodeSamlArtifact = (encoded, binding) => {
  const artifact = { encoded };
  try {
    const xml = binding === "redirect" ? decodeRedirectPayload(encoded) : decodeBase64(encoded);
    artifact.decodedXml = xml;
    const parsed = xmlParser.parse(xml);
    artifact.issuer = findValue(parsed, "Issuer");
    artifact.destination = findValue(parsed, "@_Destination");
    artifact.audience = findValue(parsed, "Audience");
    artifact.recipient = findValue(parsed, "@_Recipient");
    artifact.inResponseTo = findValue(parsed, "@_InResponseTo");
    const nameIdData = extractNameId(parsed);
    artifact.nameId = nameIdData.nameId;
    artifact.nameIdFormat = nameIdData.nameIdFormat;
    artifact.notBefore = findValue(parsed, "@_NotBefore");
    artifact.notOnOrAfter = findValue(parsed, "@_NotOnOrAfter");
    artifact.assertionSigned = hasNode(parsed, "Signature") && hasNode(parsed, "Assertion");
    artifact.documentSigned = hasNode(parsed, "Signature") && hasNode(parsed, "Response");
    artifact.encryptedAssertion = hasNode(parsed, "EncryptedAssertion");
    artifact.forceAuthn = findValue(parsed, "@_ForceAuthn") === "true";
    artifact.allowCreate = findValue(parsed, "@_AllowCreate") === "true";
  } catch (error) {
    artifact.parseError = error instanceof Error ? error.message : "Failed to parse SAML artifact";
  }
  return artifact;
};

// src/normalizers/index.ts
var parseBodyParams = (body) => {
  if (!body) return {};
  return parseQueryString(body);
};
var buildSaml = (raw) => {
  const fromQuery = raw.queryParams ?? {};
  const fromBody = parseBodyParams(raw.postBody);
  const samlRequest = fromQuery.SAMLRequest ?? fromBody.SAMLRequest;
  const samlResponse = fromQuery.SAMLResponse ?? fromBody.SAMLResponse;
  const relayState = fromQuery.RelayState ?? fromBody.RelayState;
  if (!samlRequest && !samlResponse) return void 0;
  const binding = raw.method === "POST" || raw.source === "content-form" ? "post" : "redirect";
  return {
    id: raw.id,
    tabId: raw.tabId,
    timestamp: raw.timestamp,
    protocol: "SAML",
    kind: samlResponse ? "saml-response" : "saml-request",
    url: raw.url,
    host: raw.host ?? safeUrl(raw.url)?.host ?? "",
    method: raw.method,
    statusCode: raw.statusCode,
    rawRef: raw.id,
    artifacts: {
      relayState,
      binding,
      requestHeaders: raw.requestHeaders,
      responseHeaders: raw.responseHeaders
    },
    binding,
    relayState,
    samlRequest: samlRequest ? decodeSamlArtifact(samlRequest, binding) : void 0,
    samlResponse: samlResponse ? decodeSamlArtifact(samlResponse, binding) : void 0
  };
};
var classifyOidcKind = (url) => {
  if (url.includes("/.well-known/openid-configuration")) return "discovery";
  if (url.includes("/protocol/openid-connect/auth")) return "authorize";
  if (url.includes("/protocol/openid-connect/token")) return "token";
  if (url.includes("/protocol/openid-connect/userinfo")) return "userinfo";
  if (url.includes("/protocol/openid-connect/logout")) return "logout";
  if (url.includes("/protocol/openid-connect/certs")) return "jwks";
  const params = parseFragmentOrQuery(url);
  if (params.code || params.error || params.id_token || params.access_token) return "callback";
  return "unknown";
};
var inferFlowType = (responseType) => {
  if (!responseType) return "unknown";
  const parts = responseType.split(" ").map((p) => p.trim().toLowerCase());
  const hasCode = parts.includes("code");
  const hasIdToken = parts.includes("id_token");
  const hasToken = parts.includes("token");
  if (hasCode && (hasIdToken || hasToken)) return "hybrid";
  if (hasCode) return "auth-code";
  if (hasIdToken || hasToken) return "implicit";
  return "unknown";
};
var buildOidc = (raw) => {
  const oidcHint = raw.url.includes("openid") || raw.url.includes("/protocol/openid-connect/") || Object.keys(raw.queryParams ?? {}).some((k) => ["client_id", "redirect_uri", "response_type"].includes(k));
  if (!oidcHint) return void 0;
  const url = safeUrl(raw.url);
  const query = raw.queryParams ?? (url ? parseQueryString(url.search.slice(1)) : {});
  const body = parseBodyParams(raw.postBody);
  const callbackParams = parseFragmentOrQuery(raw.url);
  const kind = classifyOidcKind(raw.url);
  const event = {
    id: raw.id,
    tabId: raw.tabId,
    timestamp: raw.timestamp,
    protocol: "OIDC",
    kind,
    url: raw.url,
    host: raw.host ?? url?.host ?? "",
    method: raw.method,
    statusCode: raw.statusCode,
    rawRef: raw.id,
    artifacts: {
      query,
      body,
      callbackParams,
      requestHeaders: raw.requestHeaders,
      responseHeaders: raw.responseHeaders
    },
    clientId: query.client_id ?? body.client_id,
    redirectUri: query.redirect_uri ?? body.redirect_uri,
    responseType: query.response_type,
    responseMode: query.response_mode,
    scope: query.scope,
    state: query.state ?? callbackParams.state ?? body.state,
    nonce: query.nonce ?? callbackParams.nonce,
    code: callbackParams.code ?? body.code,
    error: callbackParams.error,
    errorDescription: callbackParams.error_description,
    codeChallenge: query.code_challenge,
    codeChallengeMethod: query.code_challenge_method,
    codeVerifier: body.code_verifier,
    sessionState: callbackParams.session_state,
    prompt: query.prompt,
    maxAge: query.max_age,
    acrValues: query.acr_values,
    uiLocales: query.ui_locales,
    claimsLocales: query.claims_locales,
    idTokenHint: query.id_token_hint,
    postLogoutRedirectUri: query.post_logout_redirect_uri,
    flowType: query.response_type ? inferFlowType(query.response_type) : void 0
  };
  if (kind === "discovery" && raw.responseBody) {
    try {
      const discovery = JSON.parse(raw.responseBody);
      event.issuer = typeof discovery.issuer === "string" ? discovery.issuer : void 0;
      event.artifacts.discovery = discovery;
    } catch {
      event.artifacts.discoveryError = "Discovery response is not valid JSON";
    }
  }
  if (kind === "token") {
    attachTokenArtifacts(event, raw.responseBody);
  }
  return event;
};
var normalizeRawEvent = (raw) => {
  const saml = buildSaml(raw);
  if (saml) return saml;
  const oidc = buildOidc(raw);
  if (oidc) return oidc;
  return {
    id: raw.id,
    tabId: raw.tabId,
    timestamp: raw.timestamp,
    protocol: raw.source === "webrequest-error" ? "network" : "unknown",
    kind: raw.source,
    url: raw.url,
    host: raw.host ?? safeUrl(raw.url)?.host ?? "",
    method: raw.method,
    statusCode: raw.statusCode,
    rawRef: raw.id,
    artifacts: {
      errorText: raw.errorText,
      redirectUrl: raw.redirectUrl
    }
  };
};

// src/mappings/fieldMappings.ts
var map = {
  OIDC_REDIRECT_URI_MISMATCH: {
    kzeroFields: ["Redirect URL", "Client ID"],
    vendorFields: ["Redirect URI / Callback URL", "Client ID"]
  },
  OIDC_DISCOVERY_ISSUER_MISMATCH: {
    kzeroFields: ["Use discovery endpoint", "Discovery Endpoint", "Issuer"],
    vendorFields: ["Issuer URL"]
  },
  OIDC_INVALID_CLIENT: {
    kzeroFields: ["Client ID", "Client Secret", "Client authentication"],
    vendorFields: ["Client ID", "Client Secret", "Token Auth Method"]
  },
  OIDC_INVALID_SCOPE: {
    kzeroFields: ["Client ID"],
    vendorFields: ["Scope", "OIDC Application Permissions"]
  },
  OIDC_PKCE_INCONSISTENT: {
    kzeroFields: ["Use PKCE", "Client authentication"],
    vendorFields: ["PKCE Required", "Code Challenge Method"]
  },
  OIDC_TOKEN_AUTH_METHOD_MISMATCH_CLUE: {
    kzeroFields: ["Client authentication", "Client ID", "Client Secret"],
    vendorFields: ["Token endpoint auth method", "Client credentials"]
  },
  OIDC_LOGOUT_REDIRECT_MISMATCH_CLUE: {
    kzeroFields: ["Logout URL", "Redirect URL"],
    vendorFields: ["Post logout redirect URI"]
  },
  SAML_AUDIENCE_MISMATCH: {
    kzeroFields: ["Service provider Entity ID", "Identity provider entity ID"],
    vendorFields: ["SP Entity ID", "Audience URI"]
  },
  SAML_ACS_RECIPIENT_MISMATCH: {
    kzeroFields: ["Assertion Consumer Service URL", "Single Sign-On service url"],
    vendorFields: ["ACS URL"]
  },
  SAML_DESTINATION_MISMATCH: {
    kzeroFields: ["Single Sign-On service url"],
    vendorFields: ["Destination URL"]
  },
  SAML_ISSUER_MISMATCH: {
    kzeroFields: ["Identity provider entity ID"],
    vendorFields: ["Expected IdP Issuer", "Entity ID"]
  },
  SAML_MISSING_NAMEID: {
    kzeroFields: ["Principal type", "Pass subject", "NameID Policy Format"],
    vendorFields: ["NameID format", "Subject mapping"]
  },
  SAML_CLOCK_SKEW: {
    kzeroFields: ["Allow clock skew"],
    vendorFields: ["Allowed Clock Skew", "System Time"]
  },
  SAML_NAMEID_FORMAT_MISMATCH: {
    kzeroFields: ["NameID Policy Format", "Principal type", "Pass subject"],
    vendorFields: ["NameID format", "User identifier mapping"]
  },
  SAML_CERT_SIGNATURE_VALIDATION_CLUE: {
    kzeroFields: ["Tenant certificate", "Tenant XML data", "Validate signatures"],
    vendorFields: ["Signature certificate", "Certificate fingerprint"]
  },
  TENANT_CASE_MISMATCH: {
    kzeroFields: ["Alias", "Discovery Endpoint", "Identity provider entity ID"],
    vendorFields: ["Issuer", "Metadata URL"]
  }
};
var getFieldMapping = (ruleId) => map[ruleId] ?? { kzeroFields: ["Alias", "Display name"], vendorFields: ["App config values"] };

// src/rules/helpers.ts
var deriveConfidenceLevel = (confidence) => {
  if (confidence >= 0.8) return "high";
  if (confidence >= 0.55) return "medium";
  return "low";
};
var makeFinding = (input) => {
  const fields = getFieldMapping(input.ruleId);
  if (input.isAmbiguous && !input.ambiguityNote && !input.traceGaps?.length) {
    console.warn(`Finding ${input.ruleId} is ambiguous but has no ambiguityNote or traceGaps`);
  }
  const confidenceLevel = deriveConfidenceLevel(input.confidence);
  return {
    id: nowId(),
    ruleId: input.ruleId,
    severity: input.severity,
    protocol: input.protocol,
    likelyOwner: input.likelyOwner,
    title: input.title,
    explanation: input.explanation,
    observed: input.observed,
    expected: input.expected,
    evidence: input.evidence,
    likelyFix: {
      kzeroFields: fields.kzeroFields,
      vendorFields: fields.vendorFields,
      action: input.action
    },
    confidence: input.confidence,
    confidenceLevel,
    isAmbiguous: input.isAmbiguous,
    ambiguityNote: input.ambiguityNote,
    traceGaps: input.traceGaps,
    disqualifyingEvidence: input.disqualifyingEvidence
  };
};

// src/rules/crossRules.ts
var extractTenants = (events) => {
  const tenants = [];
  for (const event of events) {
    const match = event.url.match(/\/realms\/([^/]+)/i);
    if (match) tenants.push(match[1]);
  }
  return tenants;
};
var runCrossRules = (events) => {
  const findings = [];
  const tenants = extractTenants(events);
  if (tenants.length > 1) {
    const uniqueTenants = new Set(tenants);
    const lowerUnique = new Set(tenants.map((r) => r.toLowerCase()));
    if (uniqueTenants.size > 1 && lowerUnique.size < uniqueTenants.size) {
      findings.push(
        makeFinding({
          ruleId: "TENANT_CASE_MISMATCH",
          severity: "error",
          protocol: "unknown",
          likelyOwner: "KZero",
          title: "Tenant name casing mismatch",
          explanation: "Tenant names are case-sensitive; mixed casing was observed in the same trace.",
          observed: [...new Set(tenants)].join(", "),
          expected: "Single tenant name with exact consistent casing",
          evidence: [...new Set(tenants)],
          action: "Normalize tenant casing across Discovery Endpoint, Issuer, and SAML/OIDC endpoints.",
          confidence: 0.94
        })
      );
    }
  }
  const nonKzeroHosts = events.filter(
    (e) => e.protocol !== "unknown" && e.host && !e.host.endsWith("auth.kzero.com") && !e.host.includes("localhost")
  );
  if (nonKzeroHosts.length > 0) {
    findings.push(
      makeFinding({
        ruleId: "WRONG_HOST_OR_ENVIRONMENT",
        severity: "warning",
        protocol: "unknown",
        likelyOwner: "unknown",
        title: "Potential wrong host or environment mix",
        explanation: "Trace includes auth endpoints outside expected KZero host family.",
        observed: nonKzeroHosts.map((e) => e.host).join(", "),
        expected: "Consistent endpoint family per environment",
        evidence: nonKzeroHosts.slice(0, 3).map((e) => e.url),
        action: "Check for copied values from another environment and confirm tenant endpoint family.",
        confidence: 0.74
      })
    );
  }
  const legacyFamily = events.find((e) => e.url.includes("/auth/realms/"));
  if (legacyFamily) {
    findings.push(
      makeFinding({
        ruleId: "WRONG_REALM_ENDPOINT_FAMILY",
        severity: "warning",
        protocol: "unknown",
        likelyOwner: "KZero",
        title: "Unexpected endpoint path family",
        explanation: "Legacy /auth/realms path detected; this often indicates stale docs or copied config.",
        observed: legacyFamily.url,
        expected: "https://<host>/realms/<tenant>/...",
        evidence: [legacyFamily.url],
        action: "Replace legacy endpoint values with current KZero URL patterns.",
        confidence: 0.88,
        disqualifyingEvidence: ["All endpoints use current /realms/ path pattern"]
      })
    );
  }
  const parseFailures = events.filter(
    (e) => String(e.artifacts.errorText ?? "").length > 0 || String(e.artifacts.discoveryError ?? "").length > 0
  );
  if (parseFailures.length > 0) {
    findings.push(
      makeFinding({
        ruleId: "METADATA_COPY_PASTE_TRUNCATION",
        severity: "info",
        protocol: "unknown",
        likelyOwner: "user data",
        title: "Potential copy/paste truncation",
        explanation: "Malformed metadata or payload parse errors can indicate copied values were truncated.",
        observed: parseFailures.map((e) => e.url).join(", "),
        expected: "Full metadata/payload values",
        evidence: parseFailures.slice(0, 3).map((e) => e.id),
        action: "Re-copy metadata URLs/XML from source and avoid manual edits in the middle of long values.",
        confidence: 0.61,
        isAmbiguous: true,
        ambiguityNote: "Parse errors could be from truncation, encoding issues, or actual malformed data. Look at the raw artifact to determine.",
        traceGaps: ["Full untruncated artifact content"],
        disqualifyingEvidence: ["Successful parse of same metadata/payload"]
      })
    );
  }
  const samlPostedButRejected = events.find(
    (e) => e.protocol === "SAML" && e.kind === "saml-response" && (e.statusCode ?? 0) >= 400
  );
  if (samlPostedButRejected) {
    findings.push(
      makeFinding({
        ruleId: "VENDOR_VALIDATION_REJECTING_METADATA_CLUE",
        severity: "warning",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "Vendor validation likely rejecting metadata",
        explanation: "SAML response reached SP endpoint but was rejected by validation checks.",
        observed: `ACS status ${(samlPostedButRejected.statusCode ?? 0).toString()}`,
        expected: "SP accepts metadata/assertion values",
        evidence: [samlPostedButRejected.url],
        action: "Review vendor strict validation requirements and compare against KZero metadata fields.",
        confidence: 0.65,
        isAmbiguous: true,
        ambiguityNote: "Error status could be due to signature/cert issues, audience/issuer mismatch, or other validation failures. Check the specific error response body if available.",
        traceGaps: ["SAML response error body content"],
        disqualifyingEvidence: ["ACS returns 200 with successful login"]
      })
    );
  }
  const callbackErrorNoToken = events.some((e) => e.protocol === "OIDC" && e.kind === "callback" && String(e.error ?? "").length > 0) && !events.some((e) => e.protocol === "OIDC" && e.kind === "token");
  if (callbackErrorNoToken) {
    findings.push(
      makeFinding({
        ruleId: "CLIENT_SIDE_VS_BACKEND_VALIDATION_DISTINCTION",
        severity: "info",
        protocol: "OIDC",
        likelyOwner: "browser",
        title: "Likely client-side validation before backend token exchange",
        explanation: "Callback error appears in browser and no token request was attempted.",
        observed: "callback includes error and token request missing",
        expected: "backend token exchange attempted when callback has authorization code",
        evidence: ["OIDC callback event present", "OIDC token event missing"],
        action: "Check browser/client redirect handler logic before backend token exchange path.",
        confidence: 0.62,
        isAmbiguous: true,
        ambiguityNote: "Could be client-side validation failing, or backend returning error before token exchange. Look for token request in trace.",
        traceGaps: ["OIDC token request event"],
        disqualifyingEvidence: ["Token request made and succeeds", "Callback has no error"]
      })
    );
  }
  const networkErrors = events.filter((e) => e.protocol === "network");
  if (networkErrors.length > 0) {
    findings.push(
      makeFinding({
        ruleId: "NETWORK_TLS_REACHABILITY_SUSPECTED",
        severity: "warning",
        protocol: "network",
        likelyOwner: "network",
        title: "Network/TLS/public accessibility suspicion",
        explanation: "Request-level network errors were captured during auth flow.",
        observed: networkErrors.map((e) => String(e.artifacts.errorText ?? "network error")).join(", "),
        expected: "No network-level failures on auth endpoints",
        evidence: networkErrors.slice(0, 3).map((e) => e.url),
        action: "Verify firewall, WAF, DNS, and TLS chain from browser and vendor backend paths.",
        confidence: 0.86
      })
    );
  }
  const mixedRealmHosts = new Set(events.map((e) => e.host)).size > 3;
  if (mixedRealmHosts) {
    findings.push(
      makeFinding({
        ruleId: "STALE_VALUES_FROM_ANOTHER_ENVIRONMENT",
        severity: "info",
        protocol: "unknown",
        likelyOwner: "user data",
        title: "Suspected stale copied values from another environment",
        explanation: "Auth flow touches many unrelated hosts, which often indicates copied endpoint values.",
        observed: `${new Set(events.map((e) => e.host)).size} hosts in one auth trace`,
        expected: "Small, consistent host set for one tenant integration",
        evidence: events.slice(0, 5).map((e) => e.url),
        action: "Re-validate all endpoint URLs against the current environment and tenant.",
        confidence: 0.57
      })
    );
  }
  return findings;
};

// src/recipes/context.ts
var computeOidcCorrelation = (oidc) => {
  const hasAuthorize = Boolean(oidc.authorize);
  const hasCallback = Boolean(oidc.callback);
  const hasDiscovery = Boolean(oidc.discovery);
  const hasToken = Boolean(oidc.token);
  const hasLogout = Boolean(oidc.logout);
  const stateRoundTrip = hasAuthorize && hasCallback && Boolean(oidc.authorize?.state) && Boolean(oidc.callback?.state) && oidc.authorize.state === oidc.callback.state;
  const pkcePresent = Boolean(hasAuthorize && oidc.authorize?.codeChallenge);
  const pkceMethod = oidc.authorize?.codeChallengeMethod;
  const pkceVerified = pkcePresent && Boolean(oidc.token?.codeVerifier);
  let redirectUriMatch;
  if (oidc.authorize?.redirectUri && hasCallback) {
    try {
      const callbackUrl = new URL(oidc.callback.url);
      const redirectUrl = new URL(oidc.authorize.redirectUri);
      redirectUriMatch = callbackUrl.origin === redirectUrl.origin && callbackUrl.pathname === redirectUrl.pathname;
    } catch {
      redirectUriMatch = false;
    }
  }
  let issuerMatch;
  const discoveryIssuer = oidc.discovery?.issuer;
  const tokenIssuer = hasToken && oidc.token?.idToken?.payload?.iss ? String(oidc.token.idToken.payload.iss) : void 0;
  if (discoveryIssuer && tokenIssuer) {
    issuerMatch = discoveryIssuer === tokenIssuer;
  }
  const flowType = oidc.authorize?.flowType ?? "unknown";
  const tokenVisible = hasToken && Boolean(oidc.token?.artifacts.responseBody);
  const lateCapture = !hasAuthorize && hasCallback;
  const flowCorrelated = hasAuthorize && hasCallback || lateCapture;
  const callbackError = hasCallback ? oidc.callback?.error : void 0;
  const errorClue = callbackError ?? (hasToken ? oidc.token?.error : void 0) ?? (hasLogout ? oidc.logout?.error : void 0);
  const discoveryVisible = hasDiscovery;
  const landingUrl = hasCallback ? oidc.callback?.artifacts.landingUrl : void 0;
  return {
    stateRoundTrip,
    pkcePresent,
    pkceMethod,
    pkceVerified,
    redirectUriMatch,
    issuerMatch,
    discoveryVisible,
    flowCorrelated,
    flowType,
    tokenVisible,
    lateCapture,
    callbackError,
    landingUrl,
    errorClue
  };
};

// src/shared/landing.ts
var KNOWN_STATIC_HOSTS = [
  "zohocdn.com",
  "static.zohocdn.com",
  "google-analytics.com",
  "googletagmanager.com",
  "segment.io",
  "segment.com",
  "hotjar.com",
  "intercom.io",
  "zendesk.com"
];
var isKnownStaticHost = (host) => {
  const h = host.toLowerCase();
  return KNOWN_STATIC_HOSTS.some((s) => h === s || h.endsWith("." + s));
};
var isAppLanding = (event, targetHosts) => {
  try {
    const url = new URL(event.url);
    const pathname = url.pathname;
    if (/\.(css|js|png|svg|woff|ico|jpg|jpeg|gif|webp|json)(\?|$)/i.test(pathname)) return false;
    if (pathname.includes("/ws/") || pathname.includes("/chat/") || pathname.includes("/status")) return false;
    if (url.hostname.includes("statuspage") || url.hostname.includes("wss.")) return false;
    if (isKnownStaticHost(url.hostname)) return false;
    if (pathname === "/" || pathname === "" || pathname === "/home" || pathname === "/app" || pathname === "/dashboard") return true;
    if (pathname.endsWith(".html") || pathname.endsWith(".htm")) return true;
    return false;
  } catch {
    return false;
  }
};
var isOidcCallback = (event) => {
  return event.protocol === "OIDC" && event.kind === "callback";
};
var isOidcToken = (event) => {
  return event.protocol === "OIDC" && event.kind === "token";
};
var isSamlResponse = (event) => {
  return event.protocol === "SAML" && event.kind === "saml-response";
};
var isOidcAuthEvent = (event) => {
  if (event.protocol !== "OIDC") return false;
  const kind = event.kind;
  return kind === "discovery" || kind === "authorize" || kind === "callback" || kind === "token" || kind === "userinfo" || kind === "jwks" || kind === "logout";
};
var isSamlAuthEvent = (event) => {
  return event.protocol === "SAML";
};
var detectLanding = (events) => {
  if (!events.length) {
    return { detected: false };
  }
  const authEvents = events.filter((e) => isOidcAuthEvent(e) || isSamlAuthEvent(e));
  let boundaryEvent;
  let landingEvent;
  const knownIdpHosts = /* @__PURE__ */ new Set();
  const knownSpHosts = /* @__PURE__ */ new Set();
  for (const event of authEvents) {
    if (isSamlResponse(event)) {
      boundaryEvent = event;
      if (event.samlResponse?.issuer) {
        try {
          const issuerUrl = new URL(event.samlResponse.issuer);
          knownIdpHosts.add(issuerUrl.host);
        } catch {
        }
      }
    }
    if (isOidcCallback(event) && event.code && !boundaryEvent) {
      boundaryEvent = event;
      if (event.redirectUri) {
        try {
          const redirectUrl = new URL(event.redirectUri);
          knownSpHosts.add(redirectUrl.host);
        } catch {
        }
      }
    }
    if (isOidcToken(event) && boundaryEvent) {
      const artifacts = event.artifacts;
      const hasAccessToken = Boolean(artifacts.accessToken || artifacts.idToken);
      if (hasAccessToken) {
        boundaryEvent = event;
      }
    }
  }
  if (!boundaryEvent) {
    return { detected: false };
  }
  const boundaryIndex = events.indexOf(boundaryEvent);
  const remainingEvents = events.slice(boundaryIndex + 1);
  for (const event of remainingEvents) {
    const targetHosts = knownSpHosts.size > 0 ? knownSpHosts : knownIdpHosts;
    if (isAppLanding(event, targetHosts)) {
      landingEvent = event;
      break;
    }
  }
  return {
    detected: Boolean(landingEvent),
    landingEvent,
    boundaryEvent
  };
};

// src/rules/oidcRules.ts
var isOidc = (e) => e.protocol === "OIDC";
var hasStrongDownstreamActivity = (events) => {
  return events.some((e) => e.kind === "token" || e.kind === "userinfo" || e.kind === "logout");
};
var runOidcRules = (events) => {
  const findings = [];
  const oidc = events.filter(isOidc);
  const discovery = oidc.find((e) => e.kind === "discovery");
  const authorize = oidc.find((e) => e.kind === "authorize");
  const callback = oidc.find((e) => e.kind === "callback");
  const token = oidc.find((e) => e.kind === "token");
  const jwks = oidc.find((e) => e.kind === "jwks");
  const userinfo = oidc.find((e) => e.kind === "userinfo");
  const logoutEvent = oidc.find((e) => e.kind === "logout");
  const correlation = computeOidcCorrelation({
    discovery,
    authorize,
    callback,
    token,
    jwks,
    logout: logoutEvent
  });
  const landing = detectLanding(events);
  if (discovery && discovery.statusCode && discovery.statusCode >= 400) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_DISCOVERY_UNREACHABLE",
        severity: "error",
        protocol: "OIDC",
        likelyOwner: "network",
        title: "Discovery URL unreachable",
        explanation: "The OIDC discovery endpoint returned an error status.",
        observed: `Discovery status ${discovery.statusCode}`,
        expected: "HTTP 200 with valid OpenID metadata",
        evidence: [discovery.url],
        action: "Verify Discovery Endpoint, DNS/TLS reachability, and WAF rules.",
        confidence: 0.9,
        disqualifyingEvidence: ["Discovery endpoint returns HTTP 200"]
      })
    );
  }
  if (discovery?.issuer) {
    const expected = discovery.url.split("/.well-known/openid-configuration")[0];
    if (discovery.issuer !== expected) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_DISCOVERY_ISSUER_MISMATCH",
          severity: "error",
          protocol: "OIDC",
          likelyOwner: "KZero",
          title: "Discovery issuer mismatch",
          explanation: "The issuer in discovery does not match the tenant endpoint used for discovery.",
          observed: discovery.issuer,
          expected,
          evidence: [discovery.url],
          action: "Compare tenant casing and ensure Discovery Endpoint and Issuer values match exactly.",
          confidence: 0.92,
          disqualifyingEvidence: ["Issuer in discovery matches the tenant endpoint used"]
        })
      );
    }
  }
  if (discovery?.artifacts?.discoveryError) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_DISCOVERY_MALFORMED",
        severity: "error",
        protocol: "OIDC",
        likelyOwner: "user data",
        title: "Discovery document is malformed",
        explanation: "The discovery response could not be parsed as valid JSON.",
        observed: String(discovery.artifacts.discoveryError),
        expected: "Valid JSON in discovery response",
        evidence: [discovery.url],
        action: "Verify the discovery URL returns valid JSON. Check for proxy/gateway that may be returning error HTML instead of JSON, or that the URL is correct for your IdP.",
        confidence: 0.94,
        disqualifyingEvidence: ["Discovery document parses as valid JSON"]
      })
    );
  }
  if (discovery?.artifacts?.discovery) {
    const disc = discovery.artifacts.discovery;
    const issuerHost = typeof disc.issuer === "string" ? disc.issuer : null;
    const authEndpoint = typeof disc.authorization_endpoint === "string" ? disc.authorization_endpoint : null;
    const tokenEndpoint = typeof disc.token_endpoint === "string" ? disc.token_endpoint : null;
    const jwksUri = typeof disc.jwks_uri === "string" ? disc.jwks_uri : null;
    const isPrivateNetworkPattern = (host) => {
      const h = host.toLowerCase();
      if (h === "localhost" || h === "127.0.0.1") return true;
      if (/^10\.\d+\.\d+\.\d+$/.test(h)) return true;
      if (/^192\.168\.\d+\.\d+$/.test(h)) return true;
      if (/^172\.(1[6-9]|2\d|3[01])\.\d+\.\d+$/.test(h)) return true;
      if (h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".corp")) return true;
      if (!h.includes(".")) return true;
      return false;
    };
    const getHostFamily = (urlStr) => {
      try {
        const url = new URL(urlStr);
        const host = url.hostname.toLowerCase();
        if (isPrivateNetworkPattern(host)) return "private";
        const parts = host.split(".");
        if (parts.length >= 2) {
          return parts.slice(-2).join(".");
        }
        return host;
      } catch {
        return null;
      }
    };
    const endpointHosts = [authEndpoint, tokenEndpoint, jwksUri].filter(Boolean);
    const hasPrivateEndpoint = endpointHosts.some((ep) => {
      try {
        return isPrivateNetworkPattern(new URL(ep).hostname);
      } catch {
        return false;
      }
    });
    if (hasPrivateEndpoint) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_DISCOVERY_PUBLIC_REACHABILITY_CLUE",
          severity: "warning",
          protocol: "OIDC",
          likelyOwner: "network",
          title: "Discovery endpoints may not be publicly reachable",
          explanation: "Discovery endpoints contain internal or localhost addresses.",
          observed: "Internal-looking endpoint URLs in discovery",
          expected: "Publicly accessible endpoint URLs",
          evidence: [discovery.url],
          action: "Verify IdP endpoints are publicly accessible. Internal-only endpoints will fail for cloud/SaaS vendors.",
          confidence: 0.58,
          isAmbiguous: true,
          ambiguityNote: "Internal-looking endpoints could be valid for VPN-based setups or private IdP deployments. Verify this matches your deployment model."
        })
      );
    } else if (issuerHost) {
      const issuerFamily = getHostFamily(issuerHost);
      let suspiciousHostFound = false;
      for (const endpoint of endpointHosts) {
        const endpointFamily = getHostFamily(endpoint);
        if (endpointFamily && endpointFamily !== "private" && issuerFamily && endpointFamily !== issuerFamily) {
          suspiciousHostFound = true;
          break;
        }
      }
      if (suspiciousHostFound) {
        findings.push(
          makeFinding({
            ruleId: "OIDC_DISCOVERY_ENDPOINT_HOST_SUSPICIOUS",
            severity: "warning",
            protocol: "OIDC",
            likelyOwner: "user data",
            title: "Discovery endpoint host differs from issuer",
            explanation: "The authorization_endpoint, token_endpoint, or jwks_uri host does not match the issuer host family.",
            observed: "Endpoint hosts differ across incompatible families",
            expected: "Consistent host family across issuer and endpoints",
            evidence: [discovery.url],
            action: "Verify all endpoint URLs use the expected host family. Mismatched hosts may indicate copied values from another environment or cross-environment configuration.",
            confidence: 0.72,
            isAmbiguous: true,
            ambiguityNote: "Endpoint host differences could indicate multi-tenant setup, CDN, reverse proxy, or actual misconfiguration. Check if this is expected for your IdP.",
            disqualifyingEvidence: ["All endpoints use consistent host family matching issuer"]
          })
        );
      }
    }
  }
  if (authorize && (!authorize.scope || !authorize.scope.includes("openid"))) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_MISSING_OPENID_SCOPE",
        severity: "error",
        protocol: "OIDC",
        likelyOwner: "vendor SP",
        title: "Missing required openid scope",
        explanation: "OIDC authorization requests must include the openid scope.",
        observed: authorize.scope ?? "(missing)",
        expected: "scope contains openid",
        evidence: [authorize.url],
        action: "Update vendor scope list to include openid and keep profile/email as needed.",
        confidence: 0.98,
        disqualifyingEvidence: ["Authorization request includes 'openid' scope"]
      })
    );
  }
  if (authorize && callback && authorize.redirectUri) {
    const normalizeRedirect = (url) => {
      try {
        const u = new URL(url);
        return `${u.origin}${u.pathname.replace(/\/$/, "")}`;
      } catch {
        return url;
      }
    };
    const callbackUrl = new URL(callback.url);
    const observed = normalizeRedirect(`${callbackUrl.origin}${callbackUrl.pathname}`);
    const expected = normalizeRedirect(authorize.redirectUri);
    if (observed !== expected) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_REDIRECT_URI_MISMATCH",
          severity: "error",
          protocol: "OIDC",
          likelyOwner: "vendor SP",
          title: "Redirect URI mismatch",
          explanation: "The callback URL reached by the browser does not match the requested redirect_uri.",
          observed,
          expected: authorize.redirectUri,
          evidence: [authorize.url, callback.url],
          action: "Align redirect URI values exactly on both sides (scheme, host, path, trailing slash).",
          confidence: 0.95,
          disqualifyingEvidence: ["Callback URL matches redirect_uri exactly"]
        })
      );
    }
  }
  const errSource = callback?.error ? callback : token?.error ? token : void 0;
  if (errSource?.error) {
    const map2 = {
      invalid_client: "OIDC_INVALID_CLIENT",
      invalid_scope: "OIDC_INVALID_SCOPE",
      unauthorized_client: "OIDC_UNAUTHORIZED_CLIENT",
      unsupported_response_type: "OIDC_UNSUPPORTED_RESPONSE_TYPE",
      unsupported_response_mode: "OIDC_UNSUPPORTED_RESPONSE_MODE"
    };
    const rule = map2[errSource.error] ?? "OIDC_CALLBACK_ERROR";
    findings.push(
      makeFinding({
        ruleId: rule,
        severity: "error",
        protocol: "OIDC",
        likelyOwner: "vendor SP",
        title: `OIDC error: ${errSource.error}`,
        explanation: "The authorization or token flow returned an explicit OIDC error.",
        observed: `${errSource.error}${errSource.errorDescription ? ` (${errSource.errorDescription})` : ""}`,
        expected: "No OAuth/OIDC error parameter",
        evidence: [errSource.url],
        action: "Use the exact error to align client credentials, scopes, and supported response settings.",
        confidence: 0.97
      })
    );
  }
  if (authorize && callback) {
    if (!authorize.state || !callback.state || authorize.state !== callback.state) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_STATE_MISSING_OR_MISMATCH",
          severity: "error",
          protocol: "OIDC",
          likelyOwner: "browser",
          title: "State missing or mismatch",
          explanation: "State protects against CSRF and must match between authorize request and callback.",
          observed: `authorize=${authorize.state ?? "(missing)"}, callback=${callback.state ?? "(missing)"}`,
          expected: "Matching non-empty state values",
          evidence: [authorize.url, callback.url],
          action: "Ensure vendor preserves state through redirects and no browser plugin strips query/fragment values.",
          confidence: 0.91
        })
      );
    }
    if (authorize.responseType?.includes("id_token") && !authorize.nonce) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_NONCE_MISSING",
          severity: "warning",
          protocol: "OIDC",
          likelyOwner: "vendor SP",
          title: "Nonce missing for ID token response",
          explanation: "Nonce should be present when id_token is returned from the authorization endpoint.",
          observed: "nonce missing",
          expected: "nonce present",
          evidence: [authorize.url],
          action: "Enable nonce generation/validation in vendor OIDC client settings.",
          confidence: 0.85
        })
      );
    }
  }
  if (authorize?.codeChallenge && token && !token.codeVerifier) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_PKCE_INCONSISTENT",
        severity: "error",
        protocol: "OIDC",
        likelyOwner: "vendor SP",
        title: "PKCE code_verifier missing",
        explanation: "Authorization used a code_challenge but token exchange did not include code_verifier.",
        observed: "code_verifier missing at token endpoint",
        expected: "code_verifier present",
        evidence: [authorize.url, token.url],
        action: "Verify Use PKCE and vendor token exchange logic are both enabled and consistent.",
        confidence: 0.93
      })
    );
  }
  if (jwks && jwks.statusCode && jwks.statusCode >= 400) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_JWKS_FETCH_FAILURE",
        severity: "error",
        protocol: "OIDC",
        likelyOwner: "network",
        title: "JWKS fetch failure",
        explanation: "Public key retrieval failed, so token signature validation may fail.",
        observed: `JWKS status ${jwks.statusCode}`,
        expected: "HTTP 200 with valid JWKS JSON",
        evidence: [jwks.url],
        action: "Check WAF/TLS/public access for JWKS endpoint and compare discovery jwks_uri.",
        confidence: 0.89
      })
    );
    if ([401, 403, 408, 429, 502, 503, 504].includes(jwks.statusCode)) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_REACHABILITY_WAF_TLS_SUSPECTED",
          severity: "warning",
          protocol: "OIDC",
          likelyOwner: "network",
          title: "Public reachability / WAF / TLS suspicion",
          explanation: "JWKS failure pattern matches common gateway/WAF/reachability blocking.",
          observed: `JWKS status ${jwks.statusCode}`,
          expected: "Publicly reachable JWKS over TLS",
          evidence: [jwks.url],
          action: "Validate DNS, TLS chain, and WAF allow rules for vendor to reach KZero endpoints.",
          confidence: 0.83
        })
      );
    }
  }
  if (token?.idToken?.payload?.iss && discovery?.issuer && token.idToken.payload.iss !== discovery.issuer) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_TOKEN_ISSUER_MISMATCH",
        severity: "error",
        protocol: "OIDC",
        likelyOwner: "KZero",
        title: "Token issuer mismatch",
        explanation: "ID token issuer does not match discovery issuer.",
        observed: String(token.idToken.payload.iss),
        expected: discovery.issuer,
        evidence: [token.url, discovery.url],
        action: "Validate tenant URLs and ensure app is not mixing environments.",
        confidence: 0.96
      })
    );
  }
  if (callback?.code && (!token || (token.statusCode ?? 0) >= 400 || token.error)) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_CALLBACK_TOKEN_EXCHANGE_BROKEN",
        severity: "warning",
        protocol: "OIDC",
        likelyOwner: "vendor SP",
        title: "Callback reached but token exchange appears broken",
        explanation: "Authorization returned a code, but token exchange is missing or failed.",
        observed: token ? `token status ${token.statusCode ?? "unknown"}` : "no token call captured",
        expected: "Successful token endpoint response",
        evidence: [callback.url, token?.url ?? "(missing token request)"],
        action: "Verify Token URL, client auth method, and backend outbound connectivity.",
        confidence: 0.86
      })
    );
  }
  if (token?.tokenEndpointAuthMethod) {
    const body = token.artifacts.body;
    const headers = token.artifacts.requestHeaders;
    const hasAuthHeader = Boolean(headers?.authorization);
    const hasClientSecretInBody = Boolean(body?.client_secret);
    if (token.tokenEndpointAuthMethod === "client_secret_basic" && hasClientSecretInBody || token.tokenEndpointAuthMethod === "client_secret_post" && hasAuthHeader) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_TOKEN_AUTH_METHOD_MISMATCH_CLUE",
          severity: "warning",
          protocol: "OIDC",
          likelyOwner: "vendor SP",
          title: "Token auth method mismatch clue",
          explanation: "Observed token request style does not align with declared auth method clues.",
          observed: `${token.tokenEndpointAuthMethod} with request pattern mismatch`,
          expected: "Token request uses matching client authentication style",
          evidence: [token.url],
          action: "Compare Client authentication setting with vendor token auth method implementation.",
          confidence: 0.7
        })
      );
    }
  }
  if (logoutEvent) {
    const logoutParams = logoutEvent.artifacts.query;
    if ((logoutEvent.statusCode ?? 0) >= 400 || logoutParams?.error) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_LOGOUT_REDIRECT_MISMATCH_CLUE",
          severity: "warning",
          protocol: "OIDC",
          likelyOwner: "vendor SP",
          title: "Logout redirect mismatch clue",
          explanation: "Logout request returned error, often from post logout redirect mismatch.",
          observed: `logout status ${logoutEvent.statusCode ?? "unknown"}`,
          expected: "Valid logout with accepted post logout redirect",
          evidence: [logoutEvent.url],
          action: "Verify Logout URL and registered post logout redirect URI values.",
          confidence: 0.69
        })
      );
    }
  }
  if (token?.accessTokenOpaque) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_ACCESS_TOKEN_OPAQUE",
        severity: "info",
        protocol: "OIDC",
        likelyOwner: "unknown",
        title: "Access token is opaque",
        explanation: "Opaque access tokens are normal for some integrations.",
        observed: "token is not JWT",
        expected: "JWT or opaque depending on vendor design",
        evidence: [token.url],
        action: "Treat as informational unless vendor incorrectly expects JWT access tokens.",
        confidence: 0.8
      })
    );
  }
  if (!authorize && callback) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_LATE_CAPTURE_CLUE",
        severity: "info",
        protocol: "OIDC",
        likelyOwner: "unknown",
        title: "Capture started after authorization request",
        explanation: "Callback was captured but no authorize request is present in this trace.",
        observed: "Callback captured but authorize missing",
        expected: "Full flow with authorize and callback",
        action: "If this should be a complete trace, start capture before clicking login.",
        evidence: callback ? [callback.url] : [],
        confidence: 0.6,
        isAmbiguous: true,
        ambiguityNote: "This is informational - the flow may have succeeded, but capture started after the authorize was sent. This usually means capture started late, the initial authorize happened outside the captured tab/window, or the authorize request was not retained.",
        traceGaps: ["Authorize request not captured"],
        disqualifyingEvidence: ["Authorize request captured", "Full flow observed"]
      })
    );
  }
  if (!authorize && !callback && hasStrongDownstreamActivity(oidc)) {
    const downstreamEvent = token ?? userinfo ?? logoutEvent;
    findings.push(
      makeFinding({
        ruleId: "OIDC_MISSING_AUTHORIZE_REQUEST_CLUE",
        severity: "info",
        protocol: "OIDC",
        likelyOwner: "unknown",
        title: "Authorization request not captured but downstream activity present",
        explanation: "Token, userinfo, or logout activity was captured without the authorize request.",
        observed: "Callback or token activity was captured, but the authorize request was not present in this trace.",
        expected: "Authorize request present in trace",
        action: "This usually means capture started late, the initial authorize happened outside the captured tab/window, or the authorize request was not retained. If SP-initiated flow is expected, start capture before initiating login.",
        evidence: downstreamEvent ? [downstreamEvent.url] : [],
        confidence: 0.58,
        isAmbiguous: true,
        ambiguityNote: "This usually means capture started late, the initial authorize happened outside the captured tab/window, or the authorize request was not retained.",
        traceGaps: ["Authorize request not captured"],
        disqualifyingEvidence: ["Authorize request captured"]
      })
    );
  }
  if (authorize && !callback && !correlation.lateCapture) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_MISSING_CALLBACK",
        severity: "warning",
        protocol: "OIDC",
        likelyOwner: "vendor SP",
        title: "No callback captured after authorization request",
        explanation: "Authorize request was captured but no callback was detected.",
        observed: "Authorize sent but no callback captured",
        expected: "OIDC callback with code or error",
        action: "Verify the app received a callback to the configured redirect URI, including form_post if that response_mode is in use. Check for browser extension/CSP blocking or vendor redirect handler issues.",
        evidence: [authorize.url],
        confidence: 0.68,
        traceGaps: ["OIDC callback not captured"],
        disqualifyingEvidence: ["Callback captured", "Callback error present"]
      })
    );
  }
  if (authorize && authorize.responseType?.includes("code") && !authorize.codeChallenge) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_PKCE_MISSING_WHEN_CODE_FLOW",
        severity: "warning",
        protocol: "OIDC",
        likelyOwner: "vendor SP",
        title: "PKCE not used in Authorization Code flow",
        explanation: "response_type=code was used but no code_challenge was present in the authorize request.",
        observed: "response_type=code but no code_challenge present",
        expected: "PKCE code_challenge for Authorization Code flow",
        action: "Enable PKCE (Use PKCE) in vendor OIDC client - recommended for all Authorization Code flows for security.",
        evidence: [authorize.url],
        confidence: 0.74,
        disqualifyingEvidence: ["code_challenge present in authorize request"]
      })
    );
  }
  if (authorize?.codeChallengeMethod && authorize.codeChallengeMethod !== "S256") {
    findings.push(
      makeFinding({
        ruleId: "OIDC_PKCE_METHOD_WEAK_OR_UNEXPECTED",
        severity: "warning",
        protocol: "OIDC",
        likelyOwner: "vendor SP",
        title: "Weak or unexpected PKCE method",
        explanation: "PKCE code_challenge_method is not the recommended S256.",
        observed: `code_challenge_method=${authorize.codeChallengeMethod}`,
        expected: "code_challenge_method=S256",
        action: "Set code_challenge_method to S256 in vendor OIDC client. Plain method is considered weak and not recommended.",
        evidence: [authorize.url],
        confidence: 0.84,
        disqualifyingEvidence: ["code_challenge_method=S256"]
      })
    );
  }
  if (discovery) {
    const requiredFields = ["issuer", "authorization_endpoint", "token_endpoint"];
    const missingFields = requiredFields.filter((f) => {
      const artifacts = discovery.artifacts;
      return !artifacts[f];
    });
    if (missingFields.length > 0) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_DISCOVERY_ENDPOINT_INCONSISTENT",
          severity: "error",
          protocol: "OIDC",
          likelyOwner: "user data",
          title: "Discovery document missing required fields",
          explanation: "Discovery document is missing required OpenID Connect metadata fields.",
          observed: `Missing fields: ${missingFields.join(", ")}`,
          expected: "All required fields present in discovery document",
          action: "Verify discovery document structure - may indicate stale copied values, wrong discovery URL, or malformed IdP metadata. Check all required fields are present and properly formatted.",
          evidence: [discovery.url],
          confidence: 0.86,
          disqualifyingEvidence: ["Discovery document validates and passes structural checks"]
        })
      );
    }
  }
  if (userinfo && (userinfo.statusCode ?? 0) >= 400) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_USERINFO_FAILED",
        severity: "warning",
        protocol: "OIDC",
        likelyOwner: "vendor SP",
        title: "UserInfo endpoint request failed",
        explanation: "The UserInfo endpoint returned an error status.",
        observed: `userinfo status ${userinfo.statusCode}`,
        expected: "HTTP 200 with user claims",
        action: "Check UserInfo endpoint accessibility, token validity, and vendor UserInfo URL configuration.",
        evidence: [userinfo.url],
        confidence: 0.76,
        disqualifyingEvidence: ["UserInfo returns HTTP 200"]
      })
    );
  }
  if (authorize && !callback) {
    const recentAuthorizes = oidc.filter((e) => e.kind === "authorize");
    if (recentAuthorizes.length > 2) {
      findings.push(
        makeFinding({
          ruleId: "OIDC_BROWSER_STORAGE_OR_COOKIE_BLOCKING_CLUE",
          severity: "warning",
          protocol: "OIDC",
          likelyOwner: "browser",
          title: "Multiple authorize requests without callback - possible cookie/storage blocking",
          explanation: "Multiple authorization requests were captured without any callback, which may indicate the browser is blocking cookies or storage.",
          observed: `${recentAuthorizes.length} authorize requests without callback`,
          expected: "Single authorize \u2192 callback flow",
          action: "Check browser for blocked cookies or storage - common with incognito mode or privacy extensions.",
          evidence: recentAuthorizes.map((e) => e.url),
          confidence: 0.52,
          isAmbiguous: true,
          ambiguityNote: "Pattern suggests cookie/storage blocking, but could also be vendor redirect loop. Verify in browser devtools.",
          traceGaps: ["Callback event captured"],
          disqualifyingEvidence: ["Callback captured after authorize", "Single authorize \u2192 callback flow observed"]
        })
      );
    }
  }
  if (callback?.code && !landing.detected) {
    findings.push(
      makeFinding({
        ruleId: "OIDC_CALLBACK_SEEN_BUT_NO_APP_LANDING_CLUE",
        severity: "warning",
        protocol: "OIDC",
        likelyOwner: "vendor SP",
        title: "Callback succeeded but no app landing detected",
        explanation: "OIDC callback with authorization code was captured, but no app landing was detected within the capture window.",
        observed: "Callback succeeded but no app landing detected within capture window",
        expected: "App landing after successful callback",
        action: "Check if vendor callback handler properly redirects to app landing page. Verify redirect URI points to correct app URL.",
        evidence: [callback.url],
        confidence: 0.64,
        isAmbiguous: true,
        ambiguityNote: "Landing may have happened but was filtered as noise, occurred outside capture window, or SPA routing finished without full navigation event. This is a clue, not a definitive failure.",
        traceGaps: ["App landing event captured"],
        disqualifyingEvidence: ["Landing event captured", "Successful flow with landing observed"]
      })
    );
  }
  return findings;
};

// src/rules/samlRules.ts
var isSaml = (e) => e.protocol === "SAML";
var KNOWN_STATIC_HOSTS2 = [
  "zohocdn.com",
  "static.zohocdn.com",
  "google-analytics.com",
  "googletagmanager.com",
  "segment.io",
  "segment.com",
  "hotjar.com",
  "intercom.io",
  "zendesk.com"
];
var isKnownStaticHost2 = (host) => {
  const h = host.toLowerCase();
  return KNOWN_STATIC_HOSTS2.some((s) => h === s || h.endsWith("." + s));
};
var normalizeUrl = (urlStr) => {
  try {
    const url = new URL(urlStr);
    const normalized = new URL(url.origin);
    normalized.pathname = (url.pathname.replace(/\/+$/, "") || "/").toLowerCase();
    const sortedParams = [...new URLSearchParams(url.search)].sort((a, b) => a[0].localeCompare(b[0]));
    normalized.search = sortedParams.map(([k, v]) => `${k}=${v}`).join("&");
    return normalized.toString().replace(/\/+$/, "");
  } catch {
    return urlStr;
  }
};
var urlsMatch = (url1, url2) => {
  const n1 = normalizeUrl(url1);
  const n2 = normalizeUrl(url2);
  if (n1 === n2) return "exact";
  try {
    const u1 = new URL(url1);
    const u2 = new URL(url2);
    if (u1.host.toLowerCase() !== u2.host.toLowerCase()) return "none";
    const p1 = u1.pathname.replace(/\/+$/, "");
    const p2 = u2.pathname.replace(/\/+$/, "");
    if (p1 === p2) return "path";
    if (p1.startsWith(p2 + "/")) return "path";
    if (p2.startsWith(p1 + "/")) return "path";
    return "host";
  } catch {
    return "none";
  }
};
var isLikelyDocumentLanding = (event) => {
  try {
    const url = new URL(event.url);
    const pathname = url.pathname;
    if (/\.(css|js|png|svg|woff|ico|jpg|jpeg|gif|webp|json)(\?|$)/i.test(pathname)) return false;
    if (pathname.includes("/ws/") || pathname.includes("/chat/") || pathname.includes("/status")) return false;
    if (url.hostname.includes("statuspage") || url.hostname.includes("wss.")) return false;
    if (isKnownStaticHost2(url.hostname)) return false;
    if (pathname === "/" || pathname === "" || pathname === "/home" || pathname === "/app" || pathname === "/dashboard") return true;
    if (pathname.endsWith(".html") || pathname.endsWith(".htm")) return true;
    return false;
  } catch {
    return false;
  }
};
var detectSamlFlow = (events, responseEvent) => {
  if ((responseEvent.statusCode ?? 0) >= 400) {
    return { success: "none", captureCompleteness: "unknown" };
  }
  const samlEvents = events.filter(isSaml);
  const relayState = responseEvent.relayState;
  let relayStateUrl;
  if (relayState) {
    try {
      relayStateUrl = new URL(relayState);
    } catch {
    }
  }
  const windowStart = responseEvent.timestamp;
  const windowEnd = responseEvent.timestamp + 3e4;
  const postAcsRequests = events.filter(
    (e) => e.timestamp >= windowStart && e.timestamp <= windowEnd && e.method === "GET" && (!e.statusCode || e.statusCode < 400 || e.statusCode >= 300 && e.statusCode < 400)
  ).filter((e) => isLikelyDocumentLanding(e));
  let matchLevel = "none";
  if (relayStateUrl) {
    for (const req of postAcsRequests) {
      const m = urlsMatch(req.url, relayStateUrl.href);
      if (m === "exact" || m === "path") {
        matchLevel = m;
        break;
      }
      if (matchLevel === "none" && m === "host") {
        matchLevel = "host";
      }
    }
  }
  if (matchLevel === "exact" || matchLevel === "path") {
    return { success: "clear", captureCompleteness: "late" };
  }
  if (matchLevel === "host" || postAcsRequests.length > 0) {
    return { success: "probable", captureCompleteness: "late" };
  }
  return { success: "none", captureCompleteness: "unknown" };
};
var runSamlRules = (events) => {
  const findings = [];
  const samlEvents = events.filter(isSaml);
  const requestEvent = samlEvents.find((e) => e.samlRequest);
  const responseEvent = samlEvents.find((e) => e.samlResponse);
  if (!responseEvent) {
    findings.push(
      makeFinding({
        ruleId: "SAML_MISSING_RESPONSE",
        severity: "error",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "Missing SAMLResponse",
        explanation: "No SAMLResponse was captured in this trace.",
        observed: "SAMLResponse not found",
        expected: "SAMLResponse posted to ACS",
        evidence: samlEvents.map((e) => e.url),
        action: "Confirm vendor ACS endpoint receives POST and browser is not blocked by extensions/CSP.",
        confidence: 0.88
      })
    );
  }
  if (!requestEvent) {
    const flow = responseEvent ? detectSamlFlow(events, responseEvent) : { success: "none", captureCompleteness: "unknown" };
    const isSuccessful = flow.success === "clear" || flow.success === "probable";
    if (isSuccessful) {
      findings.push(
        makeFinding({
          ruleId: "SAML_CAPTURE_STARTED_LATE",
          severity: "info",
          protocol: "SAML",
          likelyOwner: "analysis",
          title: "Capture started after AuthnRequest",
          explanation: flow.success === "clear" ? "Flow appears successful but no AuthnRequest was captured - may be IdP-initiated or capture started late." : "Post-ACS activity detected but AuthnRequest was not captured - capture may be incomplete.",
          observed: "AuthnRequest not captured",
          expected: "Full SAML flow with both request and response",
          evidence: samlEvents.map((e) => e.url),
          action: "If this should be SP-initiated, start capture before clicking the app icon.",
          confidence: 0.6,
          isAmbiguous: true,
          ambiguityNote: "No AuthnRequest was captured. This could mean: (1) capture started after the request was sent, (2) IdP-initiated login that has no AuthnRequest, or (3) redirect binding AuthnRequest that wasn't captured.",
          traceGaps: ["AuthnRequest not captured"],
          disqualifyingEvidence: ["Captured AuthnRequest in the trace"]
        })
      );
    }
    if (flow.success === "clear") {
    } else if (flow.success === "probable") {
      findings.push(
        makeFinding({
          ruleId: "SAML_MISSING_REQUEST",
          severity: "info",
          protocol: "SAML",
          likelyOwner: "vendor SP",
          title: "Missing SAMLRequest",
          explanation: "No SP-initiated AuthnRequest was captured - flow may be IdP-initiated or capture started late.",
          observed: "SAMLRequest not found",
          expected: "SAMLRequest for SP-initiated flow",
          evidence: samlEvents.map((e) => e.url),
          action: "If this should be SP-initiated, confirm the app starts login with SAMLRequest.",
          confidence: 0.72,
          isAmbiguous: true,
          ambiguityNote: "No AuthnRequest captured. Could be SP-initiated with late capture, or IdP-initiated login.",
          traceGaps: ["AuthnRequest not captured"],
          disqualifyingEvidence: ["Captured AuthnRequest matching this response"]
        })
      );
    } else {
      findings.push(
        makeFinding({
          ruleId: "SAML_MISSING_REQUEST",
          severity: "warning",
          protocol: "SAML",
          likelyOwner: "vendor SP",
          title: "Missing SAMLRequest",
          explanation: "No SP-initiated AuthnRequest was captured.",
          observed: "SAMLRequest not found",
          expected: "SAMLRequest for SP-initiated flow",
          evidence: samlEvents.map((e) => e.url),
          action: "If this should be SP-initiated, confirm the app starts login with SAMLRequest.",
          confidence: 0.72,
          traceGaps: ["AuthnRequest not captured"]
        })
      );
    }
  }
  const parseErrorEvent = samlEvents.find(
    (e) => e.samlRequest?.parseError || e.samlResponse?.parseError
  );
  if (parseErrorEvent) {
    findings.push(
      makeFinding({
        ruleId: "SAML_UNPARSEABLE_ARTIFACT",
        severity: "error",
        protocol: "SAML",
        likelyOwner: "browser",
        title: "SAML artifact could not be parsed",
        explanation: "Base64 decode, DEFLATE decode, or XML parse failed.",
        observed: parseErrorEvent.samlRequest?.parseError ?? parseErrorEvent.samlResponse?.parseError ?? "unknown parse error",
        expected: "Valid base64 and XML payload",
        evidence: [parseErrorEvent.url],
        action: "Check whether copied SAML payload was truncated or incorrectly URL-encoded.",
        confidence: 0.94
      })
    );
  }
  if (responseEvent?.samlResponse?.destination) {
    const destination = responseEvent.samlResponse.destination;
    if (destination !== responseEvent.url) {
      findings.push(
        makeFinding({
          ruleId: "SAML_DESTINATION_MISMATCH",
          severity: "error",
          protocol: "SAML",
          likelyOwner: "vendor SP",
          title: "SAML Destination mismatch",
          explanation: "Destination in SAMLResponse does not match receiving endpoint.",
          observed: destination,
          expected: responseEvent.url,
          evidence: [responseEvent.url],
          action: "Compare SSO URL and vendor ACS/Destination values for exact match.",
          confidence: 0.93
        })
      );
    }
  }
  if (responseEvent?.samlResponse?.recipient && responseEvent.samlResponse.recipient !== responseEvent.url) {
    findings.push(
      makeFinding({
        ruleId: "SAML_ACS_RECIPIENT_MISMATCH",
        severity: "error",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "Recipient / ACS mismatch",
        explanation: "Assertion SubjectConfirmation Recipient does not match ACS endpoint.",
        observed: responseEvent.samlResponse.recipient,
        expected: responseEvent.url,
        evidence: [responseEvent.url],
        action: "Align Assertion Consumer Service URL with vendor ACS and posted endpoint.",
        confidence: 0.96
      })
    );
  }
  if (responseEvent?.samlResponse?.audience && requestEvent?.samlRequest?.issuer && responseEvent.samlResponse.audience !== requestEvent.samlRequest.issuer) {
    findings.push(
      makeFinding({
        ruleId: "SAML_AUDIENCE_MISMATCH",
        severity: "error",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "Audience / Entity ID mismatch",
        explanation: "Audience in assertion does not match SP Entity ID from request.",
        observed: responseEvent.samlResponse.audience,
        expected: requestEvent.samlRequest.issuer,
        evidence: [requestEvent.url, responseEvent.url],
        action: "Compare Service provider Entity ID in KZero with vendor SP Entity ID/Audience URI.",
        confidence: 0.95
      })
    );
  }
  if (responseEvent?.samlResponse?.issuer && requestEvent?.url.includes("auth.kzero.com")) {
    const tenantBase = requestEvent.url.split("/protocol/saml")[0];
    if (responseEvent.samlResponse.issuer !== tenantBase) {
      findings.push(
        makeFinding({
          ruleId: "SAML_ISSUER_MISMATCH",
          severity: "error",
          protocol: "SAML",
          likelyOwner: "KZero",
          title: "SAML issuer mismatch",
          explanation: "Issuer in SAMLResponse does not match KZero tenant base URL.",
          observed: responseEvent.samlResponse.issuer,
          expected: tenantBase,
          evidence: [responseEvent.url],
          action: "Verify Identity provider entity ID and tenant name casing in KZero.",
          confidence: 0.91
        })
      );
    }
  }
  if (responseEvent && !responseEvent.samlResponse?.nameId) {
    findings.push(
      makeFinding({
        ruleId: "SAML_MISSING_NAMEID",
        severity: "error",
        protocol: "SAML",
        likelyOwner: "user data",
        title: "Missing NameID",
        explanation: "Assertion has no NameID value for user identity mapping.",
        observed: "NameID missing",
        expected: "NameID present",
        evidence: [responseEvent.url],
        action: "Check Principal type, Pass subject, and NameID Policy Format mappings.",
        confidence: 0.9
      })
    );
  }
  if (responseEvent?.relayState && !requestEvent?.relayState) {
    const flow = responseEvent ? detectSamlFlow(samlEvents, responseEvent) : { success: "none", captureCompleteness: "unknown" };
    const severity = flow.success === "clear" || flow.success === "probable" ? "info" : "warning";
    const isAmbiguous = flow.success !== "none" && !requestEvent;
    findings.push(
      makeFinding({
        ruleId: "SAML_RELAYSTATE_UNEXPECTED",
        severity,
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "Unexpected RelayState behavior",
        explanation: flow.success !== "none" ? "RelayState present in response but not request - likely capture started late." : "RelayState appeared in response without matching request value.",
        observed: "response RelayState present, request missing",
        expected: "Stable RelayState round-trip",
        evidence: [responseEvent.url],
        action: "Verify vendor Relay State setting and preserve value across redirects.",
        confidence: 0.75,
        isAmbiguous,
        ambiguityNote: isAmbiguous ? "No AuthnRequest was captured, so we cannot verify if RelayState was expected on the request side." : void 0,
        traceGaps: !requestEvent ? ["AuthnRequest not captured - cannot verify RelayState round-trip"] : void 0
      })
    );
  }
  if (responseEvent && !responseEvent.samlResponse?.assertionSigned) {
    findings.push(
      makeFinding({
        ruleId: "SAML_ASSERTION_SIGNATURE_MISSING",
        severity: "warning",
        protocol: "SAML",
        likelyOwner: "KZero",
        title: "Assertion signature not detected",
        explanation: "No assertion-level signature was found in parsed XML.",
        observed: "assertion signature not detected",
        expected: "Signed assertion when vendor requires it",
        evidence: [responseEvent.url],
        action: "Confirm Want assertions signed and Validate signatures settings.",
        confidence: 0.78
      })
    );
  }
  if (responseEvent && !responseEvent.samlResponse?.documentSigned) {
    findings.push(
      makeFinding({
        ruleId: "SAML_DOCUMENT_SIGNATURE_MISSING",
        severity: "info",
        protocol: "SAML",
        likelyOwner: "unknown",
        title: "Document signature not detected",
        explanation: "Response-level signature was not detected.",
        observed: "document signature not detected",
        expected: "Signed response when SP requires document signature",
        evidence: [responseEvent.url],
        action: "Match signing expectations between vendor and KZero signature settings.",
        confidence: 0.7
      })
    );
  }
  if (responseEvent?.samlResponse?.notOnOrAfter) {
    const expiry = Date.parse(responseEvent.samlResponse.notOnOrAfter);
    if (!Number.isNaN(expiry) && expiry < Date.now()) {
      findings.push(
        makeFinding({
          ruleId: "SAML_CLOCK_SKEW",
          severity: "error",
          protocol: "SAML",
          likelyOwner: "network",
          title: "SAML assertion expired",
          explanation: "Assertion validity window has already ended.",
          observed: responseEvent.samlResponse.notOnOrAfter,
          expected: "Assertion still within NotOnOrAfter window",
          evidence: [responseEvent.url],
          action: "Check system clocks and adjust Allow clock skew if needed.",
          confidence: 0.9
        })
      );
    }
  }
  if (responseEvent?.samlResponse?.notBefore) {
    const notBefore = Date.parse(responseEvent.samlResponse.notBefore);
    if (!Number.isNaN(notBefore) && notBefore > Date.now()) {
      findings.push(
        makeFinding({
          ruleId: "SAML_CLOCK_SKEW_NOT_BEFORE",
          severity: "error",
          protocol: "SAML",
          likelyOwner: "network",
          title: "SAML assertion not yet valid",
          explanation: "NotBefore is in the future relative to local capture time.",
          observed: responseEvent.samlResponse.notBefore,
          expected: "Current time after NotBefore",
          evidence: [responseEvent.url],
          action: "Check system clocks and increase Allow clock skew where appropriate.",
          confidence: 0.9
        })
      );
    }
  }
  if (responseEvent && requestEvent?.samlRequest && !responseEvent.samlResponse?.inResponseTo) {
    findings.push(
      makeFinding({
        ruleId: "SAML_INRESPONSETO_MISSING",
        severity: "warning",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "InResponseTo missing",
        explanation: "SP-initiated flow usually expects InResponseTo in SAMLResponse.",
        observed: "InResponseTo missing",
        expected: "InResponseTo references AuthnRequest ID",
        evidence: [responseEvent.url],
        action: "Confirm SP-initiated mode and whether IdP-initiated responses are accepted.",
        confidence: 0.76
      })
    );
  }
  if (responseEvent?.samlResponse?.encryptedAssertion) {
    findings.push(
      makeFinding({
        ruleId: "SAML_ASSERTION_ENCRYPTED",
        severity: "warning",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "Assertion is encrypted",
        explanation: "Some SP implementations fail when encrypted assertions are enabled.",
        observed: "EncryptedAssertion present",
        expected: "SP supports encrypted assertions with correct certificate",
        evidence: [responseEvent.url],
        action: "Check Want assertions encrypted and vendor certificate compatibility.",
        confidence: 0.73
      })
    );
  }
  if (responseEvent?.samlResponse?.nameId && responseEvent.samlResponse.nameIdFormat) {
    const format = responseEvent.samlResponse.nameIdFormat.toLowerCase();
    const value = responseEvent.samlResponse.nameId;
    if (format.includes("email") && !value.includes("@")) {
      findings.push(
        makeFinding({
          ruleId: "SAML_NAMEID_FORMAT_MISMATCH",
          severity: "warning",
          protocol: "SAML",
          likelyOwner: "user data",
          title: "Likely wrong NameID format",
          explanation: "NameID format indicates email but value is not email-like.",
          observed: `${responseEvent.samlResponse.nameIdFormat} -> ${value}`,
          expected: "Email NameID format with email value",
          evidence: [responseEvent.url],
          action: "Align NameID Policy Format with actual principal value mapping.",
          confidence: 0.87
        })
      );
    }
  }
  if (!requestEvent && responseEvent?.samlResponse?.inResponseTo) {
    findings.push(
      makeFinding({
        ruleId: "SAML_IDP_SP_INIT_MISMATCH_CLUE",
        severity: "info",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "IdP vs SP initiated flow mismatch clue",
        explanation: "Response carries InResponseTo but no AuthnRequest is present in this capture.",
        observed: `InResponseTo=${responseEvent.samlResponse.inResponseTo}`,
        expected: "Captured AuthnRequest for SP-initiated flow",
        evidence: [responseEvent.url],
        action: "Verify capture start timing and whether the app expects IdP-initiated or SP-initiated login.",
        confidence: 0.64,
        isAmbiguous: true,
        ambiguityNote: "Response contains InResponseTo (suggesting SP-initiated) but no AuthnRequest was captured. This could mean capture started late, or this is actually an IdP-initiated flow that includes InResponseTo from a prior SP-initiated request.",
        traceGaps: ["AuthnRequest not captured"],
        disqualifyingEvidence: ["Captured AuthnRequest that matches InResponseTo", "Confirmed IdP-initiated login without InResponseTo"]
      })
    );
  }
  if (responseEvent?.binding === "redirect" && responseEvent.samlResponse) {
    findings.push(
      makeFinding({
        ruleId: "SAML_WRONG_BINDING_CLUE",
        severity: "warning",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "Unexpected SAML response binding",
        explanation: "SAMLResponse over Redirect binding can fail with SPs expecting POST binding.",
        observed: "Response binding=redirect",
        expected: "HTTP-POST binding response where required",
        evidence: [responseEvent.url],
        action: "Compare HTTP-POST binding response settings on KZero and vendor SAML config.",
        confidence: 0.72
      })
    );
  }
  if ((responseEvent?.statusCode ?? 0) >= 400 && responseEvent?.samlResponse) {
    findings.push(
      makeFinding({
        ruleId: "SAML_CERT_SIGNATURE_VALIDATION_CLUE",
        severity: "warning",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "Signature/certificate validation mismatch clue",
        explanation: "SP endpoint returned an error while receiving a SAML assertion, often due to cert/signature expectations.",
        observed: `ACS status ${responseEvent.statusCode}`,
        expected: "ACS accepts assertion and returns success",
        evidence: [responseEvent.url],
        action: "Compare Tenant certificate/XML data and Validate signatures settings with vendor certificate configuration.",
        confidence: 0.67
      })
    );
  }
  if (requestEvent?.samlRequest?.forceAuthn || requestEvent?.samlRequest?.allowCreate === false) {
    findings.push(
      makeFinding({
        ruleId: "SAML_POLICY_MISMATCH_CLUE",
        severity: "info",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "NameID / ForceAuthn policy mismatch clue",
        explanation: "AuthnRequest policy flags can conflict with current IdP/SP expectations.",
        observed: `ForceAuthn=${requestEvent.samlRequest.forceAuthn}, AllowCreate=${requestEvent.samlRequest.allowCreate}`,
        expected: "Policy flags aligned with SP requirements",
        evidence: [requestEvent.url],
        action: "Review Force authentication, Allow create, and NameID Policy Format values.",
        confidence: 0.58
      })
    );
  }
  if (requestEvent?.binding === "redirect" && requestEvent.samlRequest && !requestEvent.url.includes("Signature=")) {
    findings.push(
      makeFinding({
        ruleId: "SAML_AUTHNREQUEST_SIGN_EXPECTATION_MISMATCH",
        severity: "info",
        protocol: "SAML",
        likelyOwner: "vendor SP",
        title: "AuthnRequest signature may be missing",
        explanation: "Redirect binding request appears unsigned.",
        observed: "Signature parameter not found",
        expected: "Signed AuthnRequest when Want AuthnRequests signed is enabled",
        evidence: [requestEvent.url],
        action: "Compare Want AuthnRequests signed with vendor signed request requirement.",
        confidence: 0.68
      })
    );
  }
  return findings;
};

// src/rules/index.ts
var ALWAYS_NOISE_RULES = [
  "SAML_DOCUMENT_SIGNATURE_MISSING",
  "OIDC_ACCESS_TOKEN_OPAQUE"
];
var filterNoise = (findings) => {
  return findings.filter((f) => {
    if (ALWAYS_NOISE_RULES.includes(f.ruleId)) {
      return false;
    }
    return true;
  });
};
var runFindingsEngine = (events) => {
  const findings = [...runSamlRules(events), ...runOidcRules(events), ...runCrossRules(events)];
  const dedupe = /* @__PURE__ */ new Map();
  for (const finding of findings) {
    const key = `${finding.ruleId}-${finding.observed}-${finding.expected}`;
    if (!dedupe.has(key)) {
      dedupe.set(key, finding);
    }
  }
  return filterNoise([...dedupe.values()]);
};

// src/capture/hostClassifier.ts
var NOISE_HOSTS = [
  "google-analytics.com",
  "www.google-analytics.com",
  "googletagmanager.com",
  "www.googletagmanager.com",
  "facebook.com",
  "www.facebook.com",
  "fbcdn.net",
  "www.fbcdn.net",
  "doubleclick.net",
  "www.doubleclick.net",
  "adnxs.com",
  "www.adnxs.com",
  "criteo.com",
  "www.criteo.com",
  "hotjar.com",
  "www.hotjar.com",
  "mixpanel.com",
  "www.mixpanel.com",
  "segment.com",
  "www.segment.com",
  "amplitude.com",
  "www.amplitude.com",
  "newrelic.com",
  "www.newrelic.com",
  "nr-data.net",
  "www.nr-data.net",
  "sentry.io",
  "www.sentry.io",
  "datadog.com",
  "www.datadog.com",
  "loggly.com",
  "www.loggly.com",
  "papertrail.com",
  "www.papertrail.com"
];
var AUTH_PATH_PATTERNS = [
  /\/saml\//i,
  /\/sso\//i,
  /\/oauth2?\//i,
  /openid-connect\//i,
  /\/auth\//i,
  /\/login\//i,
  /\/acs\//i,
  /\/callback\//i,
  /\/token\//i,
  /\/userinfo\//i,
  /\/logout\//i,
  /\/authorize\//i,
  /\/register\//i,
  /\/signup\//i,
  /\/signin\//i
];
var AUTH_PARAM_KEYS = [
  "samlrequest",
  "samlresponse",
  "relaystate",
  "code",
  "id_token",
  "access_token",
  "state",
  "nonce",
  "redirect_uri",
  "response_type",
  "scope"
];
var CALLBACK_PATTERNS = [
  /\?code=/i,
  /\?state=/i,
  /\?id_token=/i,
  /\?access_token=/i,
  /\/oauth2\/callback/i,
  /\/oauth\/callback/i,
  /\/saml\/acs/i,
  /\/sso\/saml\/acs/i
];
var classifyEvent = (event) => {
  const reasons = [];
  let classification = "unknown";
  const hostLower = event.host?.toLowerCase() ?? "";
  if (hostLower) {
    for (const noiseHost of NOISE_HOSTS) {
      if (hostLower === noiseHost || hostLower.endsWith("." + noiseHost)) {
        return {
          classification: "noise",
          reasons: [`known noise host: ${event.host}`],
          isAuthRelevant: false
        };
      }
    }
  }
  const url = event.url ?? "";
  try {
    const urlObj = new URL(url);
    const path = urlObj.pathname.toLowerCase();
    const query = urlObj.search.toLowerCase();
    const method = event.method?.toUpperCase() ?? "GET";
    for (const pattern of AUTH_PATH_PATTERNS) {
      if (pattern.test(path)) {
        classification = "auth-critical";
        reasons.push(`auth path pattern: ${pattern.source}`);
        break;
      }
    }
    for (const key of AUTH_PARAM_KEYS) {
      if (query.includes(key.toLowerCase())) {
        if (classification === "unknown") classification = "flow-adjacent";
        reasons.push(`auth param: ${key}`);
      }
    }
    for (const pattern of CALLBACK_PATTERNS) {
      if (pattern.test(path) || pattern.test(query)) {
        if (classification === "unknown") classification = "flow-adjacent";
        reasons.push("callback pattern");
      }
    }
    if (method === "POST") {
      let postBody = "";
      if ("postBody" in event && typeof event.postBody === "string") {
        postBody = event.postBody.toLowerCase();
      } else if ("artifacts" in event && event.artifacts && typeof event.artifacts === "object") {
        const artifacts = event.artifacts;
        if (typeof artifacts.body === "string") {
          postBody = artifacts.body.toLowerCase();
        }
      }
      if (postBody.includes("saml") || postBody.includes("samlrequest") || postBody.includes("samlresponse")) {
        classification = "auth-critical";
        reasons.push("SAML POST body");
      }
    }
    if (event.statusCode !== void 0) {
      if (event.statusCode >= 400) {
        if (classification === "unknown") {
          reasons.push(`error response: ${event.statusCode}`);
        }
      }
    }
  } catch {
    reasons.push("invalid URL - kept as unknown");
  }
  if ("protocol" in event && event.protocol !== "unknown" && event.protocol !== "network") {
    if (classification === "unknown") classification = "auth-critical";
    if (!reasons.some((r) => r.startsWith("protocol:"))) {
      reasons.push(`protocol: ${event.protocol}`);
    }
  }
  if (reasons.length === 0) {
    reasons.push("no classification match");
  }
  const isAuthRelevant = classification === "auth-critical" || classification === "flow-adjacent";
  return { classification, reasons, isAuthRelevant };
};

// src/shared/settings.ts
var SETTINGS_VERSION = 3;
var DEFAULT_SETTINGS_V3 = {
  autoStartOnTabSwitch: false,
  maxHistoryItems: 30,
  redactionStrictness: "strict",
  defaultDetailTab: "happened",
  showOnboarding: true,
  captureScope: "auth-only",
  allowedHosts: [],
  hasSeenScopeNotice: true,
  settingsVersion: SETTINGS_VERSION,
  debugEnabled: false
};
var SETTINGS_KEY = "settings";
var migrateSettings = (stored) => {
  if (!stored) {
    return { ...DEFAULT_SETTINGS_V3 };
  }
  if (!stored.settingsVersion || stored.settingsVersion < SETTINGS_VERSION) {
    return {
      ...DEFAULT_SETTINGS_V3,
      ...stored,
      captureScope: stored.captureScope ?? "full",
      hasSeenScopeNotice: false,
      settingsVersion: SETTINGS_VERSION,
      debugEnabled: stored.debugEnabled ?? false
    };
  }
  return { ...DEFAULT_SETTINGS_V3, ...stored };
};
var getSettings = async () => {
  const result = await chrome.storage.local.get(SETTINGS_KEY);
  const stored = result[SETTINGS_KEY];
  return migrateSettings(stored);
};

// src/shared/debugLog.ts
var DEBUG_KEY = "debug:logs";
var MAX_DEBUG_ENTRIES = 500;
var logDebug = async (source, message, data) => {
  try {
    const result = await chrome.storage.local.get(DEBUG_KEY);
    const logs = result[DEBUG_KEY] ?? [];
    const entry = {
      timestamp: Date.now(),
      source,
      message,
      data
    };
    const updated = [entry, ...logs].slice(0, MAX_DEBUG_ENTRIES);
    await chrome.storage.local.set({ [DEBUG_KEY]: updated });
  } catch {
  }
};

// src/capture/sessionStore.ts
var sessions = /* @__PURE__ */ new Map();
var sessionCache = /* @__PURE__ */ new Map();
var HISTORY_KEY = "history:sessions";
var HISTORY_MAX = 30;
var MAX_EVENTS_PER_SESSION = 500;
var MAX_SESSION_SIZE_BYTES = 512 * 1024;
var GLOBAL_TAB_ID = 0;
var storageGet = async (key) => {
  const result = await chrome.storage.local.get(key);
  return result[key];
};
var storageSet = async (key, value) => {
  await chrome.storage.local.set({ [key]: value });
};
var storageRemove = async (key) => {
  await chrome.storage.local.remove(key);
};
var SESSION_KEY = (tabId) => `session:${tabId}`;
void chrome.storage.local.get(null, (items) => {
  for (const [key, value] of Object.entries(items)) {
    if (key.startsWith("session:") && value && typeof value === "object") {
      const s = value;
      sessionCache.set(s.tabId, s);
      if (s.active) {
        sessions.set(s.tabId, s);
      }
    }
  }
});
var ensureSession = (tabId) => {
  const existing = sessions.get(tabId);
  if (existing) return existing;
  const stored = sessionCache.get(tabId);
  if (stored) {
    sessions.set(tabId, stored);
    return stored;
  }
  const created = {
    tabId,
    active: false,
    rawEvents: [],
    normalizedEvents: [],
    findings: []
  };
  sessions.set(tabId, created);
  return created;
};
var isHostAllowed = (host, allowedHosts) => {
  const hostLower = host.toLowerCase();
  return allowedHosts.some((h) => {
    const allowedLower = h.toLowerCase();
    return hostLower === allowedLower || hostLower.endsWith("." + allowedLower);
  });
};
var shouldCaptureEvent = async (raw) => {
  const settings = await getSettings();
  const { classification, isAuthRelevant } = classifyEvent(raw);
  if (settings.captureScope === "full") {
    return true;
  }
  if (settings.captureScope === "auth-only") {
    if (classification === "noise") {
      void logDebug("capture", "Event filtered (noise)", {
        url: raw.url,
        host: raw.host,
        classification
      });
      return false;
    }
    return true;
  }
  if (settings.captureScope === "auth-plus-allowlist") {
    if (classification === "noise") {
      const allowed = isHostAllowed(raw.host ?? "", settings.allowedHosts);
      if (!allowed) {
        void logDebug("capture", "Event filtered (noise, not allowlisted)", {
          url: raw.url,
          host: raw.host,
          classification
        });
      }
      return allowed;
    }
    return true;
  }
  return true;
};
var sessionDiscoveredHosts = /* @__PURE__ */ new Set();
var startCapture = async (_tabId) => {
  const session = ensureSession(GLOBAL_TAB_ID);
  session.active = true;
  session.startedAt = Date.now();
  session.rawEvents = [];
  session.normalizedEvents = [];
  session.findings = [];
  sessionDiscoveredHosts.clear();
  void storageSet(SESSION_KEY(GLOBAL_TAB_ID), session);
  void logDebug("capture", "Capture started", { tabId: session.tabId });
  return session;
};
var stopCapture = (_tabId) => {
  const session = ensureSession(GLOBAL_TAB_ID);
  session.active = false;
  session.stoppedAt = Date.now();
  void storageSet(SESSION_KEY(GLOBAL_TAB_ID), session);
  void logDebug("capture", "Capture stopped", {
    tabId: session.tabId,
    eventCount: session.rawEvents.length,
    startedAt: session.startedAt,
    stoppedAt: session.stoppedAt
  });
  void persistHistoryItem(session);
  return session;
};
var clearSession = (_tabId) => {
  const session = ensureSession(GLOBAL_TAB_ID);
  session.rawEvents = [];
  session.normalizedEvents = [];
  session.findings = [];
  sessionDiscoveredHosts.clear();
  void storageRemove(SESSION_KEY(GLOBAL_TAB_ID));
  return session;
};
var addRawEvent = async (tabId, raw) => {
  const globalSession = sessions.get(GLOBAL_TAB_ID);
  if (!globalSession?.active) {
    return void 0;
  }
  if (!await shouldCaptureEvent(raw)) {
    return globalSession;
  }
  if (globalSession.rawEvents.length >= MAX_EVENTS_PER_SESSION) return globalSession;
  const sessionSize = new Blob([JSON.stringify(globalSession)]).size;
  const rawSize = new Blob([JSON.stringify(raw)]).size;
  if (sessionSize + rawSize > MAX_SESSION_SIZE_BYTES) {
    void logDebug("capture", "Event dropped (session size limit)", { url: raw.url });
    return globalSession;
  }
  const { isAuthRelevant } = classifyEvent(raw);
  if (isAuthRelevant && raw.host) {
    sessionDiscoveredHosts.add(raw.host);
  }
  globalSession.rawEvents.push(raw);
  const normalized = normalizeRawEvent(raw);
  globalSession.normalizedEvents.push(normalized);
  globalSession.normalizedEvents.sort((a, b) => a.timestamp - b.timestamp);
  globalSession.findings = runFindingsEngine(globalSession.normalizedEvents);
  void storageSet(SESSION_KEY(GLOBAL_TAB_ID), globalSession);
  return globalSession;
};
var getSession = (_tabId) => ensureSession(GLOBAL_TAB_ID);
var persistHistoryItem = async (session) => {
  if (!session.startedAt || !session.stoppedAt) return;
  const history = await storageGet(HISTORY_KEY) ?? [];
  const protocolHints = [...new Set(session.normalizedEvents.map((event) => event.protocol))].filter((p) => p !== "unknown").map((p) => String(p));
  const snapshot = {
    id: nowId(),
    tabId: session.tabId,
    startedAt: session.startedAt,
    stoppedAt: session.stoppedAt,
    protocolHints,
    findingCount: session.findings.length,
    session: JSON.parse(JSON.stringify(session))
  };
  const next = [snapshot, ...history].slice(0, HISTORY_MAX);
  await storageSet(HISTORY_KEY, next);
};
var getHistory = async () => await storageGet(HISTORY_KEY) ?? [];
var clearHistory = async () => {
  await storageRemove(HISTORY_KEY);
};
var loadHistoryItem = async (itemId) => {
  const history = await getHistory();
  return history.find((item) => item.id === itemId);
};

// src/background/index.ts
var panelPorts = /* @__PURE__ */ new Map();
var contentPorts = /* @__PURE__ */ new Map();
chrome.alarms.create("keepalive", { periodInMinutes: 0.25 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== "keepalive") return;
  void getSession(0);
});
chrome.runtime.onInstalled.addListener(() => {
  const sidePanel = chrome.sidePanel;
  if (!sidePanel?.setPanelBehavior) return;
  void sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});
chrome.commands.onCommand.addListener((command) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tabId = tabs[0]?.id;
    if (typeof tabId !== "number") return;
    const ports = panelPorts.get(tabId) ?? [];
    ports.forEach((port) => port.postMessage({ type: "COMMAND", command }));
  });
});
var broadcast = (_tabId, session) => {
  for (const [, ports] of panelPorts) {
    ports.forEach((port) => port.postMessage({ type: "SESSION_UPDATE", session }));
  }
};
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "kzero-panel") return;
  let tabId = port.sender?.tab?.id ?? -1;
  port.onMessage.addListener((msg) => {
    if (msg.type === "PANEL_INIT") {
      tabId = msg.tabId ?? tabId;
      const ports = panelPorts.get(tabId) ?? [];
      ports.push(port);
      panelPorts.set(tabId, ports);
      port.postMessage({ type: "SESSION_UPDATE", session: getSession(tabId) });
    }
  });
  port.onDisconnect.addListener(() => {
    if (tabId < 0) return;
    const ports = (panelPorts.get(tabId) ?? []).filter((p) => p !== port);
    panelPorts.set(tabId, ports);
  });
});
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "kzero-content") return;
  const tabId = port.sender?.tab?.id;
  if (typeof tabId !== "number") return;
  contentPorts.set(tabId, port);
  port.onDisconnect.addListener(() => {
    const existing = contentPorts.get(tabId);
    if (existing === port) contentPorts.delete(tabId);
  });
  port.onMessage.addListener((msg) => {
    if (msg?.type === "UI_SCAN_RESULT") {
      const ports = panelPorts.get(tabId) ?? [];
      ports.forEach((p) => p.postMessage({ ...msg, tabId }));
    }
  });
});
chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  const respond = (response) => sendResponse(response);
  if (message.type === "GET_HISTORY") {
    void logDebug("background", "GET_HISTORY request");
    void getHistory().then((history) => respond({ ok: true, history }));
    return true;
  }
  if (message.type === "CLEAR_HISTORY") {
    void logDebug("background", "CLEAR_HISTORY request");
    await clearHistory();
    void getHistory().then((history) => respond({ ok: true, history }));
    return true;
  }
  if (message.type === "SET_TAB") {
    const tabId2 = message.tabId;
    if (typeof tabId2 === "number") {
      void chrome.tabs.get(tabId2, (tab) => {
        if (tab?.url) {
          respond({ ok: true, session: getSession(tabId2) });
        } else {
          respond({ ok: false, error: "Tab not found" });
        }
      });
    }
    return true;
  }
  if (message.type === "LOAD_HISTORY_ITEM") {
    void loadHistoryItem(message.itemId).then((item) => {
      if (!item) {
        respond({ ok: false, error: "History item not found" });
        return;
      }
      respond({ ok: true, session: item.session });
    });
    return true;
  }
  if (message.type === "REQUEST_UI_SCAN") {
    const port = contentPorts.get(message.tabId);
    if (port) {
      port.postMessage({ type: "SCAN_FIELDS", requestId: message.requestId, labels: message.labels });
      respond({ ok: true });
    } else {
      void (async () => {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: message.tabId },
            files: ["content.js"]
          });
          const retryPort = contentPorts.get(message.tabId);
          if (retryPort) {
            retryPort.postMessage({ type: "SCAN_FIELDS", requestId: message.requestId, labels: message.labels });
            respond({ ok: true });
          } else {
            respond({ ok: false, error: "Content script did not connect after injection" });
          }
        } catch (err2) {
          respond({ ok: false, error: `Could not inject content script: ${err2}` });
        }
      })();
    }
    return true;
  }
  if (message.type === "REQUEST_UI_HIGHLIGHT") {
    const port = contentPorts.get(message.tabId);
    if (port) {
      port.postMessage({ type: "HIGHLIGHT_FIELD", requestId: message.requestId, labels: message.labels });
      respond({ ok: true });
    } else {
      void (async () => {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: message.tabId },
            files: ["content.js"]
          });
          const retryPort = contentPorts.get(message.tabId);
          if (retryPort) {
            retryPort.postMessage({ type: "HIGHLIGHT_FIELD", requestId: message.requestId, labels: message.labels });
          }
        } catch {
        }
      })();
    }
    return;
  }
  if (message.type === "OPEN_POPUP") {
    const url = chrome.runtime.getURL(`sidepanel.html?popup=1&targetTabId=${encodeURIComponent(String(message.targetTabId))}`);
    chrome.windows.create(
      {
        url,
        type: "popup",
        width: 560,
        height: 860
      },
      () => respond({ ok: true })
    );
    return true;
  }
  const tabId = message.tabId ?? sender.tab?.id;
  if (typeof tabId !== "number") {
    respond({ ok: false, error: "Missing tabId" });
    return;
  }
  switch (message.type) {
    case "START_CAPTURE": {
      startCapture(tabId).then((session) => {
        broadcast(tabId, session);
        respond({ ok: true, session });
      }).catch(() => {
        const session = getSession(tabId);
        respond({ ok: true, session });
      });
      return;
    }
    case "STOP_CAPTURE": {
      const session = stopCapture(tabId);
      broadcast(tabId, session);
      respond({ ok: true, session });
      return;
    }
    case "CLEAR_SESSION": {
      const session = clearSession(tabId);
      broadcast(tabId, session);
      respond({ ok: true, session });
      return;
    }
    case "GET_SESSION": {
      respond({ ok: true, session: getSession(tabId) });
      return;
    }
    case "DEVTOOLS_NETWORK_EVENT":
    case "CONTENT_FORM_EVENT": {
      addRawEvent(tabId, message.event).then((session) => {
        if (session) broadcast(tabId, session);
        respond({ ok: true, session: session ?? getSession(tabId) });
      }).catch(() => {
        respond({ ok: true, session: getSession(tabId) });
      });
      return;
    }
    default:
      respond({ ok: false, error: "Unsupported message type" });
  }
  return true;
});
var makeWebRequestEvent = (tabId, url, method, statusCode, requestHeaders, responseHeaders, queryParams, errorText, redirectUrl, timingMs) => ({
  id: nowId(),
  tabId,
  source: errorText ? "webrequest-error" : "webrequest",
  timestamp: Date.now(),
  url,
  method,
  statusCode,
  requestHeaders,
  responseHeaders,
  queryParams,
  errorText,
  redirectUrl,
  timingMs,
  host: (() => {
    try {
      return new URL(url).host;
    } catch {
      return "";
    }
  })()
});
chrome.webRequest.onCompleted.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const event = makeWebRequestEvent(
      details.tabId,
      details.url,
      details.method,
      details.statusCode,
      void 0,
      details.responseHeaders ? toHeaderMap(details.responseHeaders) : void 0,
      parseQueryString(details.url.split("?")[1] ?? "")
    );
    addRawEvent(details.tabId, event).then((session) => {
      if (session) broadcast(details.tabId, session);
    });
  },
  { urls: ["<all_urls>"] }
);
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.tabId < 0) return;
    let postBody;
    if (details.requestBody?.raw?.[0]?.bytes) {
      const bytes = details.requestBody.raw[0].bytes;
      if (bytes.byteLength > 100 * 1024) {
        postBody = "[body truncated \u2014 exceeds 100KB]";
      } else {
        postBody = String.fromCharCode(...new Uint8Array(bytes));
      }
    }
    const event = {
      id: nowId(),
      tabId: details.tabId,
      source: "webrequest",
      timestamp: Date.now(),
      url: details.url,
      method: details.method,
      postBody,
      queryParams: parseQueryString(details.url.split("?")[1] ?? ""),
      host: (() => {
        try {
          return new URL(details.url).host;
        } catch {
          return "";
        }
      })()
    };
    void chrome.storage.local.set({ _debug_last_event: event });
    addRawEvent(details.tabId, event).then((session) => {
      if (session) broadcast(details.tabId, session);
    });
  },
  { urls: ["<all_urls>"], types: ["main_frame", "sub_frame"] },
  ["requestBody"]
);
chrome.webRequest.onErrorOccurred.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const event = makeWebRequestEvent(
      details.tabId,
      details.url,
      details.method,
      void 0,
      void 0,
      void 0,
      parseQueryString(details.url.split("?")[1] ?? ""),
      details.error
    );
    addRawEvent(details.tabId, event).then((session) => {
      if (session) broadcast(details.tabId, session);
    });
  },
  { urls: ["<all_urls>"] }
);
var makeRawEventFromDevtools = (tabId, payload) => ({
  id: nowId(),
  tabId,
  source: "devtools-network",
  timestamp: payload.startedDateTime ? Date.parse(payload.startedDateTime) : Date.now(),
  url: payload.url,
  method: payload.method,
  statusCode: payload.statusCode,
  requestHeaders: toHeaderMap(payload.requestHeaders ?? []),
  responseHeaders: toHeaderMap(payload.responseHeaders ?? []),
  queryParams: parseQueryString(
    (payload.queryString ?? []).map((entry) => `${encodeURIComponent(entry.name)}=${encodeURIComponent(entry.value)}`).join("&")
  ),
  postBody: payload.postData,
  responseBody: payload.responseBody,
  redirectUrl: payload.redirectURL,
  timingMs: payload.time,
  host: (() => {
    try {
      return new URL(payload.url).host;
    } catch {
      return "";
    }
  })()
});
export {
  makeRawEventFromDevtools
};
/*! Bundled license information:

pako/dist/pako.esm.mjs:
  (*! pako 2.1.0 https://github.com/nodeca/pako @license (MIT AND Zlib) *)
*/
//# sourceMappingURL=background.js.map
