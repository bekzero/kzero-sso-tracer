"use strict";
(() => {
  // src/shared/utils.ts
  var nowId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

  // src/content/index.ts
  var normalizeLabel = (value) => value.replace(/\s+/g, " ").replace(/[\*\?]+\s*$/g, "").trim().toLowerCase();
  var SENSITIVE_INPUT_TYPES = /* @__PURE__ */ new Set(["password", "hidden", "secret", "token"]);
  var readControlValue = (el) => {
    const input = el;
    if (input instanceof HTMLInputElement) {
      if (SENSITIVE_INPUT_TYPES.has(input.type.toLowerCase())) return null;
      if (input.type === "checkbox") return { found: true, value: input.checked ? "On" : "Off", kind: "checkbox" };
      return { found: true, value: input.value, kind: "input" };
    }
    if (el instanceof HTMLTextAreaElement) return { found: true, value: el.value, kind: "textarea" };
    if (el instanceof HTMLSelectElement) {
      const opt = el.selectedOptions?.[0];
      return { found: true, value: opt ? opt.textContent ?? "" : el.value, kind: "select" };
    }
    const ariaChecked = el.getAttribute("aria-checked");
    if (ariaChecked) return { found: true, value: ariaChecked === "true" ? "On" : "Off", kind: "aria-toggle" };
    const role = el.getAttribute("role");
    if (role === "combobox" || role === "switch") {
      return { found: true, value: el.innerText?.trim() ?? "", kind: role };
    }
    if (el.isContentEditable) return { found: true, value: el.innerText?.trim() ?? "", kind: "contenteditable" };
    return { found: true, value: el.innerText?.trim() ?? "", kind: "element" };
  };
  var findControlNearLabel = (labelEl) => {
    if (labelEl instanceof HTMLLabelElement && labelEl.htmlFor) {
      const byFor = document.getElementById(labelEl.htmlFor);
      if (byFor) return byFor;
    }
    const container = labelEl.closest("div") ?? labelEl.parentElement;
    if (container) {
      const direct = container.querySelector(
        "input, textarea, select, [role='combobox'], [role='switch'], [contenteditable='true']"
      );
      if (direct) return direct;
    }
    const next = labelEl.nextElementSibling;
    if (next) {
      const within = next.querySelector(
        "input, textarea, select, [role='combobox'], [role='switch'], [contenteditable='true']"
      );
      if (within) return within;
      if (next.matches("input, textarea, select")) return next;
    }
    return void 0;
  };
  var findLabelElement = (targetLabel) => {
    const wanted = normalizeLabel(targetLabel);
    const candidates = Array.from(
      document.querySelectorAll(
        "label, [role='label'], [aria-label], [data-testid*='label'], [class*='label'], [class*='Label']"
      )
    );
    for (const el of candidates) {
      const aria = el.getAttribute("aria-label");
      if (aria && normalizeLabel(aria) === wanted) return el;
      const txt = el.innerText?.trim() ?? "";
      if (txt && normalizeLabel(txt) === wanted) return el;
    }
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
      const text = node.textContent?.trim() ?? "";
      if (!text) continue;
      if (normalizeLabel(text) === wanted) {
        const parent = node.parentElement;
        if (parent) return parent;
      }
    }
    return void 0;
  };
  var scanFields = (labels) => {
    const results = {};
    for (const label of labels) {
      const labelEl = findLabelElement(label);
      if (!labelEl) {
        results[label] = { found: false };
        continue;
      }
      const control = findControlNearLabel(labelEl);
      if (!control) {
        results[label] = { found: false };
        continue;
      }
      const result = readControlValue(control);
      if (result === null) {
        results[label] = { found: false };
        continue;
      }
      results[label] = result;
    }
    return results;
  };
  var highlightField = (label) => {
    const labelEl = findLabelElement(label);
    if (!labelEl) return false;
    const target = findControlNearLabel(labelEl) ?? labelEl;
    const el = target;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    const prev = el.getAttribute("data-kzero-highlight");
    el.setAttribute("data-kzero-highlight", "true");
    const oldOutline = el.style.outline;
    const oldBg = el.style.backgroundColor;
    el.style.outline = "2px solid #4dd1ff";
    el.style.backgroundColor = "rgba(77, 209, 255, 0.08)";
    window.setTimeout(() => {
      if (!prev) el.removeAttribute("data-kzero-highlight");
      el.style.outline = oldOutline;
      el.style.backgroundColor = oldBg;
    }, 2500);
    return true;
  };
  var highlightFirst = (labels) => {
    for (const label of labels) {
      if (highlightField(label)) return true;
    }
    return false;
  };
  var port = chrome.runtime.connect({ name: "kzero-content" });
  port.onMessage.addListener((msg) => {
    if (msg?.type === "SCAN_FIELDS") {
      const results = scanFields(Array.isArray(msg.labels) ? msg.labels : []);
      port.postMessage({ type: "UI_SCAN_RESULT", requestId: msg.requestId, results });
    }
    if (msg?.type === "HIGHLIGHT_FIELD") {
      const labels = Array.isArray(msg.labels) ? msg.labels.map(String) : [String(msg.label ?? "")];
      highlightFirst(labels);
    }
  });
  var extractForm = (form) => {
    const output = {};
    const formData = new FormData(form);
    formData.forEach((value, key) => {
      output[key] = String(value);
    });
    return output;
  };
  var sendSamlForm = (form) => {
    const fields = extractForm(form);
    if (!fields.SAMLRequest && !fields.SAMLResponse) return;
    const event = {
      id: nowId(),
      tabId: -1,
      source: "content-form",
      timestamp: Date.now(),
      url: form.action || location.href,
      method: (form.method || "POST").toUpperCase(),
      postBody: new URLSearchParams(fields).toString(),
      host: location.host
    };
    void chrome.runtime.sendMessage({ type: "CONTENT_FORM_EVENT", tabId: void 0, event });
  };
  document.addEventListener(
    "submit",
    (evt) => {
      const target = evt.target;
      if (!(target instanceof HTMLFormElement)) return;
      sendSamlForm(target);
    },
    true
  );
  var origSubmit = HTMLFormElement.prototype.submit;
  HTMLFormElement.prototype.submit = function() {
    const fields = extractForm(this);
    if (fields.SAMLRequest || fields.SAMLResponse) {
      sendSamlForm(this);
    }
    return origSubmit.call(this);
  };
  var observedForms = /* @__PURE__ */ new WeakSet();
  var scanForms = () => {
    const forms = document.querySelectorAll("form[action]");
    const formArray = Array.from(forms);
    for (const form of formArray) {
      if (observedForms.has(form)) continue;
      observedForms.add(form);
      const fields = extractForm(form);
      if (fields.SAMLRequest || fields.SAMLResponse) {
        sendSamlForm(form);
      }
    }
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scanForms);
  } else {
    scanForms();
  }
  var domObserver = new MutationObserver(() => {
    scanForms();
  });
  domObserver.observe(document.documentElement, { childList: true, subtree: true });
})();
//# sourceMappingURL=content.js.map
